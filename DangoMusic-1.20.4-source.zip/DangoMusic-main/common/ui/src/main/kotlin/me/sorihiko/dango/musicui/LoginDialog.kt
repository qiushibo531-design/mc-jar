package me.sorihiko.dango.musicui

import me.sorihiko.dango.i18n.I18n

import me.sorihiko.dango.DangoClient
import me.sorihiko.dango.gfx.Texture
import me.sorihiko.dango.music.MusicScreen
import me.sorihiko.dango.music.NeteaseLogin
import me.sorihiko.dango.music.NativeLogin
import me.sorihiko.dango.music.NeteasePhoneLogin
import me.sorihiko.dango.music.MusicSource
import me.sorihiko.dango.music.MusicSources
import me.sorihiko.dango.platform.Keys
import me.sorihiko.dango.ui.LayoutBounds
import me.sorihiko.dango.ui.ShapeStyle
import me.sorihiko.dango.ui.Theme
import me.sorihiko.dango.utils.Color

/** 登录弹窗（网易云另有手机号登录）：盖在整个播放器上面，开着时其它地方不响应 */
internal class LoginDialog(private val screen: MusicScreen) {
    private val ui = screen.ui
    private val hits = mutableListOf<Hit>()

    companion object {
        // 关掉播放器再打开还在（扫码可能还没完成）
        private var showing = false
        private var qrLoc: Texture? = null
        private var qrUploaded = -1
        private var provider = MusicSource.NETEASE
        private var uploadedProvider = MusicSource.NETEASE
        // 酷狗概念版的二维码（和普通版并排）
        private var liteLoc: Texture? = null
        private var liteUploaded = -1

        // 网易云手机号登录：标签页、输入内容、焦点（0 无 / 1 手机号 / 2 验证码或密码）
        private var phoneMode = false
        private var phone = ""
        private var secret = ""
        private var focus = 0
        private var usePassword = false
    }

    /** 只有网易云有手机号登录；QQ / 酷狗仍然只有扫码 */
    private val hasTabs: Boolean get() = !native
    /** 手机号输入框有焦点：平台层据此让系统输入法可用 */
    val textFocused: Boolean get() = showing && hasTabs && phoneMode && focus != 0

    val visible: Boolean get() = showing
    private val native: Boolean get() = provider != MusicSource.NETEASE
    private val state get() = if (native) NativeLogin.state else NeteaseLogin.state
    private val image get() = if (native) NativeLogin.qrImage else NeteaseLogin.qrImage
    /** 酷狗：普通版和概念版两个码并排 */
    private val dual: Boolean get() = provider == MusicSource.KUGOU

    fun open() {
        showing = true
        provider = MusicSources.selected
        focus = 0
        if (native) NativeLogin.start(provider)
        else if (phoneMode) NeteasePhoneLogin.reset()
        else NeteaseLogin.start()
    }

    fun close() {
        showing = false
        focus = 0
        if (native) NativeLogin.cancel() else NeteaseLogin.cancel()
        NeteasePhoneLogin.reset()
    }

    private fun switchMode(phoneTab: Boolean) {
        if (phoneMode == phoneTab) return
        phoneMode = phoneTab
        focus = 0
        if (phoneTab) {
            NeteaseLogin.cancel()
            NeteasePhoneLogin.reset()
        } else {
            NeteaseLogin.start()
        }
    }

    /** 新二维码生成后传成贴图（每帧调用，没变化就什么都不做） */
    fun uploadQr() {
        val img = image ?: return
        val version = if (native) NativeLogin.qrVersion else NeteaseLogin.qrVersion
        if (version == qrUploaded && uploadedProvider == provider) return
        val textures = DangoClient.gfx.textures
        qrLoc?.let { textures.delete(it) }
        qrLoc = textures.upload("dango_qr", img)
        qrUploaded = version
        uploadedProvider = provider
    }

    private fun uploadLite() {
        val img = NativeLogin.liteImage ?: return
        if (NativeLogin.liteVersion == liteUploaded) return
        val textures = DangoClient.gfx.textures
        liteLoc?.let { textures.delete(it) }
        liteLoc = textures.upload("dango_qr_lite", img)
        liteUploaded = NativeLogin.liteVersion
    }

    fun draw() {
        val ctx = ui.ctx
        hits.clear()
        val state = this.state
        if (state == NeteaseLogin.State.SUCCESS || (hasTabs && phoneMode && NeteasePhoneLogin.status == NeteasePhoneLogin.Status.SUCCESS)) {
            showing = false
            focus = 0
            if (native) NativeLogin.cancel() else NeteaseLogin.cancel()
            NeteasePhoneLogin.reset()
            Library.refreshAll()
            return
        }

        ctx.drawShape(LayoutBounds(0f, 0f, ui.lw, ui.lh), ShapeStyle(Color(0f, 0f, 0f, 0.45f)))
        if (dual) {
            drawDual(state)
            return
        }
        val w = 300f
        val h = if (hasTabs) 408f else 372f
        val dy = if (hasTabs) 36f else 0f
        val box = LayoutBounds((ui.lw - w) / 2f, (ui.lh - h) / 2f, w, h)
        ctx.drawGlass(box, Theme.GLASS_WINDOW)

        val title = if (native) I18n.text("Log in") + " · " + I18n.text(provider.label) else I18n.text("Log in to NetEase")
        ui.text(title, box.x + 20f, box.y + 20f, 18f, Theme.TEXT_PRIMARY, Theme.FONT_SEMIBOLD)
        val closeB = LayoutBounds(box.right - 38f, box.y + 14f, 24f, 24f)
        ctx.drawShape(closeB, ShapeStyle(if (ui.hover(closeB)) Theme.CARD_HOVER else Theme.CARD, 12f))
        ui.text("x", closeB.x + 8.5f, closeB.y + 7f, 12f, Theme.TEXT_PRIMARY, Theme.FONT_MEDIUM)
        hits += closeB to { close() }

        if (hasTabs) {
            val tw = (w - 48f) / 2f
            fun tab(i: Int, label: String, active: Boolean, phoneTab: Boolean) {
                val b = LayoutBounds(box.x + 20f + i * (tw + 8f), box.y + 52f, tw, 26f)
                ctx.drawShape(b, ShapeStyle(if (active) RED else if (ui.hover(b)) Theme.CARD_HOVER else Theme.CARD, 13f))
                val text = I18n.text(label)
                ui.text(text, b.x + (tw - ui.width(text, 12f, Theme.FONT_MEDIUM)) / 2f, b.y + 8f, 12f, Theme.TEXT_PRIMARY, Theme.FONT_MEDIUM)
                hits += b to { switchMode(phoneTab) }
            }
            tab(0, "Scan QR", !phoneMode, false)
            tab(1, "Phone", phoneMode, true)
            if (phoneMode) {
                drawPhone(box, w)
                return
            }
        }

        val qs = 200f
        val qrBox = LayoutBounds(box.x + (w - qs) / 2f, box.y + 60f + dy, qs, qs)
        ctx.drawShape(qrBox.expand(10f, 10f), ShapeStyle(Color.WHITE, 14f))
        val loc = qrLoc
        val showQr = image != null && loc != null &&
            (state == NeteaseLogin.State.WAITING || state == NeteaseLogin.State.SCANNED || state == NeteaseLogin.State.EXPIRED)
        if (showQr) {
            ctx.pushOpacity(if (state == NeteaseLogin.State.EXPIRED) 0.2f else 1f)
            ctx.drawImage(qrBox, loc!!)
            ctx.popOpacity()
        } else {
            val t = if (state == NeteaseLogin.State.ERROR) {
                I18n.text(if (image != null) "Login failed" else "获取二维码失败")
            } else I18n.text("正在获取二维码…")
            ui.text(t, qrBox.x + (qs - ui.width(t, 13f)) / 2f, qrBox.y + qs / 2f - 6f, 13f, Color(0.33f, 0.33f, 0.33f, 1f))
        }

        val msg = when (state) {
            NeteaseLogin.State.WAITING -> I18n.text(when (provider) {
                MusicSource.QQ -> "Scan with the QQ Music app"
                MusicSource.KUGOU -> "Scan with the Kugou Music app"
                else -> "打开手机网易云音乐 App 扫码"
            })
            NeteaseLogin.State.SCANNED -> if (native && NativeLogin.message.isNotEmpty()) I18n.text(NativeLogin.message)
                else I18n.text("已扫码，请在手机上确认登录")
            NeteaseLogin.State.EXPIRED -> I18n.text("二维码已过期")
            NeteaseLogin.State.ERROR -> I18n.text("出错了，请重试")
            else -> I18n.text("请稍候…")
        }
        val msgColor = when (state) {
            NeteaseLogin.State.SCANNED -> Theme.GREEN
            NeteaseLogin.State.ERROR, NeteaseLogin.State.EXPIRED -> RED
            else -> Theme.TEXT_PRIMARY
        }
        val detail = if (native && state == NeteaseLogin.State.ERROR && NativeLogin.message.isNotEmpty()) I18n.text(NativeLogin.message) else msg
        val lines = ui.wrap2(detail, w - 24f, 12f)
        lines.forEachIndexed { index, shown ->
            ui.text(shown, box.x + (w - ui.width(shown, 12f)) / 2f, qrBox.bottom + (if (lines.size > 1) 18f else 24f) + index * 14f, 12f, msgColor)
        }

        if (state == NeteaseLogin.State.EXPIRED || state == NeteaseLogin.State.ERROR) {
            val label = I18n.text("Refresh QR")
            val bw = ui.width(label, 12f, Theme.FONT_MEDIUM) + 28f
            val b = LayoutBounds(box.x + (w - bw) / 2f, qrBox.bottom + 48f, bw, 28f)
            ctx.drawShape(b, ShapeStyle(RED, 14f))
            ui.text(label, b.x + 14f, b.y + 9f, 12f, Theme.TEXT_PRIMARY, Theme.FONT_MEDIUM)
            hits += b to { if (native) NativeLogin.start(provider) else NeteaseLogin.start() }
        }
    }

    private fun caret(): Boolean = (System.currentTimeMillis() / 500) % 2 == 0L

    /** 手机号登录：输入框 + 验证码 / 密码切换 + 发送验证码按钮 */
    private fun drawPhone(box: LayoutBounds, w: Float) {
        val ctx = ui.ctx
        val x = box.x + 20f
        val fw = w - 40f
        var y = box.y + 92f
        val busy = NeteasePhoneLogin.status == NeteasePhoneLogin.Status.WORKING

        // 验证码 / 密码 两种方式
        var px = x
        fun method(label: String, pwd: Boolean) {
            val text = I18n.text(label)
            val b = LayoutBounds(px, y, ui.width(text, 12f, Theme.FONT_MEDIUM) + 20f, 24f)
            val active = usePassword == pwd
            if (active) ctx.drawShape(b, ShapeStyle(Theme.CARD_HOVER, 12f))
            ui.text(text, b.x + 10f, b.y + 7f, 12f, if (active) Theme.TEXT_PRIMARY else Theme.TEXT_SECONDARY, Theme.FONT_MEDIUM)
            hits += b to {
                if (usePassword != pwd) {
                    usePassword = pwd
                    secret = ""
                    NeteasePhoneLogin.reset()
                }
            }
            px = b.right + 6f
        }
        method("SMS code", false)
        method("Password", true)
        y += 34f

        fun field(r: LayoutBounds, id: Int, value: String, placeholder: String, prefix: String) {
            val focused = focus == id
            ctx.drawShape(r, ShapeStyle(Theme.CARD, 10f))
            if (focused) ctx.drawShape(r, ShapeStyle(Color(0f, 0f, 0f, 0f), 10f, 1.4f, RED))
            var tx = r.x + 12f
            if (prefix.isNotEmpty()) {
                ui.text(prefix, tx, r.y + 11f, 13f, Theme.TEXT_SECONDARY, Theme.FONT_MEDIUM)
                tx += ui.width(prefix, 13f, Theme.FONT_MEDIUM) + 10f
            }
            val maxW = r.right - 10f - tx
            if (value.isEmpty()) {
                ui.text(ui.trim(I18n.text(placeholder), maxW, 12f), tx, r.y + 11f, 12f, Theme.TEXT_TERTIARY)
                if (focused && caret()) ui.text("|", tx, r.y + 11f, 13f, Theme.TEXT_PRIMARY)
            } else {
                var visible = value + (if (focused && caret()) "|" else "")
                while (visible.length > 1 && ui.width(visible, 13f) > maxW) visible = visible.substring(1)
                ui.text(visible, tx, r.y + 11f, 13f, Theme.TEXT_PRIMARY)
            }
            hits += r to { focus = id }
        }

        field(LayoutBounds(x, y, fw, 36f), 1, phone, "Phone number", "+86")
        y += 46f

        val btnW = 104f
        val sw = if (usePassword) fw else fw - btnW - 8f
        val shown = if (usePassword) "*".repeat(secret.length) else secret
        field(LayoutBounds(x, y, sw, 36f), 2, shown, if (usePassword) "Password" else "Verification code", "")
        if (!usePassword) {
            val wait = NeteasePhoneLogin.cooldownSeconds()
            val enabled = wait == 0 && !NeteasePhoneLogin.sending && !busy
            val b = LayoutBounds(x + sw + 8f, y, btnW, 36f)
            ctx.drawShape(b, ShapeStyle(if (enabled) (if (ui.hover(b)) RED else RED.copy(a = 0.85f)) else Theme.CARD, 10f))
            val label = if (wait > 0) I18n.format("Resend (%ds)", wait) else I18n.text("Send code")
            ui.text(label, b.x + (btnW - ui.width(label, 12f, Theme.FONT_MEDIUM)) / 2f, b.y + 11f, 12f,
                if (enabled) Theme.TEXT_PRIMARY else Theme.TEXT_TERTIARY, Theme.FONT_MEDIUM)
            if (enabled) hits += b to { NeteasePhoneLogin.sendCaptcha(phone) }
        }
        y += 50f

        val lb = LayoutBounds(x, y, fw, 36f)
        ctx.drawShape(lb, ShapeStyle(if (busy) Theme.CARD else if (ui.hover(lb)) RED else RED.copy(a = 0.9f), 18f))
        val label = I18n.text(if (busy && !NeteasePhoneLogin.sending) "Logging in…" else "Log in")
        ui.text(label, lb.x + (fw - ui.width(label, 13f, Theme.FONT_MEDIUM)) / 2f, lb.y + 11f, 13f,
            if (busy) Theme.TEXT_TERTIARY else Theme.TEXT_PRIMARY, Theme.FONT_MEDIUM)
        if (!busy) hits += lb to { submit() }
        y += 46f

        val msg = NeteasePhoneLogin.message
        if (msg.isNotEmpty()) {
            val color = when (NeteasePhoneLogin.status) {
                NeteasePhoneLogin.Status.ERROR -> RED
                NeteasePhoneLogin.Status.WORKING -> Theme.TEXT_SECONDARY
                else -> Theme.GREEN
            }
            ui.wrap2(I18n.text(msg), fw, 12f).take(3).forEachIndexed { i, line ->
                ui.text(line, x, y + i * 14f, 12f, color)
            }
        }
        // 点空白处取消输入焦点（放最后，上面的控件优先）
        hits += box to { focus = 0 }
    }

    private fun submit() = NeteasePhoneLogin.login(phone, secret, usePassword)

    /** 酷狗：左边普通版、右边概念版，扫哪个就按哪个版本登录 */
    private fun drawDual(state: NeteaseLogin.State) {
        val ctx = ui.ctx
        uploadLite()
        val lite = NativeLogin.liteState
        val w = 520f
        val h = 392f
        val box = LayoutBounds((ui.lw - w) / 2f, (ui.lh - h) / 2f, w, h)
        ctx.drawGlass(box, Theme.GLASS_WINDOW)
        ui.text(I18n.text("Log in") + " · " + I18n.text(provider.label), box.x + 20f, box.y + 20f, 18f, Theme.TEXT_PRIMARY, Theme.FONT_SEMIBOLD)
        val closeB = LayoutBounds(box.right - 38f, box.y + 14f, 24f, 24f)
        ctx.drawShape(closeB, ShapeStyle(if (ui.hover(closeB)) Theme.CARD_HOVER else Theme.CARD, 12f))
        ui.text("x", closeB.x + 8.5f, closeB.y + 7f, 12f, Theme.TEXT_PRIMARY, Theme.FONT_MEDIUM)
        hits += closeB to { close() }

        val qs = 180f
        val gap = 70f
        val left = box.x + (w - qs * 2f - gap) / 2f
        fun slot(x: Float, loc: Texture?, img: Any?, slotState: NeteaseLogin.State, label: String, note: String) {
            val qrBox = LayoutBounds(x, box.y + 66f, qs, qs)
            ctx.drawShape(qrBox.expand(10f, 10f), ShapeStyle(Color.WHITE, 14f))
            val visible = img != null && loc != null &&
                (slotState == NeteaseLogin.State.WAITING || slotState == NeteaseLogin.State.SCANNED || slotState == NeteaseLogin.State.EXPIRED)
            if (visible) {
                ctx.pushOpacity(if (slotState == NeteaseLogin.State.EXPIRED) 0.2f else 1f)
                ctx.drawImage(qrBox, loc!!)
                ctx.popOpacity()
            } else {
                val t = I18n.text(if (slotState == NeteaseLogin.State.ERROR) "获取二维码失败" else "正在获取二维码…")
                ui.text(t, qrBox.x + (qs - ui.width(t, 13f)) / 2f, qrBox.y + qs / 2f - 6f, 13f, Color(0.33f, 0.33f, 0.33f, 1f))
            }
            val title = I18n.text(label)
            ui.text(title, x + (qs - ui.width(title, 13f, Theme.FONT_MEDIUM)) / 2f, qrBox.bottom + 20f, 13f, Theme.TEXT_PRIMARY, Theme.FONT_MEDIUM)
            val sub = I18n.text(if (slotState == NeteaseLogin.State.SCANNED) "已扫码，请在手机上确认登录" else note)
            if (sub.isNotEmpty()) ui.text(sub, x + (qs - ui.width(sub, 11f)) / 2f, qrBox.bottom + 38f, 11f,
                if (slotState == NeteaseLogin.State.SCANNED) Theme.GREEN else Theme.TEXT_SECONDARY)
        }
        slot(left, qrLoc, image, state, "Scan with the Kugou Music app", "")
        slot(left + qs + gap, liteLoc, NativeLogin.liteImage, lite, "Scan with Kugou Lite", "Free VIP claimed for you every day")

        // 底部：出错的说明；两个码都不能用了才给刷新按钮
        val dead = { s: NeteaseLogin.State -> s == NeteaseLogin.State.EXPIRED || s == NeteaseLogin.State.ERROR }
        val y = box.y + 66f + qs + 66f
        if (state == NeteaseLogin.State.ERROR && NativeLogin.message.isNotEmpty()) {
            val lines = ui.wrap2(I18n.text(NativeLogin.message), w - 40f, 12f)
            lines.forEachIndexed { index, shown -> ui.text(shown, box.x + (w - ui.width(shown, 12f)) / 2f, y + index * 14f, 12f, RED) }
        }
        if (dead(state) && dead(lite)) {
            val label = I18n.text("Refresh QR")
            val bw = ui.width(label, 12f, Theme.FONT_MEDIUM) + 28f
            val b = LayoutBounds(box.x + (w - bw) / 2f, box.bottom - 44f, bw, 28f)
            ctx.drawShape(b, ShapeStyle(RED, 14f))
            ui.text(label, b.x + 14f, b.y + 9f, 12f, Theme.TEXT_PRIMARY, Theme.FONT_MEDIUM)
            hits += b to { NativeLogin.start(provider) }
        }
    }

    fun mouseClicked(mx: Int, my: Int, button: Int) {
        if (button == 0) hits.firstOrNull { it.first.contains(mx, my) }?.second?.invoke()
    }

    fun keyTyped(typedChar: Char, keyCode: Int) {
        if (!(hasTabs && phoneMode) || focus == 0) {
            if (keyCode == Keys.ESCAPE) close()
            return
        }
        val digitsOnly = focus == 1 || !usePassword
        val limit = if (focus == 1) 15 else if (usePassword) 64 else 8
        fun current() = if (focus == 1) phone else secret
        fun set(v: String) { if (focus == 1) phone = v else secret = v }
        fun accept(c: Char) = if (digitsOnly) c in '0'..'9' else Keys.isAllowedChar(c)
        when {
            keyCode == Keys.ESCAPE -> focus = 0
            keyCode == Keys.TAB -> focus = if (focus == 1) 2 else 1
            keyCode == Keys.RETURN || keyCode == Keys.NUMPADENTER ->
                if (focus == 1 && !usePassword) focus = 2 else submit()
            keyCode == Keys.BACK -> if (current().isNotEmpty()) set(current().dropLast(1))
            DangoClient.platform.ctrlDown && keyCode == Keys.V -> {
                val clip = DangoClient.platform.clipboard.filter { accept(it) }
                set((current() + clip).take(limit))
            }
            DangoClient.platform.ctrlDown && keyCode == Keys.A -> set("")
            typedChar != '\u0000' && accept(typedChar) -> set((current() + typedChar).take(limit))
        }
    }
}
