package me.sorihiko.dango.music

import com.google.gson.JsonObject
import com.google.gson.JsonParser
import me.sorihiko.dango.DangoLogger

import java.nio.charset.StandardCharsets
import java.security.MessageDigest

/**
 * 网易云手机号登录：短信验证码 / 密码两种方式（和网页版一样走 weapi）。
 *   发验证码  POST /weapi/sms/captcha/sent      {cellphone, ctcode}
 *   登录      POST /weapi/login/cellphone       {phone, countrycode, captcha | password(md5), rememberLogin}
 * 成功后把响应里的登录 Cookie 存起来，和扫码登录存到同一个地方。
 * [message] 是界面文案（英文原文，界面用 I18n.text 翻译）。
 */
object NeteasePhoneLogin {

    enum class Status { IDLE, WORKING, SUCCESS, ERROR }

    @Volatile var status = Status.IDLE
        private set
    @Volatile var message = ""
        private set
    /** 正在发验证码（发送按钮据此置灰） */
    @Volatile var sending = false
        private set
    @Volatile private var nextSendAt = 0L
    @Volatile private var session = 0

    private const val COUNTRY = "86"
    private const val RESEND_MS = 60_000L

    /** 还要等几秒才能再发验证码，0 表示可以发 */
    fun cooldownSeconds(): Int {
        val left = nextSendAt - System.currentTimeMillis()
        return if (left <= 0) 0 else ((left + 999) / 1000).toInt()
    }

    fun reset() {
        ++session
        status = Status.IDLE
        message = ""
        sending = false
    }

    fun validPhone(phone: String): Boolean = phone.length in 5..15 && phone.all { it in '0'..'9' }

    fun sendCaptcha(phone: String) {
        if (sending || status == Status.WORKING || cooldownSeconds() > 0) return
        if (!validPhone(phone)) return fail("Invalid phone number")
        val my = ++session
        sending = true
        status = Status.WORKING
        message = "Sending…"
        val json = JsonObject().apply {
            addProperty("cellphone", phone)
            addProperty("ctcode", COUNTRY)
        }.toString()
        Thread({
            try {
                val resp = NeteaseLogin.weapi("https://music.163.com/weapi/sms/captcha/sent", json)
                if (my != session) return@Thread
                if (resp == null) return@Thread fail("Network error")
                val obj = JsonParser().parse(resp.first).asJsonObject
                val code = obj.get("code")?.asInt ?: -1
                if (code == 200) {
                    nextSendAt = System.currentTimeMillis() + RESEND_MS
                    status = Status.IDLE
                    message = "Code sent"
                } else {
                    fail(describe(code, obj, "Failed to send code"))
                }
            } catch (e: Exception) {
                DangoLogger.warn("NetEase send captcha failed: {}", e.toString())
                if (my == session) fail("Network error")
            } finally {
                if (my == session) sending = false
            }
        }, "Dango-NeteasePhoneCaptcha").apply { isDaemon = true; start() }
    }

    /** [secret] 是验证码（[usePassword] 为 false）或密码 */
    fun login(phone: String, secret: String, usePassword: Boolean) {
        if (status == Status.WORKING) return
        if (!validPhone(phone)) return fail("Invalid phone number")
        if (secret.isEmpty()) return fail(if (usePassword) "Enter your password" else "Enter the verification code")
        val my = ++session
        sending = false
        status = Status.WORKING
        message = "Logging in…"
        val json = JsonObject().apply {
            addProperty("phone", phone)
            addProperty("countrycode", COUNTRY)
            if (usePassword) addProperty("password", md5(secret)) else addProperty("captcha", secret)
            addProperty("rememberLogin", "true")
        }.toString()
        Thread({
            try {
                val resp = NeteaseLogin.weapi("https://music.163.com/weapi/login/cellphone", json)
                if (my != session) return@Thread
                if (resp == null) return@Thread fail("Network error")
                val obj = JsonParser().parse(resp.first).asJsonObject
                val code = obj.get("code")?.asInt ?: -1
                if (code != 200) return@Thread fail(describe(code, obj, "Login failed"))
                val cookie = NeteaseLogin.extractCookie(resp.second)
                if (!cookie.contains("MUSIC_U=")) return@Thread fail("Login failed (no cookie returned)")
                NeteaseApi.saveCookie(cookie)
                message = ""
                status = Status.SUCCESS
            } catch (e: Exception) {
                DangoLogger.warn("NetEase phone login failed: {}", e.toString())
                if (my == session) fail("Network error")
            }
        }, "Dango-NeteasePhoneLogin").apply { isDaemon = true; start() }
    }

    private fun fail(msg: String) {
        message = msg
        status = Status.ERROR
    }

    private fun describe(code: Int, obj: JsonObject, fallback: String): String = when (code) {
        502 -> "Wrong password"
        503 -> "Wrong or expired verification code"
        415, 405 -> "Too many requests, try again later"
        8821, -460 -> "NetEase asked for extra verification. Log in with the QR code instead."
        else -> {
            val server = (obj.get("message") ?: obj.get("msg"))?.takeIf { it.isJsonPrimitive }?.asString.orEmpty()
            "$fallback (code $code" + (if (server.isNotEmpty()) ": $server" else "") + ")"
        }
    }

    private fun md5(text: String): String =
        MessageDigest.getInstance("MD5").digest(text.toByteArray(StandardCharsets.UTF_8))
            .joinToString("") { "%02x".format(it) }
}
