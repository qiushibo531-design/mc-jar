package me.sorihiko.dango.music

import com.google.gson.JsonObject
import me.sorihiko.dango.DangoMusic
import me.sorihiko.dango.i18n.I18n
import me.sorihiko.dango.lyrics.Lyrics

/**
 * Jamendo（https://www.jamendo.com）：免费、合法的独立音乐平台，官方公开 API v3.0，播放 MP3。
 * 需要一个免费的 client ID（https://devportal.jamendo.com 注册应用即可拿到），
 * 保存到 config/dangomusic/jamendo_client_id.txt，或设置环境变量 DANGO_JAMENDO_CLIENT_ID。
 * 不需要登录。没有歌词、歌手页和云盘。
 */
object JamendoMusicSource : MusicSourceApi {
    override val source = MusicSource.JAMENDO
    private const val API = "https://api.jamendo.com/v3.0"
    private const val REFERER = "https://www.jamendo.com/"

    /** 榜单入口用负数 ID，不会和真实歌单 ID 冲突 */
    private const val CHART_WEEK = -164001L
    private const val CHART_MONTH = -164002L
    private const val CHART_ALL = -164003L

    private const val NEED_KEY = "Jamendo needs a free client ID. Get one at devportal.jamendo.com and save it to config/dangomusic/jamendo_client_id.txt"

    private fun clientId(): String {
        System.getenv("DANGO_JAMENDO_CLIENT_ID")?.trim()?.takeIf { it.isNotEmpty() }?.let { return it }
        return try {
            DangoMusic.instance.clientDir.resolve("jamendo_client_id.txt").toFile().readText().trim()
        } catch (_: Exception) { "" }
    }

    override val libraryWarning: String get() = if (clientId().isEmpty()) NEED_KEY else ""

    private fun call(path: String, params: String): JsonObject {
        val id = clientId()
        if (id.isEmpty()) throw SourceAccessException(NEED_KEY)
        val root = SourceHttp.json("$API/$path/?client_id=${SourceHttp.enc(id)}&format=json&$params", REFERER)
        if (root.getAsJsonObject("headers")?.text("status") == "failed")
            throw SourceAccessException("Jamendo request failed. Check your client ID and try again.")
        return root
    }

    private fun parseTrack(o: JsonObject): NeteaseTrack? {
        val id = o.text("id")
        if (!id.matches(Regex("[0-9]{1,12}"))) return null
        val artist = cleanSourceText(o.text("artist_name"))
        return NeteaseTrack(
            MusicSources.stableId(source, id), cleanSourceText(o.text("name")),
            if (artist.isEmpty()) emptyList() else listOf(artist),
            o.number("duration") * 1000, o.text("image"), source, id, id, o.text("album_id"),
        )
    }

    private fun tracks(root: JsonObject): List<NeteaseTrack> =
        root.getAsJsonArray("results")?.mapNotNull { if (it.isJsonObject) parseTrack(it.asJsonObject) else null } ?: emptyList()

    override fun search(query: String): List<NeteaseTrack> =
        tracks(call("tracks", "limit=40&imagesize=300&audioformat=mp32&search=${SourceHttp.enc(query)}"))

    override fun songUrl(track: NeteaseTrack): NeteaseApi.SongUrl? {
        val item = call("tracks", "id=${SourceHttp.enc(track.nativeId)}&imagesize=300&audioformat=mp32")
            .getAsJsonArray("results")?.firstOrNull()?.takeIf { it.isJsonObject }?.asJsonObject ?: return null
        val url = item.text("audio")
        if (!url.startsWith("https://") && !url.startsWith("http://")) return null
        if (track.coverUrl.isEmpty()) track.coverUrl = item.text("image")
        return NeteaseApi.SongUrl(url, false)
    }

    /** Jamendo 的曲目没有同步歌词 */
    override fun lyrics(track: NeteaseTrack): Lyrics? = null

    override fun charts(): List<NeteasePlaylist> = listOf(
        NeteasePlaylist(CHART_WEEK, I18n.text("Popular this week"), 0, "", false),
        NeteasePlaylist(CHART_MONTH, I18n.text("Popular this month"), 0, "", false),
        NeteasePlaylist(CHART_ALL, I18n.text("Popular of all time"), 0, "", false),
    )

    override fun recommend(): List<NeteasePlaylist> {
        val featured = try {
            call("playlists", "limit=30").getAsJsonArray("results")?.mapNotNull { e ->
                val o = e.takeIf { it.isJsonObject }?.asJsonObject ?: return@mapNotNull null
                val id = o.number("id")
                if (id <= 0) null else NeteasePlaylist(id, cleanSourceText(o.text("name")), 0, "", false)
            } ?: emptyList()
        } catch (e: SourceAccessException) { throw e } catch (_: Exception) { emptyList() }
        return charts() + featured
    }

    override fun playlistTracks(id: Long): List<NeteaseTrack> {
        val order = when (id) {
            CHART_WEEK -> "popularity_week"
            CHART_MONTH -> "popularity_month"
            CHART_ALL -> "popularity_total"
            else -> null
        }
        if (order != null) return tracks(call("tracks", "limit=50&imagesize=300&audioformat=mp32&order=$order"))
        val list = call("playlists/tracks", "id=$id").getAsJsonArray("results")?.firstOrNull()?.takeIf { it.isJsonObject }?.asJsonObject
        return list?.getAsJsonArray("tracks")?.mapNotNull { if (it.isJsonObject) parseTrack(it.asJsonObject) else null } ?: emptyList()
    }
}
