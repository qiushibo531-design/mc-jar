package me.sorihiko.dango.music

import com.google.gson.JsonObject
import me.sorihiko.dango.i18n.I18n
import me.sorihiko.dango.lyrics.Lyrics
import java.util.concurrent.ConcurrentHashMap

/**
 * Audius（https://audius.co）：去中心化的音乐平台，官方公开 API，不需要 key 也不需要登录，播放 MP3。
 * 只有搜索 / 播放 / 趋势榜 / 趋势歌单；没有歌词、歌手页和云盘。
 */
object AudiusMusicSource : MusicSourceApi {
    override val source = MusicSource.AUDIUS
    private const val API = "https://api.audius.co/v1"
    private const val APP = "app_name=DangoMusic"
    private const val REFERER = "https://audius.co/"

    private const val CHART_WEEK = -165001L
    private const val CHART_MONTH = -165002L
    private const val CHART_ALL = -165003L

    /** Audius 的歌单 ID 是字符串，界面用数字：登记一下对应关系 */
    private val playlistIds = ConcurrentHashMap<Long, String>()

    private fun get(path: String, params: String = ""): JsonObject {
        val root = SourceHttp.json("$API/$path${if (path.contains('?')) "&" else "?"}$APP$params", REFERER)
        if (root.get("data") == null) throw SourceAccessException("Audius request failed. Please retry.")
        return root
    }

    private fun cover(o: JsonObject): String {
        val art = o.getAsJsonObject("artwork") ?: return ""
        return art.text("480x480").ifEmpty { art.text("150x150").ifEmpty { art.text("1000x1000") } }
    }

    private fun parseTrack(o: JsonObject): NeteaseTrack? {
        val id = o.text("id")
        if (!id.matches(Regex("[A-Za-z0-9]{1,24}"))) return null
        if (o.get("is_streamable")?.takeIf { it.isJsonPrimitive }?.asBoolean == false) return null
        val artist = cleanSourceText(o.getAsJsonObject("user")?.text("name").orEmpty())
        return NeteaseTrack(
            MusicSources.stableId(source, id), cleanSourceText(o.text("title")),
            if (artist.isEmpty()) emptyList() else listOf(artist),
            o.number("duration") * 1000, cover(o), source, id, id, "",
        )
    }

    private fun tracks(root: JsonObject): List<NeteaseTrack> =
        root.getAsJsonArray("data")?.mapNotNull { if (it.isJsonObject) parseTrack(it.asJsonObject) else null } ?: emptyList()

    override fun search(query: String): List<NeteaseTrack> =
        tracks(get("tracks/search?query=${SourceHttp.enc(query)}&limit=40"))

    /** 流地址会 302 到某个内容节点，SourceHttp 会跟随跳转 */
    override fun songUrl(track: NeteaseTrack): NeteaseApi.SongUrl? {
        if (!track.nativeId.matches(Regex("[A-Za-z0-9]{1,24}"))) return null
        return NeteaseApi.SongUrl("$API/tracks/${track.nativeId}/stream?$APP", false)
    }

    override fun lyrics(track: NeteaseTrack): Lyrics? = null

    override fun charts(): List<NeteasePlaylist> = listOf(
        NeteasePlaylist(CHART_WEEK, I18n.text("Popular this week"), 0, "", false),
        NeteasePlaylist(CHART_MONTH, I18n.text("Popular this month"), 0, "", false),
        NeteasePlaylist(CHART_ALL, I18n.text("Popular of all time"), 0, "", false),
    )

    override fun recommend(): List<NeteasePlaylist> {
        val trending = try {
            get("playlists/trending", "&time=week").getAsJsonArray("data")?.mapNotNull { e ->
                val o = e.takeIf { it.isJsonObject }?.asJsonObject ?: return@mapNotNull null
                val id = o.text("id")
                if (!id.matches(Regex("[A-Za-z0-9]{1,24}"))) return@mapNotNull null
                val stable = MusicSources.stableId(source, "playlist:$id")
                playlistIds[stable] = id
                NeteasePlaylist(stable, cleanSourceText(o.text("playlist_name")), o.number("track_count").toInt(), cover(o), false)
            } ?: emptyList()
        } catch (e: SourceAccessException) { throw e } catch (_: Exception) { emptyList() }
        return charts() + trending
    }

    override fun playlistTracks(id: Long): List<NeteaseTrack> {
        val time = when (id) {
            CHART_WEEK -> "week"
            CHART_MONTH -> "month"
            CHART_ALL -> "allTime"
            else -> null
        }
        if (time != null) return tracks(get("tracks/trending", "&time=$time&limit=50"))
        val real = playlistIds[id] ?: return emptyList()
        return tracks(get("playlists/$real/tracks"))
    }
}
