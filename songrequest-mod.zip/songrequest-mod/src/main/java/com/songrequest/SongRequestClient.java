package com.songrequest;

import com.songrequest.api.NeteaseApi;
import com.songrequest.audio.JavaSoundSink;
import com.songrequest.audio.MusicPlayer;
import com.songrequest.gui.MusicScreen;
import com.songrequest.hud.LyricsHud;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.sound.SoundCategory;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SongRequestClient implements ClientModInitializer {
    public static final String MOD_ID = "songrequest";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    public static final MusicPlayer PLAYER = new MusicPlayer(
            JavaSoundSink::new, NeteaseApi::openAudio, NeteaseApi::fetchLyrics);

    private static KeyBinding openKey;
    private static KeyBinding skipKey;
    private static KeyBinding pauseKey;

    @Override
    public void onInitializeClient() {
        Config.load();

        // 實際音量 = 模組音量 × 遊戲「主音量」× 遊戲「音樂」音量（平方讓滑桿手感更自然）
        PLAYER.setVolumeSupplier(() -> {
            GameOptions o = MinecraftClient.getInstance().options;
            double v = Config.get().volume
                    * o.getSoundVolume(SoundCategory.MASTER)
                    * o.getSoundVolume(SoundCategory.MUSIC);
            return v * v;
        });

        PLAYER.setErrorHandler(raw -> {
            String[] parts = raw.split("\u0000", 2);
            String code = parts[0];
            String name = parts.length > 1 ? parts[1] : "?";
            Text msg = "no_audio".equals(code)
                    ? Text.translatable("songrequest.error.no_audio", name)
                    : Text.translatable("songrequest.error.failed", name, code);
            MinecraftClient mc = MinecraftClient.getInstance();
            mc.execute(() -> {
                if (mc.player != null) mc.player.sendMessage(msg, true);
            });
            LOGGER.warn("播放失敗: {} ({})", name, code);
        });

        openKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.songrequest.open", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_M, "category.songrequest"));
        skipKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.songrequest.skip", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_UNKNOWN, "category.songrequest"));
        pauseKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.songrequest.pause", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_UNKNOWN, "category.songrequest"));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openKey.wasPressed()) {
                if (client.currentScreen == null) client.setScreen(new MusicScreen());
            }
            while (skipKey.wasPressed()) PLAYER.skip();
            while (pauseKey.wasPressed()) PLAYER.togglePause();
        });

        HudRenderCallback.EVENT.register(LyricsHud::render);

        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> {
            PLAYER.stop();
            Config.save();
        });
    }
}
