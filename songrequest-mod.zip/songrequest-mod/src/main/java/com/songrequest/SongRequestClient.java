package com.songrequest;

import com.songrequest.api.Providers;
import com.songrequest.audio.OpenAlSink;
import com.songrequest.audio.MusicPlayer;
import com.songrequest.gui.MusicScreen;
import com.songrequest.hud.LyricsHud;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.sound.SoundCategory;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SongRequestClient implements ClientModInitializer {
    public static final String MOD_ID = "songrequest";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    public static final MusicPlayer PLAYER = new MusicPlayer(
            OpenAlSink::new,
            song -> Providers.byId(song.source()).openAudio(song),
            song -> Providers.byId(song.source()).fetchLyrics(song));

    private static KeyBinding openKey;
    private static KeyBinding skipKey;
    private static KeyBinding pauseKey;

    @Override
    public void onInitializeClient() {
        Config.load();

        // 實際音量 = 模組音量 × 遊戲「主音量」× 遊戲「音樂」音量（平方讓滑桿手感更自然）
        // 由 OpenAL 的 source gain 即時套用，所以播放器本身不再縮放取樣
        OpenAlSink.setGainSupplier(() -> {
            GameOptions o = MinecraftClient.getInstance().options;
            double v = Config.get().volume
                    * o.getSoundVolume(SoundCategory.MASTER)
                    * o.getSoundVolume(SoundCategory.MUSIC);
            return v * v;
        });

        PLAYER.setErrorHandler(raw -> {
            String[] parts = raw.split("\u0000", 2);
            String code = parts[0];
            String name = parts.length > 1 ? parts[1] : "?";
            Text msg;
            if (code.startsWith("no_audio")) {
                String detail = code.length() > 9 ? code.substring(9) : "";
                msg = Text.translatable("songrequest.error.no_audio", name, detail);
            } else {
                msg = Text.translatable("songrequest.error.failed", name, code);
            }
            MinecraftClient mc = MinecraftClient.getInstance();
            mc.execute(() -> {
                if (mc.player != null) mc.player.sendMessage(msg, true);
                // 在主界面或點歌台打開時，玩家看不到動作列，所以同步寫進點歌台的狀態列
                MusicScreen.postStatus(msg.getString(), true);
            });
            LOGGER.warn("播放失敗: {} ({})", name, code);
        });

        openKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.songrequest.open", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_M, "category.songrequest"));
        skipKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.songrequest.skip", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_UNKNOWN, "category.songrequest"));
        pauseKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.songrequest.pause", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_UNKNOWN, "category.songrequest"));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            OpenAlSink.tickAll();
            while (openKey.wasPressed()) {
                if (client.currentScreen == null) client.setScreen(new MusicScreen());
            }
            while (skipKey.wasPressed()) PLAYER.skip();
            while (pauseKey.wasPressed()) PLAYER.togglePause();
        });

        HudRenderCallback.EVENT.register(LyricsHud::render);
        MenuIntegration.register();

        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> {
            PLAYER.stop();
            Config.save();
        });
    }
}
