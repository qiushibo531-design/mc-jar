package com.songrequest;

import com.songrequest.gui.MusicScreen;
import com.songrequest.hud.LyricsHud;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.client.gui.screen.GameMenuScreen;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

/**
 * 讓主界面與暫停選單也能點歌：左上角加一個「♪ 點歌」按鈕，
 * 並在沒有進入世界時（主界面、選擇存檔等）繼續顯示歌名與歌詞字幕，方便隨時暫停／切歌。
 */
final class MenuIntegration {
    private MenuIntegration() {}

    private static int bx(int w) {
        return 6 + Math.round((w - 12 - 64) * Config.get().btnX);
    }

    private static int by(int h) {
        return 6 + Math.round((h - 12 - 20) * Config.get().btnY);
    }

    static void register() {
        ScreenEvents.AFTER_INIT.register((client, screen, scaledWidth, scaledHeight) -> {
            if (screen instanceof TitleScreen || screen instanceof GameMenuScreen) {
                ButtonWidget btn = ButtonWidget.builder(Text.translatable("songrequest.menu.button"),
                        b -> client.setScreen(new MusicScreen(screen)))
                        .dimensions(bx(scaledWidth), by(scaledHeight), 64, 20).build();
                Screens.getButtons(screen).add(btn);
            }
            // 沒進世界時，遊戲內 HUD 不會畫，所以在各個選單畫面補上字幕
            if (client.world == null && !(screen instanceof MusicScreen)) {
                ScreenEvents.afterRender(screen).register((s, ctx, mouseX, mouseY, tickDelta) -> LyricsHud.render(ctx, tickDelta));
            }
        });
    }
}
