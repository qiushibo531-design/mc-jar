package com.songrequest.api;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.songrequest.Config;

import java.io.IOException;
import java.io.InputStream;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.List;

/**
 * 自建 API：相容 NeteaseCloudMusicApi（Binaryify/NeteaseCloudMusicApi 及其衍生專案）的伺服器。
 * 在音源設定填入你的服務網址，例如 https://你的網域 或 http://192.168.1.2:3000 。
 * 帳號登入、VIP 等都由你自己的服務端處理。
 */
public final class CustomApiProvider implements MusicProvider {
    @Override public String id() { return "custom"; }
    @Override public String displayName() { return "自建 API"; }
    @Override public String tag() { return "songrequest.tag.self"; }
    @Override public String configLabel() { return "songrequest.cfg.url"; }

    private static String base() throws IOException {
        String u = Config.api("custom");
        if (u.isEmpty()) throw new IOException("need_config");
        if (!u.startsWith("http")) u = "http://" + u;
        return u.replaceAll("/+$", "");
    }

    private static String get(String path) throws Exception {
        return Http.get(base() + path, null, null, Http.UA_DESKTOP);
    }

    @Override
    public List<Song> search(String keyword) throws Exception {
        List<Song> songs = NeteaseProvider.parseSearch(get("/cloudsearch?limit=30&keywords=" + URLEncoder.encode(keyword.trim(), StandardCharsets.UTF_8)));
        return songs.stream().map(s -> new Song("custom", s.id(), s.name(), s.artist(), s.album(), s.durationMs(), "")).toList();
    }

    @Override
    public InputStream openAudio(Song song) throws Exception {
        JsonArray data = Json.arr(Json.parse(get("/song/url?br=320000&id=" + song.id())), "data");
        String url = data.isEmpty() ? "" : Json.str(data.get(0).getAsJsonObject(), "url", "");
        if (url.isEmpty()) throw new IOException("no_audio:custom_no_url");
        try {
            return Http.openAudio(url, null, null);
        } catch (IOException e) {
            throw new IOException("no_audio:" + e.getMessage());
        }
    }

    @Override
    public Lyrics fetchLyrics(Song song) throws Exception {
        JsonObject root = Json.parse(get("/lyric?id=" + song.id()));
        return Lyrics.parse(Json.str(Json.obj(root, "lrc"), "lyric", null), Json.str(Json.obj(root, "tlyric"), "lyric", null));
    }
}
