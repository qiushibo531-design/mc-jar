package com.songrequest.api;

import com.songrequest.audio.OggInfo;
import javazoom.jl.decoder.Bitstream;
import javazoom.jl.decoder.Header;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.stream.Stream;

/** 本地音樂：讀取遊戲目錄下 "Local music" 資料夾裡的 MP3／OGG（同名 .lrc 會當歌詞）。搜尋欄留空＝列出全部。 */
public final class LocalProvider implements MusicProvider {
    public static final String FOLDER = "Local music";

    public static Path dir() {
        Path d = FabricLoader.getInstance().getGameDir().resolve(FOLDER);
        try {
            Files.createDirectories(d);
        } catch (IOException ignored) {
            // 唯讀環境：搜尋時只會得到空清單
        }
        return d;
    }

    private static String pathStr;

    public static String pathString() {
        if (pathStr == null) pathStr = dir().toAbsolutePath().toString();
        return pathStr;
    }

    private static boolean supported(Path p) {
        String n = p.getFileName().toString().toLowerCase(Locale.ROOT);
        return n.endsWith(".mp3") || n.endsWith(".ogg");
    }

    @Override public String id() { return "local"; }
    @Override public String displayName() { return "本地音乐 Local music"; }
    @Override public String tag() { return "songrequest.tag.local"; }

    @Override
    public List<Song> search(String keyword) throws Exception {
        Path root = dir();
        String q = keyword == null ? "" : keyword.trim().toLowerCase(Locale.ROOT);
        List<Path> files;
        try (Stream<Path> s = Files.walk(root, 4)) {
            files = s.filter(Files::isRegularFile).filter(LocalProvider::supported).sorted().toList();
        }
        if (files.isEmpty()) throw new IOException("local_empty:" + root.toAbsolutePath());
        // 搜尋欄裡可能還留著上次搜網路音源的字：沒有任何檔名符合時就列出全部
        boolean any = false;
        for (Path f : files) if (q.isEmpty() || root.relativize(f).toString().toLowerCase(Locale.ROOT).contains(q)) { any = true; break; }
        if (!any) q = "";
        List<Song> out = new ArrayList<>();
        for (Path f : files) {
            String rel = root.relativize(f).toString().replace('\\', '/');
            String file = f.getFileName().toString();
            String name = file.substring(0, file.lastIndexOf('.'));
            if (!q.isEmpty() && !rel.toLowerCase(Locale.ROOT).contains(q)) continue;
            Path parent = f.getParent();
            String artist = parent != null && !parent.equals(root) ? parent.getFileName().toString() : "Local music";
            out.add(new Song("local", rel, name, artist, "", duration(f), ""));
            if (out.size() >= 200) break;
        }
        return out;
    }

    private static long duration(Path f) {
        try {
            long size = Files.size(f);
            if (f.getFileName().toString().toLowerCase(Locale.ROOT).endsWith(".ogg")) return OggInfo.durationMs(f);
            try (InputStream in = Files.newInputStream(f)) {
                Bitstream bs = new Bitstream(in);
                Header h = bs.readFrame();
                if (h == null || h.bitrate() <= 0) return 0;
                return size * 8000L / h.bitrate(); // 以固定位元率估算
            }
        } catch (Throwable t) {
            return 0;
        }
    }

    private Path resolve(Song song) throws IOException {
        Path root = dir().toAbsolutePath().normalize();
        Path f = root.resolve(song.id()).normalize();
        if (!f.startsWith(root) || !Files.isRegularFile(f)) throw new IOException("no_audio:file not found");
        return f;
    }

    @Override
    public InputStream openAudio(Song song) throws Exception {
        return Files.newInputStream(resolve(song));
    }

    @Override
    public Lyrics fetchLyrics(Song song) throws Exception {
        Path f = resolve(song);
        String n = f.getFileName().toString();
        Path lrc = f.resolveSibling(n.substring(0, n.lastIndexOf('.')) + ".lrc");
        if (!Files.isRegularFile(lrc)) return Lyrics.EMPTY;
        return Lyrics.parse(new String(Files.readAllBytes(lrc), StandardCharsets.UTF_8), null);
    }
}
