package com.songrequest.api;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import java.io.IOException;
import java.io.InputStream;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/** Deezer 官方公開 API：完整的搜尋資訊，音訊為官方提供的 30 秒試聽 MP3。 */
public final class DeezerProvider implements MusicProvider {
    @Override public String id() { return "deezer"; }
    @Override public String displayName() { return "Deezer"; }
    @Override public String tag() { return "songrequest.tag.preview"; }

    @Override
    public List<Song> search(String keyword) throws Exception {
        return parseSearch(Http.get("https://api.deezer.com/search?limit=30&q=" + URLEncoder.encode(keyword.trim(), StandardCharsets.UTF_8),
                null, null, Http.UA_DESKTOP));
    }

    static List<Song> parseSearch(String body) {
        List<Song> out = new ArrayList<>();
        for (JsonElement el : Json.arr(Json.parse(body), "data")) {
            JsonObject s = el.getAsJsonObject();
            JsonObject artist = Json.obj(s, "artist"), album = Json.obj(s, "album");
            out.add(new Song("deezer", Json.str(s, "id", ""), Json.str(s, "title", "未知"),
                    Json.str(artist, "name", ""), Json.str(album, "title", ""), Json.num(s, "duration", 0) * 1000, ""));
        }
        return out;
    }

    @Override
    public InputStream openAudio(Song song) throws Exception {
        // 試聽網址帶有時效，播放前重新取得
        String preview = Json.str(Json.parse(Http.get("https://api.deezer.com/track/" + song.id(), null, null, Http.UA_DESKTOP)), "preview", "");
        if (preview.isEmpty()) throw new IOException("no_audio:deezer_no_preview");
        try {
            return Http.openAudio(preview, null, null);
        } catch (IOException e) {
            throw new IOException("no_audio:" + e.getMessage());
        }
    }

    @Override
    public Lyrics fetchLyrics(Song song) {
        return Lyrics.EMPTY;
    }
}
