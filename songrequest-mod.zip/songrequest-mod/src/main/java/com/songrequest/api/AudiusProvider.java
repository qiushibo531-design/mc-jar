package com.songrequest.api;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import java.io.IOException;
import java.io.InputStream;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/** Audius：去中心化的免費音樂平台，官方公開 API，完整曲目可直接串流。 */
public final class AudiusProvider implements MusicProvider {
    private static final String APP = "SongRequest";
    private static volatile String host;

    @Override public String id() { return "audius"; }
    @Override public String displayName() { return "Audius"; }
    @Override public String tag() { return "songrequest.tag.free"; }

    private static String host() {
        String h = host;
        if (h != null) return h;
        try {
            JsonElement first = Json.arr(Json.parse(Http.get("https://api.audius.co", null, null, Http.UA_DESKTOP)), "data").get(0);
            h = first.getAsString();
        } catch (Exception e) {
            h = "https://discoveryprovider.audius.co";
        }
        host = h;
        return h;
    }

    @Override
    public List<Song> search(String keyword) throws Exception {
        return parseSearch(Http.get(host() + "/v1/tracks/search?app_name=" + APP + "&query="
                + URLEncoder.encode(keyword.trim(), StandardCharsets.UTF_8), null, null, Http.UA_DESKTOP));
    }

    static List<Song> parseSearch(String body) {
        List<Song> out = new ArrayList<>();
        for (JsonElement el : Json.arr(Json.parse(body), "data")) {
            JsonObject s = el.getAsJsonObject();
            out.add(new Song("audius", Json.str(s, "id", ""), Json.str(s, "title", "未知"),
                    Json.str(Json.obj(s, "user"), "name", ""), Json.str(s, "genre", ""), Json.num(s, "duration", 0) * 1000, ""));
        }
        return out;
    }

    @Override
    public InputStream openAudio(Song song) throws Exception {
        try {
            return Http.openAudio(host() + "/v1/tracks/" + song.id() + "/stream?app_name=" + APP, null, null);
        } catch (IOException e) {
            host = null; // 下次重新挑選節點
            throw new IOException("no_audio:" + e.getMessage());
        }
    }

    @Override
    public Lyrics fetchLyrics(Song song) {
        return Lyrics.EMPTY;
    }
}
