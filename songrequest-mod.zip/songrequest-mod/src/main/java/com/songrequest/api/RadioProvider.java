package com.songrequest.api;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.IOException;
import java.io.InputStream;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/** 網路電台（radio-browser.info 公開目錄）。只列出 MP3 串流；電台沒有長度，進度條不可拖動。 */
public final class RadioProvider implements MusicProvider {
    private static final String[] HOSTS = {"de1.api.radio-browser.info", "de2.api.radio-browser.info", "nl1.api.radio-browser.info"};

    @Override public String id() { return "radio"; }
    @Override public String displayName() { return "网络电台 Radio"; }
    @Override public String tag() { return "songrequest.tag.live"; }

    @Override
    public List<Song> search(String keyword) throws Exception {
        String q = URLEncoder.encode(keyword.trim(), StandardCharsets.UTF_8);
        Exception last = null;
        for (String h : HOSTS) {
            try {
                String body = Http.get("https://" + h + "/json/stations/search?limit=25&hidebroken=true&codec=MP3&order=clickcount&reverse=true&name=" + q,
                        null, null, Http.UA_DESKTOP);
                List<Song> out = new ArrayList<>();
                for (JsonElement el : JsonParser.parseString(body).getAsJsonArray()) {
                    JsonObject o = el.getAsJsonObject();
                    String url = Json.str(o, "url_resolved", Json.str(o, "url", ""));
                    if (url.isEmpty()) continue;
                    String tags = Json.str(o, "tags", "");
                    String where = Json.str(o, "country", "");
                    out.add(new Song("radio", Json.str(o, "stationuuid", url), Json.str(o, "name", "未知").trim(),
                            where.isEmpty() ? tags : (tags.isEmpty() ? where : where + " · " + tags), "", 0, url));
                }
                return out;
            } catch (Exception e) {
                last = e;
            }
        }
        throw last == null ? new IOException("radio") : last;
    }

    @Override
    public InputStream openAudio(Song song) throws Exception {
        try {
            return Http.openAudio(song.extra(), null, null);
        } catch (IOException e) {
            throw new IOException("no_audio:" + e.getMessage());
        }
    }

    @Override
    public Lyrics fetchLyrics(Song song) {
        return Lyrics.EMPTY;
    }
}
