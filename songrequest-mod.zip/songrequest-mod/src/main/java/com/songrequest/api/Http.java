package com.songrequest.api;

import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;

/** 各音源共用的 HTTP 小工具。 */
final class Http {
    static final String UA_DESKTOP =
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36";
    static final String UA_MOBILE =
            "Mozilla/5.0 (Linux; Android 11; V2123A) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36";

    private static final HttpClient CLIENT = HttpClient.newBuilder()
            .followRedirects(HttpClient.Redirect.NORMAL)
            .connectTimeout(Duration.ofSeconds(10))
            .build();

    private Http() {}

    private static HttpRequest.Builder base(String url, String referer, String cookie, String ua) {
        HttpRequest.Builder b = HttpRequest.newBuilder(URI.create(url))
                .timeout(Duration.ofSeconds(20))
                .header("User-Agent", ua);
        if (referer != null) b.header("Referer", referer);
        if (cookie != null && !cookie.isBlank()) b.header("Cookie", cookie);
        return b;
    }

    static String get(String url, String referer, String cookie, String ua) throws IOException, InterruptedException {
        HttpResponse<String> r = CLIENT.send(base(url, referer, cookie, ua).GET().build(),
                HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
        if (r.statusCode() != 200) throw new IOException("HTTP " + r.statusCode());
        return r.body();
    }

    static String postJson(String url, String json, String referer, String cookie) throws IOException, InterruptedException {
        HttpRequest req = base(url, referer, cookie, UA_DESKTOP)
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(json, StandardCharsets.UTF_8)).build();
        HttpResponse<String> r = CLIENT.send(req, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
        if (r.statusCode() != 200) throw new IOException("HTTP " + r.statusCode());
        return r.body();
    }

    /** 開啟音訊串流；回應不是音訊時丟出 IOException（訊息為原因）。 */
    static InputStream openAudio(String url, String referer, String cookie) throws IOException, InterruptedException {
        HttpResponse<InputStream> r = CLIENT.send(base(url, referer, cookie, UA_MOBILE).GET().build(),
                HttpResponse.BodyHandlers.ofInputStream());
        String type = r.headers().firstValue("Content-Type").orElse("").toLowerCase();
        String finalUri = r.uri().toString();
        if (r.statusCode() != 200 || type.contains("text/") || type.contains("json") || finalUri.contains("/404")) {
            try { r.body().close(); } catch (IOException ignored) {}
            throw new IOException("http=" + r.statusCode() + " type=" + type + " uri=" + finalUri);
        }
        return r.body();
    }

    static String cookieOrDefault(String userCookie, String defaults) {
        if (userCookie == null || userCookie.isBlank()) return defaults;
        return userCookie.trim() + (defaults == null || defaults.isBlank() ? "" : "; " + defaults);
    }
}
