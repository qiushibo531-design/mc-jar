package com.songrequest.api;

import java.io.InputStream;
import java.util.List;

/** 一個音樂來源。要新增音源只要實作這個介面並加進 {@link Providers}。 */
public interface MusicProvider {
    /** 設定檔與 Song.source 使用的代號。 */
    String id();

    /** 介面上顯示的名稱。 */
    String displayName();

    /** 介面上顯示的簡短標籤（語言檔 key），沒有就回傳空字串。 */
    default String tag() { return ""; }

    /** 需要使用者填寫設定時，回傳設定欄位標題的語言檔 key；不需要就回傳 null。 */
    default String configLabel() { return null; }

    List<Song> search(String keyword) throws Exception;

    /**
     * 開啟 MP3 音訊串流。
     * 無法播放（VIP／無版權／需要登入）時丟出訊息以 "no_audio" 開頭的 IOException，
     * 冒號後面可附上詳細原因，例如 "no_audio:code=-110"。
     */
    InputStream openAudio(Song song) throws Exception;

    Lyrics fetchLyrics(Song song) throws Exception;
}
