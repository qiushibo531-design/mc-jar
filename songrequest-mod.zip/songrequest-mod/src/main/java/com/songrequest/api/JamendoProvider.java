package com.songrequest.api;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.songrequest.Config;

import java.io.IOException;
import java.io.InputStream;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/** Jamendo 官方 API：Creative Commons 授權的完整曲目。需要免費申請的 client_id（devportal.jamendo.com）。 */
public final class JamendoProvider implements MusicProvider {
    @Override public String id() { return "jamendo"; }
    @Override public String displayName() { return "Jamendo"; }
    @Override public String tag() { return "songrequest.tag.key"; }
    @Override public String configLabel() { return "songrequest.cfg.clientid"; }

    @Override
    public List<Song> search(String keyword) throws Exception {
        String key = Config.api("jamendo");
        if (key.isEmpty()) throw new IOException("need_config");
        return parseSearch(Http.get("https://api.jamendo.com/v3.0/tracks/?format=json&limit=30&audioformat=mp32&client_id="
                + URLEncoder.encode(key, StandardCharsets.UTF_8) + "&search=" + URLEncoder.encode(keyword.trim(), StandardCharsets.UTF_8),
                null, null, Http.UA_DESKTOP));
    }

    static List<Song> parseSearch(String body) {
        List<Song> out = new ArrayList<>();
        for (JsonElement el : Json.arr(Json.parse(body), "results")) {
            JsonObject s = el.getAsJsonObject();
            out.add(new Song("jamendo", Json.str(s, "id", ""), Json.str(s, "name", "未知"), Json.str(s, "artist_name", ""),
                    Json.str(s, "album_name", ""), Json.num(s, "duration", 0) * 1000, Json.str(s, "audio", "")));
        }
        return out;
    }

    @Override
    public InputStream openAudio(Song song) throws Exception {
        if (song.extra() == null || !song.extra().startsWith("http")) throw new IOException("no_audio:jamendo_no_audio");
        try {
            return Http.openAudio(song.extra(), null, null);
        } catch (IOException e) {
            throw new IOException("no_audio:" + e.getMessage());
        }
    }

    @Override
    public Lyrics fetchLyrics(Song song) {
        return Lyrics.EMPTY;
    }
}
