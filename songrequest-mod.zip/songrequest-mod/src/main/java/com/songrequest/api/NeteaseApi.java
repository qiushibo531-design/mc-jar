package com.songrequest.api;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

/** 網易雲音樂的公開網頁介面：搜尋、歌詞、音源。 */
public final class NeteaseApi {

    private static final String HOST = "https://music.163.com";
    private static final String UA =
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36";

    private static final HttpClient HTTP = HttpClient.newBuilder()
            .followRedirects(HttpClient.Redirect.NORMAL)
            .connectTimeout(Duration.ofSeconds(10))
            .build();

    private NeteaseApi() {}

    private static HttpRequest.Builder request(String url) {
        return HttpRequest.newBuilder(URI.create(url))
                .timeout(Duration.ofSeconds(20))
                .header("User-Agent", UA)
                .header("Referer", HOST + "/")
                .header("Cookie", "appver=2.0.2; os=pc");
    }

    private static String getString(String url) throws IOException, InterruptedException {
        HttpResponse<String> resp = HTTP.send(request(url).GET().build(),
                HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
        if (resp.statusCode() != 200) throw new IOException("HTTP " + resp.statusCode());
        return resp.body();
    }

    public static List<Song> search(String keyword) throws IOException, InterruptedException {
        String kw = URLEncoder.encode(keyword.trim(), StandardCharsets.UTF_8);
        String body = getString(HOST + "/api/search/get/web?csrf_token=&s=" + kw + "&type=1&offset=0&limit=30");
        List<Song> songs = parseSearch(body);
        if (songs.isEmpty()) {
            // 備援端點
            body = getString(HOST + "/api/search/get?s=" + kw + "&type=1&offset=0&limit=30");
            songs = parseSearch(body);
        }
        return songs;
    }

    static List<Song> parseSearch(String json) {
        List<Song> out = new ArrayList<>();
        JsonObject root = JsonParser.parseString(json).getAsJsonObject();
        JsonObject result = obj(root, "result");
        if (result == null) return out;
        JsonArray arr = result.has("songs") && result.get("songs").isJsonArray() ? result.getAsJsonArray("songs") : null;
        if (arr == null) return out;
        for (JsonElement el : arr) {
            JsonObject s = el.getAsJsonObject();
            long id = s.get("id").getAsLong();
            String name = str(s, "name", "未知");
            JsonArray artists = s.has("artists") ? s.getAsJsonArray("artists")
                    : s.has("ar") ? s.getAsJsonArray("ar") : new JsonArray();
            List<String> names = new ArrayList<>();
            for (JsonElement a : artists) names.add(str(a.getAsJsonObject(), "name", "?"));
            JsonObject album = obj(s, "album") != null ? obj(s, "album") : obj(s, "al");
            long dur = s.has("duration") ? s.get("duration").getAsLong()
                    : s.has("dt") ? s.get("dt").getAsLong() : 0;
            out.add(new Song(id, name, String.join(" / ", names),
                    album == null ? "" : str(album, "name", ""), dur));
        }
        return out;
    }

    public static Lyrics fetchLyrics(Song song) throws IOException, InterruptedException {
        String body = getString(HOST + "/api/song/lyric?id=" + song.id() + "&lv=-1&tv=-1");
        JsonObject root = JsonParser.parseString(body).getAsJsonObject();
        JsonObject lrc = obj(root, "lrc");
        JsonObject tlrc = obj(root, "tlyric");
        return Lyrics.parse(lrc == null ? null : str(lrc, "lyric", null),
                tlrc == null ? null : str(tlrc, "lyric", null));
    }

    /** 開啟音訊串流。無版權／VIP 歌曲會丟出 IOException。 */
    public static InputStream openAudio(Song song) throws IOException, InterruptedException {
        HttpResponse<InputStream> resp = HTTP.send(
                request(HOST + "/song/media/outer/url?id=" + song.id() + ".mp3").GET().build(),
                HttpResponse.BodyHandlers.ofInputStream());
        String type = resp.headers().firstValue("Content-Type").orElse("").toLowerCase();
        String finalUri = resp.uri().toString();
        if (resp.statusCode() != 200 || type.contains("text/html") || type.contains("json")
                || finalUri.contains("/404")) {
            try { resp.body().close(); } catch (IOException ignored) {}
            throw new IOException("no_audio");
        }
        return resp.body();
    }

    private static JsonObject obj(JsonObject o, String key) {
        return o.has(key) && o.get(key).isJsonObject() ? o.getAsJsonObject(key) : null;
    }

    private static String str(JsonObject o, String key, String def) {
        return o.has(key) && !o.get(key).isJsonNull() ? o.get(key).getAsString() : def;
    }
}
