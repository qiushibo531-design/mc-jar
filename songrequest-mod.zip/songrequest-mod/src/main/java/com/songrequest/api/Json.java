package com.songrequest.api;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

/** 容錯的 JSON 讀取小工具（寬鬆解析，容許單引號等不規範格式）。 */
final class Json {
    private Json() {}

    static JsonObject parse(String s) {
        JsonElement e = JsonParser.parseString(s);
        return e.isJsonObject() ? e.getAsJsonObject() : new JsonObject();
    }

    static JsonObject obj(JsonObject o, String k) {
        return o != null && o.has(k) && o.get(k).isJsonObject() ? o.getAsJsonObject(k) : null;
    }

    static JsonArray arr(JsonObject o, String k) {
        return o != null && o.has(k) && o.get(k).isJsonArray() ? o.getAsJsonArray(k) : new JsonArray();
    }

    static String str(JsonObject o, String k, String def) {
        if (o == null || !o.has(k) || o.get(k).isJsonNull() || !o.get(k).isJsonPrimitive()) return def;
        return o.get(k).getAsString();
    }

    static long num(JsonObject o, String k, long def) {
        try {
            return o != null && o.has(k) && !o.get(k).isJsonNull() ? (long) Double.parseDouble(o.get(k).getAsString()) : def;
        } catch (NumberFormatException e) {
            return def;
        }
    }

    static String clean(String s) {
        return s == null ? "" : s.replace("&nbsp;", " ").replace("&amp;", "&").replace("&apos;", "'")
                .replace("&quot;", "\"").replace("&lt;", "<").replace("&gt;", ">").trim();
    }
}
