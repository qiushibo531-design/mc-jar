package com.songrequest.api;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import java.io.IOException;
import java.io.InputStream;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/** 酷狗音乐（實驗）：搜尋用行動網頁介面；VIP／付費歌曲取不到連結會被略過。 */
public final class KugouProvider implements MusicProvider {
    @Override public String id() { return "kugou"; }
    @Override public String displayName() { return "酷狗音乐"; }
    @Override public String tag() { return "songrequest.tag.exp"; }

    @Override
    public List<Song> search(String keyword) throws Exception {
        String body = Http.get("https://mobilecdn.kugou.com/api/v3/search/song?format=json&page=1&pagesize=25&showtype=1&keyword="
                + URLEncoder.encode(keyword.trim(), StandardCharsets.UTF_8), null, null, Http.UA_MOBILE);
        List<Song> out = new ArrayList<>();
        for (JsonElement el : Json.arr(Json.obj(Json.parse(body), "data"), "info")) {
            JsonObject o = el.getAsJsonObject();
            out.add(new Song("kugou", Json.str(o, "hash", ""), Json.str(o, "songname", "未知"),
                    Json.str(o, "singername", ""), Json.str(o, "album_name", ""), Json.num(o, "duration", 0) * 1000, ""));
        }
        return out;
    }

    @Override
    public InputStream openAudio(Song song) throws Exception {
        String body = Http.get("https://m.kugou.com/app/i/getSongInfo.php?cmd=playInfo&hash=" + song.id(),
                "https://m.kugou.com/", null, Http.UA_MOBILE);
        String url = Json.str(Json.parse(body), "url", "");
        if (url.isEmpty()) throw new IOException("no_audio");
        try {
            return Http.openAudio(url, null, null);
        } catch (IOException e) {
            throw new IOException("no_audio:" + e.getMessage());
        }
    }

    @Override
    public Lyrics fetchLyrics(Song song) {
        return Lyrics.EMPTY;
    }
}
