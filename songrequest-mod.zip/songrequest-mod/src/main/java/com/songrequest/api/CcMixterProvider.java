package com.songrequest.api;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.IOException;
import java.io.InputStream;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/** ccMixter：Creative Commons 授權的混音／原創音樂，免金鑰、完整曲目。 */
public final class CcMixterProvider implements MusicProvider {
    @Override public String id() { return "ccmixter"; }
    @Override public String displayName() { return "ccMixter"; }
    @Override public String tag() { return "songrequest.tag.free"; }

    @Override
    public List<Song> search(String keyword) throws Exception {
        String body = Http.get("https://ccmixter.org/api/query?f=json&limit=25&sort=rank&search_type=all&search="
                + URLEncoder.encode(keyword.trim(), StandardCharsets.UTF_8), null, null, Http.UA_DESKTOP);
        JsonElement root = JsonParser.parseString(body);
        List<Song> out = new ArrayList<>();
        if (!root.isJsonArray()) return out;
        for (JsonElement el : (JsonArray) root) {
            JsonObject o = el.getAsJsonObject();
            String url = null;
            if (o.has("files") && o.get("files").isJsonArray()) {
                for (JsonElement fe : o.getAsJsonArray("files")) {
                    String u = Json.str(fe.getAsJsonObject(), "download_url", "");
                    if (u.toLowerCase().endsWith(".mp3")) { url = u; break; }
                }
            }
            if (url == null) continue;
            out.add(new Song("ccmixter", Json.str(o, "upload_id", url), Json.str(o, "upload_name", "未知"),
                    Json.str(o, "user_real_name", Json.str(o, "user_name", "")), "", 0, url));
        }
        return out;
    }

    @Override
    public InputStream openAudio(Song song) throws Exception {
        if (song.extra() == null || song.extra().isEmpty()) throw new IOException("no_audio");
        try {
            return Http.openAudio(song.extra(), null, null);
        } catch (IOException e) {
            throw new IOException("no_audio:" + e.getMessage());
        }
    }

    @Override
    public Lyrics fetchLyrics(Song song) {
        return Lyrics.EMPTY;
    }
}
