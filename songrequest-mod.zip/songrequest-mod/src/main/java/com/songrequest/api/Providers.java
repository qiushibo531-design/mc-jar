package com.songrequest.api;

import com.songrequest.Config;

import java.util.List;

public final class Providers {
    public static final List<MusicProvider> ALL = List.of(
            new NeteaseProvider(), new QQMusicProvider(), new KuwoProvider(), new MiguProvider(),
            new KugouProvider(), new AudiusProvider(), new ArchiveProvider(), new CcMixterProvider(), new RadioProvider(), new DeezerProvider(), new JamendoProvider(), new CustomApiProvider(), new LocalProvider());

    private Providers() {}

    public static MusicProvider byId(String id) {
        for (MusicProvider p : ALL) if (p.id().equals(id)) return p;
        return ALL.get(0);
    }

    public static MusicProvider selected() {
        return byId(Config.get().source);
    }

    public static void select(MusicProvider p) {
        Config.get().source = p.id();
    }
}
