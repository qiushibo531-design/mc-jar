package com.songrequest.api;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import java.io.IOException;
import java.io.InputStream;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/** 酷我音乐（非官方網頁介面，實驗性）。 */
public final class KuwoProvider implements MusicProvider {
    private static final String REF = "http://www.kuwo.cn/";

    @Override public String id() { return "kuwo"; }
    @Override public String displayName() { return "酷我音乐"; }
    @Override public String tag() { return "songrequest.tag.exp"; }

    @Override
    public List<Song> search(String keyword) throws Exception {
        String url = "http://search.kuwo.cn/r.s?client=kt&all=" + URLEncoder.encode(keyword.trim(), StandardCharsets.UTF_8)
                + "&pn=0&rn=30&ft=music&cluster=0&strategy=2012&encoding=utf8&rformat=json&vermerge=1&mobi=1";
        return parseSearch(Http.get(url, REF, null, Http.UA_DESKTOP));
    }

    static List<Song> parseSearch(String body) {
        List<Song> out = new ArrayList<>();
        for (JsonElement el : Json.arr(Json.parse(body), "abslist")) {
            JsonObject s = el.getAsJsonObject();
            String rid = Json.str(s, "MUSICRID", "").replace("MUSIC_", "");
            if (rid.isEmpty()) continue;
            out.add(new Song("kuwo", rid, Json.clean(Json.str(s, "SONGNAME", "未知")), Json.clean(Json.str(s, "ARTIST", "")),
                    Json.clean(Json.str(s, "ALBUM", "")), Json.num(s, "DURATION", 0) * 1000, ""));
        }
        return out;
    }

    @Override
    public InputStream openAudio(Song song) throws Exception {
        String url = Http.get("http://antiserver.kuwo.cn/anti.s?type=convert_url&format=mp3&response=url&rid=MUSIC_" + song.id(),
                REF, null, Http.UA_DESKTOP).trim();
        if (!url.startsWith("http")) throw new IOException("no_audio:kuwo_empty_url");
        try {
            return Http.openAudio(url, null, null);
        } catch (IOException e) {
            throw new IOException("no_audio:" + e.getMessage());
        }
    }

    @Override
    public Lyrics fetchLyrics(Song song) throws Exception {
        JsonObject data = Json.obj(Json.parse(Http.get("http://m.kuwo.cn/newh5/singles/songinfoandlrc?musicId=" + song.id(),
                REF, null, Http.UA_MOBILE)), "data");
        StringBuilder lrc = new StringBuilder();
        for (JsonElement el : Json.arr(data, "lrclist")) {
            JsonObject l = el.getAsJsonObject();
            long ms = (long) (Double.parseDouble(Json.str(l, "time", "0")) * 1000);
            lrc.append(String.format("[%02d:%02d.%02d]%s%n", ms / 60000, ms / 1000 % 60, ms % 1000 / 10, Json.str(l, "lineLyric", "")));
        }
        return Lyrics.parse(lrc.toString(), null);
    }
}
