package com.songrequest.api;

/** 一首歌曲的基本資訊（來自網易雲音樂搜尋結果）。 */
public record Song(long id, String name, String artist, String album, long durationMs) {

    public String durationText() {
        long s = Math.max(0, durationMs / 1000);
        return String.format("%d:%02d", s / 60, s % 60);
    }
}
