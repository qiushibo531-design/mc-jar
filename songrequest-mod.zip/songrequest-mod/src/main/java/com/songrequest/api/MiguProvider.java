package com.songrequest.api;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import java.io.IOException;
import java.io.InputStream;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/** 咪咕音乐（非官方網頁介面，實驗性）。搜尋結果自帶 mp3 與歌詞連結，存在 Song.extra。 */
public final class MiguProvider implements MusicProvider {
    private static final String REF = "https://m.music.migu.cn/";

    @Override public String id() { return "migu"; }
    @Override public String displayName() { return "咪咕音乐"; }
    @Override public String tag() { return "songrequest.tag.exp"; }

    @Override
    public List<Song> search(String keyword) throws Exception {
        String url = "https://m.music.migu.cn/migu/remoting/scr_search_tag?rows=30&type=2&pgc=1&keyword="
                + URLEncoder.encode(keyword.trim(), StandardCharsets.UTF_8);
        return parseSearch(Http.get(url, REF, null, Http.UA_MOBILE));
    }

    static List<Song> parseSearch(String body) {
        List<Song> out = new ArrayList<>();
        for (JsonElement el : Json.arr(Json.parse(body), "musics")) {
            JsonObject s = el.getAsJsonObject();
            String id = Json.str(s, "copyrightId", Json.str(s, "id", ""));
            if (id.isEmpty()) continue;
            out.add(new Song("migu", id, Json.clean(Json.str(s, "songName", "未知")), Json.clean(Json.str(s, "singerName", "")),
                    Json.clean(Json.str(s, "albumName", "")), 0,
                    Json.str(s, "mp3", "") + "\n" + Json.str(s, "lrcUrl", "")));
        }
        return out;
    }

    @Override
    public InputStream openAudio(Song song) throws Exception {
        String url = song.extra() == null ? "" : song.extra().split("\n", -1)[0];
        if (!url.startsWith("http")) throw new IOException("no_audio:migu_no_mp3");
        try {
            return Http.openAudio(url, REF, null);
        } catch (IOException e) {
            throw new IOException("no_audio:" + e.getMessage());
        }
    }

    @Override
    public Lyrics fetchLyrics(Song song) throws Exception {
        String[] p = song.extra() == null ? new String[0] : song.extra().split("\n", -1);
        if (p.length < 2 || !p[1].startsWith("http")) return Lyrics.EMPTY;
        return Lyrics.parse(Http.get(p[1], REF, null, Http.UA_MOBILE), null);
    }
}
