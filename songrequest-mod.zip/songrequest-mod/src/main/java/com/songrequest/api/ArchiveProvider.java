package com.songrequest.api;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import java.io.IOException;
import java.io.InputStream;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/** Internet Archive：海量公有領域／授權自由的音樂與錄音，完整曲目，免金鑰。 */
public final class ArchiveProvider implements MusicProvider {
    @Override public String id() { return "archive"; }
    @Override public String displayName() { return "Internet Archive"; }
    @Override public String tag() { return "songrequest.tag.free"; }

    private static String enc(String s) {
        return URLEncoder.encode(s, StandardCharsets.UTF_8).replace("+", "%20");
    }

    @Override
    public List<Song> search(String keyword) throws Exception {
        String q = "(title:(" + keyword.trim() + ") OR creator:(" + keyword.trim() + ")) AND mediatype:audio";
        String body = Http.get("https://archive.org/advancedsearch.php?q=" + enc(q)
                + "&fl%5B%5D=identifier&fl%5B%5D=title&fl%5B%5D=creator&sort%5B%5D=downloads+desc&rows=25&output=json",
                null, null, Http.UA_DESKTOP);
        List<Song> out = new ArrayList<>();
        for (JsonElement el : Json.arr(Json.obj(Json.parse(body), "response"), "docs")) {
            JsonObject d = el.getAsJsonObject();
            String creator = d.has("creator") && d.get("creator").isJsonPrimitive() ? d.get("creator").getAsString() : "";
            out.add(new Song("archive", Json.str(d, "identifier", ""), Json.str(d, "title", "未知"), creator, "", 0, ""));
        }
        return out;
    }

    @Override
    public InputStream openAudio(Song song) throws Exception {
        String meta = Http.get("https://archive.org/metadata/" + enc(song.id()), null, null, Http.UA_DESKTOP);
        String best = null;
        for (JsonElement el : Json.arr(Json.parse(meta), "files")) {
            JsonObject f = el.getAsJsonObject();
            String name = Json.str(f, "name", "");
            if (name.toLowerCase().endsWith(".mp3")) {
                best = name;
                if (!"Original".equalsIgnoreCase(Json.str(f, "source", ""))) break; // 優先衍生的 MP3（通常較小）
            }
        }
        if (best == null) throw new IOException("no_audio:no mp3");
        try {
            return Http.openAudio("https://archive.org/download/" + enc(song.id()) + "/" + enc(best).replace("%2F", "/"), null, null);
        } catch (IOException e) {
            throw new IOException("no_audio:" + e.getMessage());
        }
    }

    @Override
    public Lyrics fetchLyrics(Song song) {
        return Lyrics.EMPTY;
    }
}
