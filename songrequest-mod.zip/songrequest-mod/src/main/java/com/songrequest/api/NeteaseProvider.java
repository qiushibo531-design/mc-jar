package com.songrequest.api;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.songrequest.Config;
import com.songrequest.SongRequestClient;

import java.io.IOException;
import java.io.InputStream;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/** 網易雲音樂（網頁公開介面）。 */
public final class NeteaseProvider implements MusicProvider {
    private static final String HOST = "https://music.163.com";

    @Override public String id() { return "netease"; }
    @Override public String displayName() { return "网易云音乐"; }
    @Override public String configLabel() { return "songrequest.cfg.cookie"; }

    private static String cookie() {
        return Http.cookieOrDefault(Config.api("netease"), "appver=2.0.2; os=pc");
    }

    private static String get(String url) throws IOException, InterruptedException {
        return Http.get(url, HOST + "/", cookie(), Http.UA_DESKTOP);
    }

    @Override
    public List<Song> search(String keyword) throws Exception {
        String kw = URLEncoder.encode(keyword.trim(), StandardCharsets.UTF_8);
        List<Song> songs = parseSearch(get(HOST + "/api/search/get/web?csrf_token=&s=" + kw + "&type=1&offset=0&limit=30"));
        if (songs.isEmpty()) songs = parseSearch(get(HOST + "/api/search/get?s=" + kw + "&type=1&offset=0&limit=30"));
        return songs;
    }

    static List<Song> parseSearch(String json) {
        List<Song> out = new ArrayList<>();
        JsonObject result = obj(JsonParser.parseString(json).getAsJsonObject(), "result");
        if (result == null || !result.has("songs") || !result.get("songs").isJsonArray()) return out;
        for (JsonElement el : result.getAsJsonArray("songs")) {
            JsonObject s = el.getAsJsonObject();
            JsonArray artists = s.has("artists") ? s.getAsJsonArray("artists")
                    : s.has("ar") ? s.getAsJsonArray("ar") : new JsonArray();
            List<String> names = new ArrayList<>();
            for (JsonElement a : artists) names.add(str(a.getAsJsonObject(), "name", "?"));
            JsonObject album = obj(s, "album") != null ? obj(s, "album") : obj(s, "al");
            long dur = s.has("duration") ? s.get("duration").getAsLong() : s.has("dt") ? s.get("dt").getAsLong() : 0;
            out.add(new Song("netease", s.get("id").getAsString(), str(s, "name", "未知"),
                    String.join(" / ", names), album == null ? "" : str(album, "name", ""), dur, ""));
        }
        return out;
    }

    @Override
    public Lyrics fetchLyrics(Song song) throws Exception {
        JsonObject root = JsonParser.parseString(get(HOST + "/api/song/lyric?id=" + song.id() + "&lv=-1&tv=-1")).getAsJsonObject();
        JsonObject lrc = obj(root, "lrc"), tlrc = obj(root, "tlyric");
        return Lyrics.parse(lrc == null ? null : str(lrc, "lyric", null), tlrc == null ? null : str(tlrc, "lyric", null));
    }

    @Override
    public InputStream openAudio(Song song) throws Exception {
        // 方法一：與 SimpMusic 相同的 enhance/player/url（回傳 JSON，其中 data[0].url 是 CDN 直連）
        String reason = "";
        for (int br : new int[]{320000, 128000}) {
            try {
                String body = get(HOST + "/api/song/enhance/player/url?ids=[" + song.id() + "]&br=" + br + "&encodeType=mp3");
                JsonObject root = JsonParser.parseString(body).getAsJsonObject();
                JsonArray data = root.has("data") && root.get("data").isJsonArray() ? root.getAsJsonArray("data") : null;
                if (data == null || data.isEmpty()) {
                    reason = "empty_data(code=" + str(root, "code", "?") + ")";
                    continue;
                }
                JsonObject d = data.get(0).getAsJsonObject();
                String url = d.has("url") && !d.get("url").isJsonNull() ? d.get("url").getAsString() : null;
                if (url == null || url.isEmpty()) {
                    reason = "no_url(code=" + str(d, "code", "?") + ",fee=" + str(d, "fee", "?") + ")";
                    continue;
                }
                return openCdn(url);
            } catch (IOException e) {
                reason = e.getMessage();
                SongRequestClient.LOGGER.warn("netease player/url br={} failed: {}", br, e.toString());
            }
        }
        // 方法二：舊的 outer/url 入口
        try {
            return Http.openAudio(HOST + "/song/media/outer/url?id=" + song.id() + ".mp3", HOST + "/", cookie());
        } catch (IOException e) {
            reason += " | outer:" + e.getMessage();
        }
        SongRequestClient.LOGGER.warn("netease no audio for {}: {}", song.id(), reason);
        throw new IOException("no_audio:" + reason);
    }

    private static InputStream openCdn(String url) throws IOException, InterruptedException {
        String https = url.startsWith("http://") ? "https://" + url.substring(7) : url;
        try {
            return Http.openAudio(https, HOST + "/", null);
        } catch (IOException e) {
            if (https.equals(url)) throw e;
            return Http.openAudio(url, HOST + "/", null);
        }
    }

    private static JsonObject obj(JsonObject o, String key) {
        return o.has(key) && o.get(key).isJsonObject() ? o.getAsJsonObject(key) : null;
    }

    private static String str(JsonObject o, String key, String def) {
        return o.has(key) && !o.get(key).isJsonNull() ? o.get(key).getAsString() : def;
    }
}
