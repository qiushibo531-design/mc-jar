package com.songrequest.api;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.songrequest.Config;
import com.songrequest.SongRequestClient;

import java.io.IOException;
import java.io.InputStream;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * QQ 音樂（非官方網頁介面，實驗性）。
 * 多數歌曲現在需要登入 Cookie 才拿得到播放網址，Cookie 填在 config/songrequest.json 的 qqCookie。
 */
public final class QQMusicProvider implements MusicProvider {
    private static final String API = "https://u.y.qq.com/cgi-bin/musicu.fcg";
    private static final String REFERER = "https://y.qq.com/";
    private static final Pattern UIN = Pattern.compile("(?:^|;\\s*)(?:uin|wxuin)=o?0*(\\d+)");

    @Override public String id() { return "qq"; }
    @Override public String displayName() { return "QQ音乐"; }
    @Override public String tag() { return "songrequest.tag.exp"; }
    @Override public String configLabel() { return "songrequest.cfg.cookie"; }

    private static String cookie() {
        return Config.api("qq");
    }

    private static String uin() {
        Matcher m = UIN.matcher(cookie());
        return m.find() ? m.group(1) : "0";
    }

    private static String comm() {
        return "{\"ct\":19,\"cv\":1859,\"uin\":\"" + uin() + "\"}";
    }

    @Override
    public List<Song> search(String keyword) throws Exception {
        JsonObject param = new JsonObject();
        param.addProperty("grp", 1);
        param.addProperty("num_per_page", 30);
        param.addProperty("page_num", 1);
        param.addProperty("query", keyword.trim());
        param.addProperty("search_type", 0);
        JsonObject req = new JsonObject();
        req.addProperty("method", "DoSearchForQQMusicDesktop");
        req.addProperty("module", "music.search.SearchCgiService");
        req.add("param", param);
        JsonObject root = new JsonObject();
        root.add("comm", JsonParser.parseString(comm()));
        root.add("req", req);
        return parseSearch(Http.postJson(API, root.toString(), REFERER, cookie()));
    }

    static List<Song> parseSearch(String json) {
        List<Song> out = new ArrayList<>();
        JsonObject root = JsonParser.parseString(json).getAsJsonObject();
        JsonObject list = path(root, "req", "data", "body", "song");
        if (list == null || !list.has("list") || !list.get("list").isJsonArray()) return out;
        for (JsonElement el : list.getAsJsonArray("list")) {
            JsonObject s = el.getAsJsonObject();
            String mid = str(s, "mid", "");
            if (mid.isEmpty()) continue;
            List<String> singers = new ArrayList<>();
            if (s.has("singer") && s.get("singer").isJsonArray()) {
                for (JsonElement a : s.getAsJsonArray("singer")) singers.add(str(a.getAsJsonObject(), "name", "?"));
            }
            JsonObject album = s.has("album") && s.get("album").isJsonObject() ? s.getAsJsonObject("album") : null;
            JsonObject file = s.has("file") && s.get("file").isJsonObject() ? s.getAsJsonObject("file") : null;
            String mediaMid = file == null ? mid : str(file, "media_mid", mid);
            long sec = s.has("interval") ? s.get("interval").getAsLong() : 0;
            out.add(new Song("qq", mid, str(s, "name", str(s, "title", "未知")), String.join(" / ", singers),
                    album == null ? "" : str(album, "name", ""), sec * 1000, mediaMid));
        }
        return out;
    }

    @Override
    public InputStream openAudio(Song song) throws Exception {
        String media = song.extra() == null || song.extra().isEmpty() ? song.id() : song.extra();
        String filename = "M500" + media + ".mp3"; // 128kbps MP3
        JsonObject param = new JsonObject();
        param.addProperty("guid", "10000");
        JsonArray mids = new JsonArray(); mids.add(song.id());
        JsonArray types = new JsonArray(); types.add(0);
        JsonArray files = new JsonArray(); files.add(filename);
        param.add("songmid", mids);
        param.add("songtype", types);
        param.add("filename", files);
        param.addProperty("uin", uin());
        param.addProperty("loginflag", 1);
        param.addProperty("platform", "20");
        JsonObject req = new JsonObject();
        req.addProperty("module", "vkey.GetVkeyServer");
        req.addProperty("method", "CgiGetVkey");
        req.add("param", param);
        JsonObject root = new JsonObject();
        root.add("comm", JsonParser.parseString(comm()));
        root.add("req", req);

        JsonObject data = path(JsonParser.parseString(Http.postJson(API, root.toString(), REFERER, cookie())).getAsJsonObject(),
                "req", "data");
        String purl = null, sip = null;
        if (data != null) {
            if (data.has("sip") && data.get("sip").isJsonArray() && !data.getAsJsonArray("sip").isEmpty()) {
                sip = data.getAsJsonArray("sip").get(0).getAsString();
            }
            if (data.has("midurlinfo") && data.get("midurlinfo").isJsonArray() && !data.getAsJsonArray("midurlinfo").isEmpty()) {
                purl = str(data.getAsJsonArray("midurlinfo").get(0).getAsJsonObject(), "purl", "");
            }
        }
        if (purl == null || purl.isEmpty() || sip == null) {
            String why = cookie().isBlank() ? "need_login_cookie(qqCookie)" : "purl_empty(VIP_or_cookie_expired)";
            SongRequestClient.LOGGER.warn("qq no audio for {}: {}", song.id(), why);
            throw new IOException("no_audio:" + why);
        }
        try {
            return Http.openAudio(sip + purl, REFERER, null);
        } catch (IOException e) {
            throw new IOException("no_audio:" + e.getMessage());
        }
    }

    @Override
    public Lyrics fetchLyrics(Song song) throws Exception {
        String body = Http.get("https://c.y.qq.com/lyric/fcgi-bin/fcg_query_lyric_new.fcg?songmid=" + URLEncoder.encode(song.id(), StandardCharsets.UTF_8)
                + "&format=json&nobase64=0&g_tk=5381", REFERER, cookie(), Http.UA_DESKTOP);
        JsonObject root = JsonParser.parseString(body).getAsJsonObject();
        return Lyrics.parse(decode(str(root, "lyric", null)), decode(str(root, "trans", null)));
    }

    /** QQ 的歌詞預設是 Base64，部分情況是純文字；並還原 HTML 實體。 */
    static String decode(String s) {
        if (s == null || s.isBlank()) return null;
        String text = s;
        if (!s.contains("[")) {
            try {
                text = new String(Base64.getDecoder().decode(s.trim()), StandardCharsets.UTF_8);
            } catch (IllegalArgumentException ignored) {
                text = s;
            }
        }
        return text.replace("&apos;", "'").replace("&quot;", "\"").replace("&lt;", "<")
                .replace("&gt;", ">").replace("&amp;", "&");
    }

    private static JsonObject path(JsonObject o, String... keys) {
        JsonObject cur = o;
        for (String k : keys) {
            if (cur == null || !cur.has(k) || !cur.get(k).isJsonObject()) return null;
            cur = cur.getAsJsonObject(k);
        }
        return cur;
    }

    private static String str(JsonObject o, String key, String def) {
        return o.has(key) && !o.get(key).isJsonNull() ? o.get(key).getAsString() : def;
    }
}
