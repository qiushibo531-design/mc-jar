package com.songrequest.audio;

import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.file.Path;

/** 不解碼，直接從 OGG Vorbis 檔案讀出長度（最後一頁的 granule position ÷ 取樣率）。 */
public final class OggInfo {
    private OggInfo() {}

    public static long durationMs(Path p) throws IOException {
        try (RandomAccessFile f = new RandomAccessFile(p.toFile(), "r")) {
            byte[] head = new byte[96];
            int n = f.read(head);
            int i = -1;
            for (int k = 0; k + 6 < n; k++) {
                if (head[k] == 'v' && head[k + 1] == 'o' && head[k + 2] == 'r' && head[k + 3] == 'b' && head[k + 4] == 'i' && head[k + 5] == 's') {
                    i = k;
                    break;
                }
            }
            if (i < 0 || i + 15 > n) return 0;
            long rate = le(head, i + 11, 4);
            if (rate <= 0) return 0;
            long len = f.length();
            int tail = (int) Math.min(len, 65536);
            byte[] t = new byte[tail];
            f.seek(len - tail);
            f.readFully(t);
            for (int k = tail - 14; k >= 0; k--) {
                if (t[k] == 'O' && t[k + 1] == 'g' && t[k + 2] == 'g' && t[k + 3] == 'S') {
                    long gp = le(t, k + 6, 8);
                    return gp > 0 ? gp * 1000L / rate : 0;
                }
            }
            return 0;
        }
    }

    private static long le(byte[] b, int off, int n) {
        long v = 0;
        for (int i = n - 1; i >= 0; i--) v = (v << 8) | (b[off + i] & 255);
        return v;
    }
}
