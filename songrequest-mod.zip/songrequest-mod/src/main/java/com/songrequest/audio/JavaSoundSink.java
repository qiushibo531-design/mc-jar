package com.songrequest.audio;

import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.SourceDataLine;

/** 以 javax.sound 輸出，與 Minecraft 自己的 OpenAL 互不干擾。 */
public final class JavaSoundSink implements AudioSink {
    private volatile SourceDataLine line;

    @Override
    public void open(int sampleRate, int channels) throws Exception {
        AudioFormat fmt = new AudioFormat(sampleRate, 16, channels, true, false);
        int frame = channels * 2;
        int buffer = (sampleRate / 5) * frame; // 約 0.2 秒，讓音量調整與暫停反應迅速
        SourceDataLine l = AudioSystem.getSourceDataLine(fmt);
        l.open(fmt, buffer);
        l.start();
        line = l;
    }

    @Override
    public void write(byte[] data, int off, int len) {
        SourceDataLine l = line;
        if (l == null) return;
        while (len > 0) {
            int n = l.write(data, off, len);
            if (n <= 0) return; // 已被關閉
            off += n;
            len -= n;
        }
    }

    @Override
    public void pause() {
        SourceDataLine l = line;
        if (l != null) l.stop();
    }

    @Override
    public void resume() {
        SourceDataLine l = line;
        if (l != null) l.start();
    }

    @Override
    public long positionMicros() {
        SourceDataLine l = line;
        return l == null ? 0 : l.getMicrosecondPosition();
    }

    @Override
    public void drain() {
        SourceDataLine l = line;
        if (l == null) return;
        l.drain();
        l.stop();
        l.close();
    }

    @Override
    public void abort() {
        SourceDataLine l = line;
        if (l == null) return;
        l.stop();
        l.flush();
        l.close();
    }
}
