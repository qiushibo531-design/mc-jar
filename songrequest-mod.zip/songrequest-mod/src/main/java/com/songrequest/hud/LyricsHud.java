package com.songrequest.hud;

import com.songrequest.Config;
import com.songrequest.SongRequestClient;
import com.songrequest.api.Lyrics;
import com.songrequest.api.Song;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;

/**
 * 螢幕正上方的「正在播放」字幕：
 * 第一行 歌名 - 歌手（小字）、第二行 當前歌詞（大字）、第三行 翻譯／下一句（小字）。
 */
public final class LyricsHud {
    private static int lastIndex = Integer.MIN_VALUE;
    private static Song lastSong;
    private static long changeNanos;

    private LyricsHud() {}

    private record Row(String text, float scale, int rgb) {}

    public static void render(DrawContext ctx, float tickDelta) {
        Config cfg = Config.get();
        Song song = SongRequestClient.PLAYER.current();
        MinecraftClient mc = MinecraftClient.getInstance();
        if (!cfg.hudEnabled || song == null || mc.options.hudHidden) return;

        TextRenderer tr = mc.textRenderer;
        Lyrics lyrics = SongRequestClient.PLAYER.lyrics();

        String header = "♪ " + song.name() + " - " + song.artist();
        if (SongRequestClient.PLAYER.isLoading()) header += "  " + Text.translatable("songrequest.hud.loading").getString();
        else if (SongRequestClient.PLAYER.isPaused()) header += "  " + Text.translatable("songrequest.hud.paused").getString();

        List<Row> rows = new ArrayList<>();
        rows.add(new Row(header, 0.8f, 0xB8C0CC));

        long pos = SongRequestClient.PLAYER.positionMs() + cfg.lyricOffsetMs;
        int idx = lyrics.indexAt(pos);
        if (song != lastSong || idx != lastIndex) {
            lastSong = song;
            lastIndex = idx;
            changeNanos = System.nanoTime();
        }

        Lyrics.Line cur = lyrics.get(idx);
        Lyrics.Line next = lyrics.get(idx + 1);
        if (cur != null && !cur.text().isEmpty()) {
            rows.add(new Row(cur.text(), 1.3f, 0xFFFFFF));
            if (cfg.showTranslation && cur.translation() != null && !cur.translation().isEmpty()) {
                rows.add(new Row(cur.translation(), 0.9f, 0xFFD966));
            } else if (next != null && !next.text().isEmpty()) {
                rows.add(new Row(next.text(), 0.85f, 0x8E97A5));
            }
        } else if (next != null && !next.text().isEmpty() && idx < 0) {
            rows.add(new Row(next.text(), 0.9f, 0x8E97A5));
        }

        // 淡入：換句時 150ms 內由透明變實體（文字 alpha 太低會被原版當成不透明，所以下限 8）
        float fade = Math.min(1f, (System.nanoTime() - changeNanos) / 150_000_000f);
        int alpha = Math.max(8, (int) (255 * fade));

        float s = cfg.hudScale;
        float lineGap = 2f * s;
        float totalH = 0, maxW = 0;
        for (Row r : rows) {
            totalH += tr.fontHeight * r.scale * s + lineGap;
            maxW = Math.max(maxW, tr.getWidth(r.text) * r.scale * s);
        }
        totalH -= lineGap;

        int cx = ctx.getScaledWindowWidth() / 2;
        float y = cfg.hudY;

        if (cfg.hudBackground) {
            int padX = Math.round(8 * s), padY = Math.round(4 * s);
            int x1 = Math.round(cx - maxW / 2f) - padX;
            int x2 = Math.round(cx + maxW / 2f) + padX;
            int y1 = Math.round(y) - padY;
            int y2 = Math.round(y + totalH) + padY;
            ctx.fill(x1, y1, x2, y2, 0x66000000);
            ctx.fill(x1, y1, x2, y1 + 1, 0x33FFFFFF); // 頂部細亮線
        }

        for (int i = 0; i < rows.size(); i++) {
            Row r = rows.get(i);
            float sc = r.scale * s;
            int rowAlpha = i == 1 ? alpha : 255; // 只有歌詞行做淡入
            int color = (rowAlpha << 24) | r.rgb;
            int w = tr.getWidth(r.text);
            ctx.getMatrices().push();
            ctx.getMatrices().translate(cx, y, 0);
            ctx.getMatrices().scale(sc, sc, 1f);
            ctx.drawText(tr, r.text, -w / 2, 0, color, true);
            ctx.getMatrices().pop();
            y += tr.fontHeight * sc + lineGap;
        }
    }
}
