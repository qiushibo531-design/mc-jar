package com.songrequest.gui;

import net.minecraft.client.gui.DrawContext;

/**
 * 「液態玻璃」風格的繪製工具。
 * Minecraft 沒有簡單的背景模糊可用（尤其在手機啟動器上），所以用多層半透明、
 * 頂部高光、細邊框與柔和陰影來模擬玻璃質感。全部使用 DrawContext.fill，沒有額外依賴。
 */
final class Glass {
    static final int ACCENT = 0xFF5AC8FA;
    static final int TEXT = 0xFFFFFFFF;
    static final int SUB = 0xFFB4BDCC;
    static final int ERR = 0xFFFF8A8A;

    private Glass() {}

    static int alpha(int argb, int a) {
        return (a << 24) | (argb & 0xFFFFFF);
    }

    /** 實心圓角矩形（半透明顏色也不會重疊疊色）。 */
    static void roundRect(DrawContext c, int x, int y, int w, int h, int r, int color) {
        if (w <= 0 || h <= 0) return;
        r = Math.max(0, Math.min(r, Math.min(w, h) / 2));
        if (r == 0) {
            c.fill(x, y, x + w, y + h, color);
            return;
        }
        c.fill(x, y + r, x + w, y + h - r, color);
        for (int i = 0; i < r; i++) {
            int inset = inset(r, i);
            c.fill(x + inset, y + i, x + w - inset, y + i + 1, color);
            c.fill(x + inset, y + h - 1 - i, x + w - inset, y + h - i, color);
        }
    }

    private static int inset(int r, int row) {
        double dy = r - row - 0.5;
        return r - (int) Math.round(Math.sqrt(Math.max(0, r * r - dy * dy)));
    }

    /** 1 像素圓角外框。 */
    static void roundOutline(DrawContext c, int x, int y, int w, int h, int r, int color) {
        if (w <= 2 || h <= 2) return;
        r = Math.max(0, Math.min(r, Math.min(w, h) / 2));
        if (r == 0) {
            c.fill(x, y, x + w, y + 1, color);
            c.fill(x, y + h - 1, x + w, y + h, color);
            c.fill(x, y + 1, x + 1, y + h - 1, color);
            c.fill(x + w - 1, y + 1, x + w, y + h - 1, color);
            return;
        }
        int prev = r;
        for (int i = 0; i < r; i++) {
            int in = inset(r, i);
            if (i == 0) {
                c.fill(x + in, y, x + w - in, y + 1, color);
                c.fill(x + in, y + h - 1, x + w - in, y + h, color);
            } else {
                int end = Math.max(in + 1, prev);
                c.fill(x + in, y + i, x + end, y + i + 1, color);
                c.fill(x + w - end, y + i, x + w - in, y + i + 1, color);
                c.fill(x + in, y + h - 1 - i, x + end, y + h - i, color);
                c.fill(x + w - end, y + h - 1 - i, x + w - in, y + h - i, color);
            }
            prev = in;
        }
        c.fill(x, y + r, x + 1, y + h - r, color);
        c.fill(x + w - 1, y + r, x + w, y + h - r, color);
    }

    /** 玻璃面板：陰影 + 通透的冷色底 + 漸層高光 + 雙層邊緣（外亮內淡）+ 頂緣與左緣高光。 */
    static void panel(DrawContext c, int x, int y, int w, int h, int r, boolean shadow) {
        if (shadow) {
            for (int k = 7; k >= 1; k--) {
                roundRect(c, x - k, y - k + 3, w + 2 * k, h + 2 * k, r + k, 0x0A000000);
            }
        }
        roundRect(c, x, y, w, h, r, 0x6E1B2840);                       // 通透冷色底（比之前更透）
        roundRect(c, x + 1, y + 1, w - 2, h - 2, Math.max(0, r - 1), 0x10FFFFFF); // 整體提亮一層
        // 上半部高光：疊多層逐漸變短的淡白色，形成由上往下淡出的漸層（沒有硬邊）
        for (int i = 0; i < 9; i++) {
            int bandH = Math.max(4, h * (58 - i * 6) / 100);
            roundRect(c, x + 1, y + 1, w - 2, bandH, Math.max(0, r - 1), 0x07FFFFFF);
        }
        roundRect(c, x + 3, y + h - 8, w - 6, 6, 3, 0x12FFFFFF);       // 底部折射反光
        roundOutline(c, x, y, w, h, r, 0x99FFFFFF);                    // 外緣亮邊
        roundOutline(c, x + 1, y + 1, w - 2, h - 2, Math.max(0, r - 1), 0x1EFFFFFF); // 內緣淡邊 → 厚玻璃邊
        c.fill(x + r, y + 1, x + w - r, y + 2, 0xCCFFFFFF);            // 頂緣高光
        c.fill(x + 1, y + r, x + 2, y + h / 2, 0x66FFFFFF);            // 左緣高光
    }

    /** 面板內的次級卡片：比面板更亮的淡玻璃。 */
    static void card(DrawContext c, int x, int y, int w, int h, int r) {
        roundRect(c, x, y, w, h, r, 0x240A1424);
        roundRect(c, x + 1, y + 1, w - 2, Math.max(3, h / 3), Math.max(0, r - 1), 0x0CFFFFFF);
        roundOutline(c, x, y, w, h, r, 0x40FFFFFF);
        c.fill(x + r, y + 1, x + w - r, y + 2, 0x38FFFFFF);
    }

    /** 膠囊按鈕（ReGlass 風格：白色亮邊、內部高光、按下更亮）。accent 為主要操作。 */
    static void pill(DrawContext c, int x, int y, int w, int h, boolean hover, boolean accent) {
        int r = h / 2;
        if (accent) {
            for (int k = 3; k >= 1; k--) roundRect(c, x - k, y - k, w + 2 * k, h + 2 * k, r + k, hover ? 0x1A5AC8FA : 0x105AC8FA); // 柔光
            roundRect(c, x, y, w, h, r, hover ? 0xCC63CFFF : 0xA83AA5DA);
            roundRect(c, x + 1, y + 1, w - 2, Math.max(2, h / 2 - 1), Math.max(0, r - 1), 0x30FFFFFF);
            roundOutline(c, x, y, w, h, r, hover ? 0xFFFFFFFF : 0xB4FFFFFF);
        } else {
            roundRect(c, x, y, w, h, r, hover ? 0x4CFFFFFF : 0x2CFFFFFF);
            roundRect(c, x + 1, y + 1, w - 2, Math.max(2, h / 2 - 1), Math.max(0, r - 1), hover ? 0x2AFFFFFF : 0x16FFFFFF);
            roundOutline(c, x, y, w, h, r, hover ? 0xE6FFFFFF : 0x99FFFFFF);
        }
        c.fill(x + r, y + h - 2, x + w - r, y + h - 1, 0x16000000);    // 底部內陰影，增加立體感
    }
}
