package com.songrequest.gui;

import net.minecraft.client.gui.DrawContext;

/**
 * 「液態玻璃」風格的繪製工具。
 * Minecraft 沒有簡單的背景模糊可用（尤其在手機啟動器上），所以用多層半透明、
 * 頂部高光、細邊框與柔和陰影來模擬玻璃質感。全部使用 DrawContext.fill，沒有額外依賴。
 */
final class Glass {
    static final int ACCENT = 0xFF5AC8FA;
    static final int TEXT = 0xFFFFFFFF;
    static final int SUB = 0xFFB4BDCC;
    static final int ERR = 0xFFFF8A8A;

    private Glass() {}

    static int alpha(int argb, int a) {
        return (a << 24) | (argb & 0xFFFFFF);
    }

    /** 實心圓角矩形（半透明顏色也不會重疊疊色）。 */
    static void roundRect(DrawContext c, int x, int y, int w, int h, int r, int color) {
        if (w <= 0 || h <= 0) return;
        r = Math.max(0, Math.min(r, Math.min(w, h) / 2));
        if (r == 0) {
            c.fill(x, y, x + w, y + h, color);
            return;
        }
        c.fill(x, y + r, x + w, y + h - r, color);
        for (int i = 0; i < r; i++) {
            int inset = inset(r, i);
            c.fill(x + inset, y + i, x + w - inset, y + i + 1, color);
            c.fill(x + inset, y + h - 1 - i, x + w - inset, y + h - i, color);
        }
    }

    private static int inset(int r, int row) {
        double dy = r - row - 0.5;
        return r - (int) Math.round(Math.sqrt(Math.max(0, r * r - dy * dy)));
    }

    /** 1 像素圓角外框。 */
    static void roundOutline(DrawContext c, int x, int y, int w, int h, int r, int color) {
        if (w <= 2 || h <= 2) return;
        r = Math.max(0, Math.min(r, Math.min(w, h) / 2));
        if (r == 0) {
            c.fill(x, y, x + w, y + 1, color);
            c.fill(x, y + h - 1, x + w, y + h, color);
            c.fill(x, y + 1, x + 1, y + h - 1, color);
            c.fill(x + w - 1, y + 1, x + w, y + h - 1, color);
            return;
        }
        int prev = r;
        for (int i = 0; i < r; i++) {
            int in = inset(r, i);
            if (i == 0) {
                c.fill(x + in, y, x + w - in, y + 1, color);
                c.fill(x + in, y + h - 1, x + w - in, y + h, color);
            } else {
                int end = Math.max(in + 1, prev);
                c.fill(x + in, y + i, x + end, y + i + 1, color);
                c.fill(x + w - end, y + i, x + w - in, y + i + 1, color);
                c.fill(x + in, y + h - 1 - i, x + end, y + h - i, color);
                c.fill(x + w - end, y + h - 1 - i, x + w - in, y + h - i, color);
            }
            prev = in;
        }
        c.fill(x, y + r, x + 1, y + h - r, color);
        c.fill(x + w - 1, y + r, x + w, y + h - r, color);
    }

    /** 玻璃面板：陰影 + 冷色半透明底 + 上半部高光 + 邊框 + 頂緣亮線。 */
    static void panel(DrawContext c, int x, int y, int w, int h, int r, boolean shadow) {
        if (shadow) {
            for (int k = 6; k >= 1; k--) {
                roundRect(c, x - k, y - k + 3, w + 2 * k, h + 2 * k, r + k, 0x0B000000);
            }
        }
        roundRect(c, x, y, w, h, r, 0x8C14202E);                       // 冷色玻璃底
        // 上半部高光：疊多層逐漸變短的淡白色，形成由上往下淡出的漸層（沒有硬邊）
        for (int i = 0; i < 8; i++) {
            int bandH = Math.max(4, h * (50 - i * 6) / 100);
            roundRect(c, x + 1, y + 1, w - 2, bandH, Math.max(0, r - 1), 0x06FFFFFF);
        }
        roundRect(c, x + 3, y + h - 7, w - 6, 5, 2, 0x0AFFFFFF);          // 底部淡淡反光
        roundOutline(c, x, y, w, h, r, 0x55FFFFFF);
        c.fill(x + r, y + 1, x + w - r, y + 2, 0x70FFFFFF);            // 頂緣亮線
    }

    /** 面板內的次級卡片（更淡、更小圓角）。 */
    static void card(DrawContext c, int x, int y, int w, int h, int r) {
        roundRect(c, x, y, w, h, r, 0x2A0A1320);
        roundOutline(c, x, y, w, h, r, 0x26FFFFFF);
    }

    /** 膠囊按鈕。accent 為強調色（主要操作）。 */
    static void pill(DrawContext c, int x, int y, int w, int h, boolean hover, boolean accent) {
        int r = h / 2;
        if (accent) {
            roundRect(c, x, y, w, h, r, hover ? 0xCC5AC8FA : 0xA03A9BD0);
            roundOutline(c, x, y, w, h, r, 0x80FFFFFF);
        } else {
            roundRect(c, x, y, w, h, r, hover ? 0x44FFFFFF : 0x26FFFFFF);
            roundOutline(c, x, y, w, h, r, hover ? 0x70FFFFFF : 0x40FFFFFF);
        }
        c.fill(x + r, y + 1, x + w - r, y + 2, 0x30FFFFFF);
    }
}
