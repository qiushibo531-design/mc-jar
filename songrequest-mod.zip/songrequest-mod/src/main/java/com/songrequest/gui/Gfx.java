package com.songrequest.gui;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.ShaderProgram;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import org.joml.Matrix4f;

/**
 * 平滑繪圖：直接把圓角形狀畫成三角形（以裝置像素精度），邊緣用 1 像素寬、透明度漸變的
 * 羽化帶做抗鋸齒，所以圓角沒有像素階梯。座標單位是 GUI 座標（可以是小數）。
 */
public final class Gfx {
    /** 依位置回傳 ARGB 顏色；用來做漸層。 */
    public interface Col {
        int at(float px, float py);
    }

    private Gfx() {}

    // ---------------------------------------------------------------- 顏色工具

    public static int alpha(int argb, int a) {
        return (Math.max(0, Math.min(255, a)) << 24) | (argb & 0xFFFFFF);
    }

    public static int scaleAlpha(int argb, float m) {
        return alpha(argb, Math.round(((argb >>> 24) & 255) * m));
    }

    public static int mix(int a, int b, float t) {
        int r = 0;
        for (int s = 24; s >= 0; s -= 8) {
            int ca = (a >>> s) & 255, cb = (b >>> s) & 255;
            r |= (Math.round(ca + (cb - ca) * t) & 255) << s;
        }
        return r;
    }

    public static Col solid(int color) {
        return (x, y) -> color;
    }

    public static Col vertical(float y0, float y1, int top, int bottom) {
        return (x, y) -> mix(top, bottom, Math.max(0f, Math.min(1f, (y - y0) / Math.max(0.001f, y1 - y0))));
    }

    /** 左上亮、右下暗的斜向漸層，用來做玻璃邊緣的高光。 */
    public static Col diagonal(float x0, float y0, float w, float h, int bright, int dim) {
        return (x, y) -> mix(bright, dim, Math.max(0f, Math.min(1f, ((x - x0) / w + (y - y0) / h) / 2f)));
    }

    // ---------------------------------------------------------------- 內部

    private static float scale() {
        return (float) MinecraftClient.getInstance().getWindow().getScaleFactor();
    }

    /** 一個裝置像素等於多少 GUI 座標。 */
    public static float px() {
        return 1f / scale();
    }

    private static int segs(float r) {
        return Math.max(2, Math.min(16, (int) Math.ceil(r * scale() / 2.5f)));
    }

    /** 圓角矩形外框上的點；off>0 往外擴。每個角 n+1 個點，共 4(n+1) 個，座標交錯存放。 */
    private static float[] path(float x, float y, float w, float h, float r, float off, int n) {
        float x1 = x - off, y1 = y - off, x2 = x + w + off, y2 = y + h + off;
        float rr = Math.max(0f, Math.min(r + off, Math.min(x2 - x1, y2 - y1) / 2f));
        float[][] corner = {{x1 + rr, y1 + rr, 180}, {x2 - rr, y1 + rr, 270}, {x2 - rr, y2 - rr, 0}, {x1 + rr, y2 - rr, 90}};
        float[] p = new float[4 * (n + 1) * 2];
        int k = 0;
        for (float[] c : corner) {
            for (int i = 0; i <= n; i++) {
                double a = Math.toRadians(c[2] + 90.0 * i / n);
                p[k++] = (float) (c[0] + rr * Math.cos(a));
                p[k++] = (float) (c[1] + rr * Math.sin(a));
            }
        }
        return p;
    }

    private static void begin(DrawContext c) {
        c.draw(); // 先把待畫的文字／方塊送出，維持繪製順序
        RenderSystem.setShader(GameRenderer::getPositionColorProgram);
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableCull();
    }

    private static void end() {
        RenderSystem.enableCull();
    }

    private static void v(BufferBuilder b, Matrix4f m, float x, float y, int argb, float aMul) {
        int a = Math.round(((argb >>> 24) & 255) * aMul);
        b.vertex(m, x, y, 0f).color((argb >> 16) & 255, (argb >> 8) & 255, argb & 255, a).next();
    }

    // ---------------------------------------------------------------- 形狀

    public static void fillRound(DrawContext c, float x, float y, float w, float h, float r, int color) {
        fill(c, x, y, w, h, r, solid(color), px());
    }

    /** 圓角矩形填色。feather 是邊緣羽化寬度（一般 1 個裝置像素；陰影用大值）。 */
    public static void fill(DrawContext c, float x, float y, float w, float h, float r, Col col, float feather) {
        if (w <= 0 || h <= 0) return;
        r = Math.max(0f, Math.min(r, Math.min(w, h) / 2f));
        feather = Math.min(feather, Math.min(w, h));
        int n = segs(r);
        float[] in = path(x, y, w, h, r, -feather / 2f, n);
        float[] out = path(x, y, w, h, r, feather / 2f, n);
        int pts = in.length / 2;

        begin(c);
        Matrix4f m = c.getMatrices().peek().getPositionMatrix();
        Tessellator t = Tessellator.getInstance();
        BufferBuilder b = t.getBuffer();

        b.begin(VertexFormat.DrawMode.TRIANGLE_FAN, VertexFormats.POSITION_COLOR);
        float cx = x + w / 2f, cy = y + h / 2f;
        v(b, m, cx, cy, col.at(cx, cy), 1f);
        for (int i = 0; i <= pts; i++) {
            int k = (i % pts) * 2;
            v(b, m, in[k], in[k + 1], col.at(in[k], in[k + 1]), 1f);
        }
        BufferRenderer.drawWithGlobalProgram(b.end());

        b.begin(VertexFormat.DrawMode.TRIANGLE_STRIP, VertexFormats.POSITION_COLOR);
        for (int i = 0; i <= pts; i++) {
            int k = (i % pts) * 2;
            v(b, m, in[k], in[k + 1], col.at(in[k], in[k + 1]), 1f);
            v(b, m, out[k], out[k + 1], col.at(out[k], out[k + 1]), 0f);
        }
        BufferRenderer.drawWithGlobalProgram(b.end());
        end();
    }

    /** 柔和陰影：從形狀邊緣往外 spread 的範圍內漸漸變透明。 */
    public static void shadow(DrawContext c, float x, float y, float w, float h, float r, float spread, int color) {
        fill(c, x + spread / 2f, y + spread / 2f, w - spread, h - spread, Math.max(0f, r - spread / 2f) + spread / 2f, solid(color), spread * 2f);
    }

    /** 圓角外框（以邊界為中心的 thick 粗細），兩側各有羽化。 */
    public static void stroke(DrawContext c, float x, float y, float w, float h, float r, float thick, Col col) {
        if (w <= 1 || h <= 1) return;
        r = Math.max(0f, Math.min(r, Math.min(w, h) / 2f));
        float f = px();
        int n = segs(r);
        float[][] ring = {
                path(x, y, w, h, r, -thick / 2f - f, n), path(x, y, w, h, r, -thick / 2f, n),
                path(x, y, w, h, r, thick / 2f, n), path(x, y, w, h, r, thick / 2f + f, n)};
        float[] am = {0f, 1f, 1f, 0f};
        int pts = ring[0].length / 2;

        begin(c);
        Matrix4f m = c.getMatrices().peek().getPositionMatrix();
        BufferBuilder b = Tessellator.getInstance().getBuffer();
        for (int s = 0; s < 3; s++) {
            b.begin(VertexFormat.DrawMode.TRIANGLE_STRIP, VertexFormats.POSITION_COLOR);
            for (int i = 0; i <= pts; i++) {
                int k = (i % pts) * 2;
                v(b, m, ring[s][k], ring[s][k + 1], col.at(ring[s][k], ring[s][k + 1]), am[s]);
                v(b, m, ring[s + 1][k], ring[s + 1][k + 1], col.at(ring[s + 1][k], ring[s + 1][k + 1]), am[s + 1]);
            }
            BufferRenderer.drawWithGlobalProgram(b.end());
        }
        end();
    }

    public static void circle(DrawContext c, float cx, float cy, float radius, int color) {
        fillRound(c, cx - radius, cy - radius, radius * 2, radius * 2, radius, color);
    }

    /** 四角各自指定顏色的矩形（用在色相／飽和度滑桿的漸層軌道）。 */
    public static void quad(DrawContext c, float x, float y, float w, float h, int tl, int tr, int bl, int br) {
        if (w <= 0 || h <= 0) return;
        begin(c);
        Matrix4f m = c.getMatrices().peek().getPositionMatrix();
        BufferBuilder b = Tessellator.getInstance().getBuffer();
        b.begin(VertexFormat.DrawMode.TRIANGLE_STRIP, VertexFormats.POSITION_COLOR);
        v(b, m, x, y, tl, 1f);
        v(b, m, x, y + h, bl, 1f);
        v(b, m, x + w, y, tr, 1f);
        v(b, m, x + w, y + h, br, 1f);
        BufferRenderer.drawWithGlobalProgram(b.end());
        end();
    }

    /** 水平漸層的圓頭軌道。 */
    public static void gradientTrack(DrawContext c, float x, float y, float w, float h, int[] stops) {
        float r = h / 2f;
        circle(c, x + r, y + r, r, stops[0]);
        circle(c, x + w - r, y + r, r, stops[stops.length - 1]);
        float inner = w - h, seg = inner / (stops.length - 1);
        for (int i = 0; i < stops.length - 1; i++) {
            quad(c, x + r + seg * i, y, seg + 0.01f, h, stops[i], stops[i + 1], stops[i], stops[i + 1]);
        }
    }

    /** 會流動的波浪線（Material 風格進度條的已播放段）。 */
    public static void wave(DrawContext c, float x, float y, float len, float amp, double phase, float thick, int color) {
        if (len <= 0) return;
        begin(c);
        Matrix4f m = c.getMatrices().peek().getPositionMatrix();
        BufferBuilder b = Tessellator.getInstance().getBuffer();
        b.begin(VertexFormat.DrawMode.TRIANGLE_STRIP, VertexFormats.POSITION_COLOR);
        int steps = Math.max(2, (int) (len * scale() / 2f));
        for (int i = 0; i <= steps; i++) {
            float px = x + len * i / steps;
            float py = y + (float) (Math.sin(px * 0.55 - phase) * amp);
            v(b, m, px, py - thick / 2f, color, 1f);
            v(b, m, px, py + thick / 2f, color, 1f);
        }
        BufferRenderer.drawWithGlobalProgram(b.end());
        end();
    }

    /** Material 的「花瓣」載入形狀：12 個波瓣，旋轉。 */
    public static void cookie(DrawContext c, float cx, float cy, float radius, double rotation, int color) {
        begin(c);
        Matrix4f m = c.getMatrices().peek().getPositionMatrix();
        BufferBuilder b = Tessellator.getInstance().getBuffer();
        b.begin(VertexFormat.DrawMode.TRIANGLE_FAN, VertexFormats.POSITION_COLOR);
        v(b, m, cx, cy, color, 1f);
        int steps = 96;
        for (int i = 0; i <= steps; i++) {
            double a = Math.PI * 2 * i / steps;
            double rr = radius * (0.84 + 0.16 * Math.cos(12 * (a - rotation)));
            v(b, m, (float) (cx + rr * Math.cos(a)), (float) (cy + rr * Math.sin(a)), color, 1f);
        }
        BufferRenderer.drawWithGlobalProgram(b.end());
        end();
    }
}
