package com.songrequest.gui;

import com.mojang.blaze3d.systems.RenderSystem;
import com.songrequest.SongRequestClient;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gl.PostEffectProcessor;
import net.minecraft.util.Identifier;

/**
 * 背景高斯模糊：用 Minecraft 自己的後處理管線（和原版「超級秘密設定」的模糊同一套著色器）
 * 把目前畫面（世界）模糊一遍，之後再畫半透明的玻璃面板，形成毛玻璃效果。
 * 任何一步失敗都會自動停用並退回「磨砂半透明」，不會讓遊戲崩潰。
 */
public final class Blur {
    private static PostEffectProcessor processor;
    private static int level = -1;
    private static int w = -1, h = -1;
    private static boolean broken;
    private static boolean active;

    private Blur() {}

    /** 本幀是否真的套用了模糊（面板據此決定要不要加強磨砂不透明度）。 */
    public static boolean isActive() {
        return active;
    }

    public static void apply(DrawContext ctx, int lvl, float delta) {
        active = false;
        if (lvl <= 0 || broken) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        try {
            int fw = mc.getWindow().getFramebufferWidth(), fh = mc.getWindow().getFramebufferHeight();
            if (processor == null || level != lvl) {
                release();
                processor = new PostEffectProcessor(mc.getTextureManager(), mc.getResourceManager(), mc.getFramebuffer(),
                        new Identifier("songrequest", "shaders/post/glass_blur_" + lvl + ".json"));
                level = lvl;
                w = -1;
            }
            if (w != fw || h != fh) {
                processor.setupDimensions(fw, fh);
                w = fw;
                h = fh;
            }
            ctx.draw();
            RenderSystem.disableBlend();
            RenderSystem.disableDepthTest();
            RenderSystem.resetTextureMatrix();
            processor.render(delta);
            mc.getFramebuffer().beginWrite(false);
            RenderSystem.enableDepthTest();
            RenderSystem.enableBlend();
            active = true;
        } catch (Throwable t) {
            broken = true;
            SongRequestClient.LOGGER.warn("背景模糊不可用，已退回磨砂半透明: {}", t.toString());
            release();
        }
    }

    public static void release() {
        if (processor != null) {
            try {
                processor.close();
            } catch (Throwable ignored) {
                // 忽略
            }
            processor = null;
        }
        level = -1;
    }
}
