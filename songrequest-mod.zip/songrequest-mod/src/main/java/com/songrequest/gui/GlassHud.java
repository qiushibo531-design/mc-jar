package com.songrequest.gui;

import net.minecraft.client.gui.DrawContext;

/** 讓 HUD 套件（不同 package）也能使用 Glass 的繪製函式。 */
public final class GlassHud {
    private GlassHud() {}

    public static void roundRect(DrawContext c, int x, int y, int w, int h, int r, int color) {
        Glass.roundRect(c, x, y, w, h, r, color);
    }

    public static void outline(DrawContext c, int x, int y, int w, int h, int r, int color) {
        Glass.roundOutline(c, x, y, w, h, r, color);
    }
}
