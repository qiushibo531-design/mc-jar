package com.songrequest.gui;

import com.songrequest.Config;
import com.songrequest.SongRequestClient;
import com.songrequest.api.MusicProvider;
import com.songrequest.api.Providers;
import com.songrequest.api.Song;
import com.songrequest.audio.MusicPlayer;
import com.songrequest.hud.LyricsHud;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;
import com.mojang.blaze3d.systems.RenderSystem;
import org.lwjgl.glfw.GLFW;
import org.lwjgl.opengl.GL11;

import java.util.ArrayList;
import java.util.List;

/**
 * 點歌台。所有按鈕、滑桿都是自繪（平滑抗鋸齒圓角），外觀由 {@link Theme} 決定：液態玻璃（高斯模糊）或 Google（Material You）。
 * 左：搜尋與結果（點歌名播放、點 + 加入佇列）；右：正在播放、控制、音量、佇列；
 * 右上：音源（API）、外觀（風格／深淺／模糊／圓角／自訂顏色）、字幕開關。
 */
public class MusicScreen extends Screen {

    /** 不帶陰影、不重複描邊的輸入框（原版 TextFieldWidget 會畫出有陰影的字，看起來像重複）。 */
    private static final class PlainField extends TextFieldWidget {
        int color = 0xFFFFFFFF;
        int hintColor = 0x99FFFFFF;
        String hint;

        PlainField(TextRenderer tr, int x, int y, int w, int h, Text t) {
            super(tr, x, y, w, h, t);
        }

        @Override
        public void renderWidget(DrawContext c, int mx, int my, float delta) {
            TextRenderer tr = MinecraftClient.getInstance().textRenderer;
            String s = getText();
            int x = getX(), y = getY() + (getHeight() - 8) / 2 + 1;
            if (s.isEmpty()) {
                if (hint != null) c.drawText(tr, hint, x, y, hintColor, false);
            } else {
                boolean cut = tr.getWidth(s) > getWidth();
                String shown = cut ? tr.trimToWidth(s, getWidth(), true) : s;
                c.drawText(tr, shown, x, y, color, false);
            }
            if (isFocused() && (System.currentTimeMillis() / 500) % 2 == 0) {
                boolean cut = tr.getWidth(s) > getWidth();
                int cur = Math.max(0, Math.min(s.length(), getCursor()));
                int cx = x + (cut ? Math.min(getWidth(), tr.getWidth(s)) : tr.getWidth(s.substring(0, cur)));
                Gfx.fillRound(c, cx, y - 1, 1, 10, 0, color);
            }
        }
    }

    private enum Menu { NONE, SOURCE, STYLE, ADV, LAYOUT, COLORS }
    private float k = 1f;
    private int vw, vh;
    private int srcScroll;

    private static final int RES_ROW = 28;
    private static final int QUEUE_ROW = 18;
    private static final int MENU_ROW = 18;

    private static List<Song> results = new ArrayList<>();
    private static String lastQuery = "";
    private static String status = "";
    private static boolean statusError;
    private static boolean searching;

    /** 自繪按鈕。 */
    private static final class Btn {
        int x, y, w, h;
        final Runnable action;
        final boolean accent;

        Btn(boolean accent, Runnable action) {
            this.accent = accent;
            this.action = action;
        }

        void set(int x, int y, int w, int h) {
            this.x = x; this.y = y; this.w = w; this.h = h;
        }

        boolean hit(double mx, double my) {
            return mx >= x && mx < x + w && my >= y && my < y + h;
        }
    }

    private final Screen parent;
    private Theme t = Theme.current();

    private PlainField searchField;
    private PlainField cfgField;
    private PlainField hexField;
    private boolean hexSilent;
    private final List<Btn> btns = new ArrayList<>();
    private Btn searchBtn, pauseBtn, skipBtn, stopBtn, sourceBtn, themeBtn, hudBtn, closeBtn, clearBtn;
    private double seekFrac;
    private int drag; // 0 無；1 音量；2 模糊；3 圓角；4-7 H/S/B/A
    private final int[] sx = new int[20], sy = new int[20], sw = new int[20];
    private int colorIdx = 1;
    private float ch, cs = 1f, cv = 1f, ca = 1f;
    private int stX, stY, stW, stH;

    private Menu menu = Menu.NONE;

    private int panelW, panelH, x0, y0;
    private int leftX, leftW, rightX, rightW;
    private int resY, resH, qY, qH;
    private int volX, volY, volW;
    private int menuX, menuY, menuW, menuH;
    private double resScroll, qScroll;

    public MusicScreen() {
        this(null);
    }

    /** parent：關閉點歌台後要回到的畫面（主界面／暫停選單），null 表示直接回到遊戲。 */
    public MusicScreen(Screen parent) {
        super(Text.translatable("songrequest.title"));
        this.parent = parent;
    }

    @Override
    public void close() {
        MinecraftClient.getInstance().setScreen(parent);
    }

    /** 外部（例如播放錯誤）更新狀態列。須在主執行緒呼叫。 */
    public static void postStatus(String text, boolean error) {
        setStatus(text, error);
    }

    // ================================================================ 初始化

    @Override
    protected void init() {
        k = Config.get().uiScale;
        vw = Math.round(width / k);
        vh = Math.round(height / k);
        panelW = Math.min(vw - 16, 460);
        panelH = Math.min(vh - 16, 264);
        x0 = (vw - panelW) / 2;
        y0 = (vh - panelH) / 2;
        leftX = x0 + 12;
        leftW = (panelW - 36) * 55 / 100;
        rightX = leftX + leftW + 12;
        rightW = panelW - 36 - leftW;

        btns.clear();

        String prev = searchField != null ? searchField.getText() : lastQuery;
        searchField = new PlainField(textRenderer, leftX + 10, y0 + 36, leftW - 64, 12, Text.translatable("songrequest.search.hint"));
        searchField.setDrawsBackground(false);
        searchField.setMaxLength(60);
        searchField.setText(prev);
        searchField.hint = Text.translatable("songrequest.search.hint").getString();
        addDrawableChild(searchField);
        setInitialFocus(searchField);

        String prevCfg = cfgField != null ? cfgField.getText() : "";
        cfgField = new PlainField(textRenderer, 0, 0, 100, 12, Text.empty());
        cfgField.setDrawsBackground(false);
        cfgField.setMaxLength(600);
        cfgField.setText(prevCfg);
        cfgField.setChangedListener(v -> Config.setApi(Providers.selected().id(), v));
        addSelectableChild(cfgField);

        hexField = new PlainField(textRenderer, 0, 0, 100, 12, Text.empty());
        hexField.setDrawsBackground(false);
        hexField.setMaxLength(9);
        hexField.setChangedListener(this::onHexTyped);
        addSelectableChild(hexField);

        searchBtn = add(true, this::doSearch);
        pauseBtn = add(false, () -> SongRequestClient.PLAYER.togglePause());
        skipBtn = add(false, () -> SongRequestClient.PLAYER.skip());
        stopBtn = add(false, () -> SongRequestClient.PLAYER.stop());
        hudBtn = add(false, () -> Config.get().hudEnabled = !Config.get().hudEnabled);
        sourceBtn = add(false, () -> toggleMenu(Menu.SOURCE));
        themeBtn = add(false, () -> toggleMenu(Menu.STYLE));
        closeBtn = add(false, this::close);
        clearBtn = add(false, () -> SongRequestClient.PLAYER.clearQueue());

        closeBtn.set(x0 + panelW - 12 - 18, y0 + 8, 18, 14);
        hudBtn.set(closeBtn.x - 4 - 58, y0 + 8, 58, 14);
        themeBtn.set(hudBtn.x - 4 - 44, y0 + 8, 44, 14);
        sourceBtn.set(themeBtn.x - 4 - 96, y0 + 8, 96, 14);

        clearBtn.set(rightX + rightW - 40, y0 + 143, 40, 14);
        searchBtn.set(leftX + leftW - 48, y0 + 31, 48, 22);
        resY = y0 + 58;
        resH = Math.max(20, panelH - 58 - 26);

        int bw = (rightW - 8) / 3;
        pauseBtn.set(rightX, y0 + 100, bw, 18);
        skipBtn.set(rightX + bw + 4, y0 + 100, bw, 18);
        stopBtn.set(rightX + 2 * (bw + 4), y0 + 100, bw, 18);

        volX = rightX + 56;
        volY = y0 + 126;
        volW = rightW - 56;
        sx[1] = volX; sy[1] = volY; sw[1] = volW;

        qY = y0 + 160;
        qH = Math.max(0, y0 + panelH - 12 - qY);

        if (menu != Menu.NONE) layoutMenu();
    }

    @Override
    public void resize(MinecraftClient client, int w, int h) {
        super.resize(client, w, h);
        if (parent != null) parent.resize(client, w, h);
    }

    private Btn add(boolean accent, Runnable action) {
        Btn b = new Btn(accent, action);
        btns.add(b);
        return b;
    }

    // ================================================================ 選單

    private void toggleMenu(Menu m) {
        if (menu == m) {
            closeMenu();
        } else {
            menu = m;
            layoutMenu();
            if (m == Menu.SOURCE) syncCfgField();
        }
    }

    private void closeMenu() {
        menu = Menu.NONE;
        drag = 0;
        Config.save();
        setFocused(searchField);
    }

    private void layoutMenu() {
        if (menu == Menu.LAYOUT) {
            menuW = Math.min(panelW - 16, 320);
            menuH = 150;
            menuX = (vw - menuW) / 2;
            menuY = Math.max(4, (vh - menuH) / 2);
            int colW = (menuW - 36) / 2;
            int[][] ids = {{12, 14, 16}, {13, 15, 17}};
            for (int c = 0; c < 2; c++) {
                for (int r = 0; r < 3; r++) {
                    sx[ids[c][r]] = menuX + 12 + c * (colW + 12);
                    sw[ids[c][r]] = colW;
                    sy[ids[c][r]] = menuY + 38 + r * 30;
                }
            }
            return;
        }
        if (menu == Menu.COLORS) {
            menuW = Math.min(panelW - 16, 340);
            menuH = 194;
            menuX = (vw - menuW) / 2;
            menuY = Math.max(4, (vh - menuH) / 2);
            int rx = menuX + 124, rw = menuW - 124 - 12;
            for (int i = 0; i < 4; i++) {
                sx[4 + i] = rx + 12;
                sw[4 + i] = rw - 12;
                sy[4 + i] = menuY + 88 + i * 18;
            }
            hexField.setX(rx + 8);
            hexField.setY(menuY + 61);
            hexField.setWidth(rw - 16);
            return;
        }
        Btn anchor = menu == Menu.SOURCE ? sourceBtn : themeBtn;
        menuW = Math.min(menu == Menu.SOURCE ? 224 : 214, panelW - 24);
        menuX = Math.max(x0 + 8, Math.min(anchor.x + anchor.w - menuW, x0 + panelW - 8 - menuW));
        menuY = y0 + 26;
        if (menu == Menu.SOURCE) {
            srcScroll = Math.max(0, Math.min(srcScroll, Providers.ALL.size() - visRows()));
            menuH = 24 + visRows() * MENU_ROW + 44;
        } else if (menu == Menu.STYLE) {
            menuH = 180;
        } else {
            menuH = 202;
            int[] ids = {2, 3, 9, 10, 11};
            for (int k = 0; k < ids.length; k++) {
                sx[ids[k]] = menuX + 12;
                sw[ids[k]] = menuW - 24;
                sy[ids[k]] = menuY + 36 + k * 28;
            }
        }
    }

    /** 音源選單一次最多顯示幾列（超過就用滾輪捲動）。 */
    private int visRows() {
        return Math.min(Providers.ALL.size(), Math.max(4, (panelH - 26 - 8 - 68) / MENU_ROW));
    }

    private void syncCfgField() {
        MusicProvider p = Providers.selected();
        cfgField.setText(Config.api(p.id()));
        int fy = menuY + 24 + visRows() * MENU_ROW + 4;
        cfgField.setX(menuX + 16);
        cfgField.setY(fy + 18);
        cfgField.setWidth(menuW - 32);
    }

    // ---------------------------------------------------------------- 顏色（HSB）

    private String colorKey() {
        return Theme.keyPrefix(t.style, t.dark) + Theme.KEYS[colorIdx];
    }

    private void loadColor() {
        int argb = Theme.resolve(t.style, t.dark, Theme.KEYS[colorIdx]);
        hsvFrom(argb);
        setHexText(argb);
    }

    private void hsvFrom(int argb) {
        float r = ((argb >> 16) & 255) / 255f, g = ((argb >> 8) & 255) / 255f, b = (argb & 255) / 255f;
        float max = Math.max(r, Math.max(g, b)), min = Math.min(r, Math.min(g, b)), d = max - min;
        ca = ((argb >>> 24) & 255) / 255f;
        cv = max;
        cs = max <= 0f ? 0f : d / max;
        if (d > 1e-5f) {
            float h;
            if (max == r) h = ((g - b) / d) % 6f;
            else if (max == g) h = (b - r) / d + 2f;
            else h = (r - g) / d + 4f;
            h /= 6f;
            if (h < 0) h += 1f;
            ch = Math.min(h, 0.9999f);
        } // 灰階時保留原本的色相
    }

    static int hsv(float h, float s, float v, float a) {
        float c = v * s, hh = (h % 1f) * 6f, x = c * (1f - Math.abs(hh % 2f - 1f)), m = v - c;
        float r, g, b;
        switch ((int) hh) {
            case 0 -> { r = c; g = x; b = 0; }
            case 1 -> { r = x; g = c; b = 0; }
            case 2 -> { r = 0; g = c; b = x; }
            case 3 -> { r = 0; g = x; b = c; }
            case 4 -> { r = x; g = 0; b = c; }
            default -> { r = c; g = 0; b = x; }
        }
        return (Math.round(a * 255) << 24) | (Math.round((r + m) * 255) << 16)
                | (Math.round((g + m) * 255) << 8) | Math.round((b + m) * 255);
    }

    private void colorChanged() {
        int argb = hsv(ch, cs, cv, ca);
        Config.setCustomColor(colorKey(), argb);
        setHexText(argb);
    }

    private void setHexText(int argb) {
        hexSilent = true;
        hexField.setText(String.format("#%08X", argb));
        hexSilent = false;
    }

    private void onHexTyped(String v) {
        if (hexSilent) return;
        String s = v.trim();
        if (s.startsWith("#")) s = s.substring(1);
        if (s.length() != 6 && s.length() != 8) return;
        try {
            long n = Long.parseLong(s, 16);
            int argb = s.length() == 6 ? (Math.round(ca * 255) << 24) | (int) n : (int) n;
            hsvFrom(argb);
            Config.setCustomColor(colorKey(), argb);
        } catch (NumberFormatException ignored) {
            // 還沒輸入完
        }
    }

    // ================================================================ 動作

    private void doSearch() {
        String q = searchField.getText().trim();
        final MusicProvider provider = Providers.selected();
        if ((q.isEmpty() && !"local".equals(provider.id())) || searching) return;
        lastQuery = q;
        searching = true;
        setStatus(Text.translatable("songrequest.status.searching").getString(), false);
        MinecraftClient mc = MinecraftClient.getInstance();
        Thread th = new Thread(() -> {
            try {
                List<Song> found = provider.search(q);
                mc.execute(() -> {
                    results = found;
                    resScroll = 0;
                    searching = false;
                    setStatus(found.isEmpty()
                            ? Text.translatable("songrequest.status.none").getString()
                            : Text.translatable("songrequest.status.found", found.size()).getString(), found.isEmpty());
                });
            } catch (Exception e) {
                SongRequestClient.LOGGER.warn("搜尋失敗 ({})", provider.id(), e);
                boolean needCfg = "need_config".equals(e.getMessage());
                String msg = e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage();
                mc.execute(() -> {
                    searching = false;
                    String st;
                    if (needCfg) st = Text.translatable("songrequest.status.need_cfg").getString();
                    else if (msg.startsWith("local_empty:")) st = Text.translatable("songrequest.status.local_empty", msg.substring(12)).getString();
                    else st = Text.translatable("songrequest.status.error_detail", msg).getString();
                    setStatus(st, true);
                    if (needCfg && menu != Menu.SOURCE) {
                        menu = Menu.SOURCE;
                        layoutMenu();
                        syncCfgField();
                    }
                });
            }
        }, "SongRequest-Search");
        th.setDaemon(true);
        th.start();
    }

    private static void setStatus(String s, boolean err) {
        status = s;
        statusError = err;
    }

    // ================================================================ 繪製

    @Override
    public void renderBackground(DrawContext context, int mouseX, int mouseY, float delta) {
        // 在 render() 自己畫背景
    }

    private void text(DrawContext ctx, String s, int x, int y, int color) {
        ctx.drawText(textRenderer, s, x, y, color, false);
    }

    private void textS(DrawContext ctx, Text s, int x, int y, int color) {
        ctx.drawText(textRenderer, s, x, y, color, t.shadowedText());
    }

    private double clock() {
        return System.nanoTime() / 1.0e9;
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        t = Theme.current();
        MusicPlayer player = SongRequestClient.PLAYER;
        TextRenderer tr = textRenderer;
        boolean blocked = menu != Menu.NONE;

        searchField.color = t.text | 0xFF000000; searchField.hintColor = t.sub;
        cfgField.color = t.text | 0xFF000000; cfgField.hintColor = t.sub;

        hexField.color = t.text | 0xFF000000; hexField.hintColor = t.sub;

        // 先畫出底下的畫面（主界面／暫停選單），再把它高斯模糊，最後疊上玻璃面板
        if (parent != null) {
            parent.render(ctx, -1, -1, delta);
            ctx.draw(); // 先送出主界面的文字與標語
            RenderSystem.clear(GL11.GL_DEPTH_BUFFER_BIT, MinecraftClient.IS_SYSTEM_MAC); // 清掉它們寫入的深度，才不會蓋在面板上
        }
        Blur.apply(ctx, t.style == Theme.Style.GLASS ? Config.get().blur : 0, delta);
        t.scrim(ctx, width, height, MinecraftClient.getInstance().world != null);
        mx = (int) (mx / k);
        my = (int) (my / k);
        ctx.getMatrices().push();
        ctx.getMatrices().scale(k, k, 1f);
        Gfx.setExtra(k);
        t.panel(ctx, x0, y0, panelW, panelH);

        // 標題列
        Gfx.fillRound(ctx, x0 + 12, y0 + 12, 3, 8, 1.5f, t.accent);
        textS(ctx, title, x0 + 20, y0 + 11, t.text);
        int creditX = x0 + 20 + tr.getWidth(title) + 8;
        int creditMax = sourceBtn.x - creditX - 6;
        if (creditMax > 30) {
            text(ctx, tr.trimToWidth(Text.translatable("songrequest.credit").getString(), creditMax), creditX, y0 + 11, t.sub);
        }

        // 搜尋欄
        t.field(ctx, leftX, y0 + 31, leftW, 22, searchField.isFocused());
        searchField.setY(y0 + 36);

        drawResults(ctx, mx, my, blocked);
        drawNowPlaying(ctx, player);
        drawVolume(ctx);
        drawQueue(ctx, mx, my, player, blocked);

        if (!status.isEmpty()) {
            text(ctx, tr.trimToWidth(status, leftW), leftX + 2, y0 + panelH - 18, statusError ? t.err : t.sub);
        }

        // 按鈕
        MusicProvider sel = Providers.selected();
        for (Btn b : btns) {
            Text label;
            if (b == searchBtn) label = Text.translatable("songrequest.search.button");
            else if (b == pauseBtn) label = Text.translatable(player.isPaused() ? "songrequest.resume" : "songrequest.pause");
            else if (b == skipBtn) label = Text.translatable("songrequest.skip");
            else if (b == clearBtn) label = Text.translatable("songrequest.queue.clear");
            else if (b == stopBtn) label = Text.translatable("songrequest.stop");
            else if (b == hudBtn) label = Text.translatable(Config.get().hudEnabled ? "songrequest.hud.on" : "songrequest.hud.off");
            else if (b == sourceBtn) label = Text.literal(tr.trimToWidth(sel.displayName(), b.w - 18) + " ▾");
            else if (b == themeBtn) label = Text.translatable("songrequest.theme.chip");
            else label = Text.literal("×");
            boolean active = (b == sourceBtn && menu == Menu.SOURCE) || (b == themeBtn && (menu == Menu.STYLE || menu == Menu.ADV || menu == Menu.LAYOUT || menu == Menu.COLORS));
            boolean hover = (!blocked && b.hit(mx, my)) || active;
            t.pill(ctx, b.x, b.y, b.w, b.h, hover, b.accent);
            int w = tr.getWidth(label);
            ctx.drawText(tr, label, b.x + (b.w - w) / 2, b.y + (b.h - 8) / 2 + 1, t.pillText(b.accent), t.shadowedText());
        }

        super.render(ctx, mx, my, delta); // 搜尋輸入框

        if (menu != Menu.NONE) drawMenu(ctx, mx, my, delta);
        ctx.draw();
        ctx.getMatrices().pop();
        Gfx.setExtra(1f);
        if (menu == Menu.LAYOUT && MinecraftClient.getInstance().world == null) LyricsHud.render(ctx, delta); // 主界面沒有遊戲 HUD，這裡直接預覽字幕
    }

    private void drawResults(DrawContext ctx, int mx, int my, boolean blocked) {
        TextRenderer tr = textRenderer;
        t.card(ctx, leftX, resY, leftW, resH);
        int top = resY + 2, bottom = resY + resH - 2;

        if (results.isEmpty()) {
            if (searching) {
                Gfx.cookie(ctx, leftX + leftW / 2, resY + resH / 2, 9, clock() * 2.2, t.accent);
            } else {
                Text hint = Text.translatable("songrequest.empty");
                ctx.drawText(tr, hint, leftX + (leftW - tr.getWidth(hint)) / 2, resY + resH / 2 - 4, t.sub, false);
            }
            return;
        }
        resScroll = Math.max(0, Math.min(resScroll, Math.max(0, results.size() * RES_ROW - (bottom - top))));
        ctx.enableScissor(leftX, top, leftX + leftW, bottom);
        int plusW = 22;
        Song cur = SongRequestClient.PLAYER.current();
        for (int i = 0; i < results.size(); i++) {
            int ry = top + i * RES_ROW - (int) resScroll;
            if (ry + RES_ROW < top || ry > bottom) continue;
            Song s = results.get(i);
            boolean inList = !blocked && my >= top && my < bottom && mx >= leftX && mx < leftX + leftW;
            boolean hover = inList && my >= ry && my < ry + RES_ROW;
            boolean hoverPlus = hover && mx >= leftX + leftW - plusW - 6;
            boolean playing = cur != null && cur.key().equals(s.key());
            if (hover || playing) t.row(ctx, leftX + 3, ry + 1, leftW - 6, RES_ROW - 2, playing);
            if (playing) Gfx.fillRound(ctx, leftX + 5, ry + 8, 2, RES_ROW - 16, 1, t.accent);

            int textW = leftW - plusW - 52;
            text(ctx, tr.trimToWidth(s.name(), textW), leftX + 12, ry + 5, playing ? t.accent : t.text);
            String sub = s.artist() + (s.album().isEmpty() ? "" : " · " + s.album());
            text(ctx, tr.trimToWidth(sub, textW), leftX + 12, ry + 16, t.sub);

            if (s.durationMs() > 0) {
                String dur = s.durationText();
                text(ctx, dur, leftX + leftW - plusW - 10 - tr.getWidth(dur), ry + 10, t.sub);
            }
            int px = leftX + leftW - plusW - 4;
            t.pill(ctx, px, ry + 5, plusW, 18, hoverPlus, false);
            ctx.drawText(tr, "+", px + (plusW - tr.getWidth("+")) / 2, ry + 10, hoverPlus ? t.accent : t.pillText(false), false);
        }
        ctx.disableScissor();
        scrollbar(ctx, leftX + leftW - 4, top, bottom - top, results.size() * RES_ROW, resScroll);
    }

    private void drawNowPlaying(DrawContext ctx, MusicPlayer player) {
        TextRenderer tr = textRenderer;
        int top = y0 + 30, h = 62;
        t.card(ctx, rightX, top, rightW, h);
        Song cur = player.current();
        if (cur == null) {
            Text idle = Text.translatable("songrequest.idle");
            ctx.drawText(tr, idle, rightX + (rightW - tr.getWidth(idle)) / 2, top + h / 2 - 4, t.sub, false);
            return;
        }
        textS(ctx, Text.translatable("songrequest.now_playing"), rightX + 10, top + 6, t.accent);
        ctx.drawText(tr, tr.trimToWidth(cur.name(), rightW - 20), rightX + 10, top + 17, t.text, t.shadowedText());
        text(ctx, tr.trimToWidth(cur.artist(), rightW - 20), rightX + 10, top + 28, t.sub);

        long pos = player.positionMs();
        long dur = Math.max(1, cur.durationMs());
        boolean loading = player.isLoading();
        float frac = loading || cur.durationMs() <= 0 ? 0f : Math.max(0f, Math.min(1f, pos / (float) dur));
        int bx = rightX + 10, bw = rightW - 20, by = top + h - 18;
        sx[8] = bx; sw[8] = bw; sy[8] = by - 5;
        if (drag == 8) { frac = (float) seekFrac; pos = (long) (seekFrac * dur); }
        t.progress(ctx, bx, by, bw, frac, !player.isPaused() && !loading);
        if (loading) {
            Gfx.cookie(ctx, bx + 5, by + 11, 4, clock() * 2.2, t.accent);
        } else {
            text(ctx, fmt(pos), bx, by + 7, t.sub);
        }
        if (cur.durationMs() > 0) {
            String right = cur.durationText();
            text(ctx, right, bx + bw - tr.getWidth(right), by + 7, t.sub);
        }
    }

    private void drawVolume(DrawContext ctx) {
        float v = Config.get().volume;
        ctx.drawText(textRenderer, Text.translatable("songrequest.volume", Math.round(v * 100)), rightX + 2, volY + 3, t.sub, false);
        t.slider(ctx, volX, volY, volW, v);
    }

    private void drawQueue(DrawContext ctx, int mx, int my, MusicPlayer player, boolean blocked) {
        TextRenderer tr = textRenderer;
        List<Song> queue = player.queueSnapshot();
        ctx.drawText(tr, Text.translatable("songrequest.queue", queue.size()), rightX + 2, y0 + 147, t.text, false);
        if (qH < QUEUE_ROW) return;
        t.card(ctx, rightX, qY, rightW, qH);
        if (queue.isEmpty()) {
            Text empty = Text.translatable("songrequest.queue.empty");
            ctx.drawText(tr, empty, rightX + (rightW - tr.getWidth(empty)) / 2, qY + Math.max(2, qH / 2 - 4), t.sub, false);
            return;
        }
        int top = qY + 2, bottom = qY + qH - 2;
        qScroll = Math.max(0, Math.min(qScroll, Math.max(0, queue.size() * QUEUE_ROW - (bottom - top))));
        ctx.enableScissor(rightX, top, rightX + rightW, bottom);
        for (int i = 0; i < queue.size(); i++) {
            int ry = top + i * QUEUE_ROW - (int) qScroll;
            if (ry + QUEUE_ROW < top || ry > bottom) continue;
            Song s = queue.get(i);
            boolean inList = !blocked && my >= top && my < bottom && mx >= rightX && mx < rightX + rightW;
            boolean hover = inList && my >= ry && my < ry + QUEUE_ROW;
            boolean hoverX = hover && mx >= rightX + rightW - 20;
            if (hover) t.row(ctx, rightX + 3, ry + 1, rightW - 6, QUEUE_ROW - 2, false);
            String line = (i + 1) + ". " + s.name() + " - " + s.artist();
            text(ctx, tr.trimToWidth(line, rightW - 30), rightX + 9, ry + 5, t.text);
            text(ctx, "×", rightX + rightW - 14, ry + 5, hoverX ? t.err : t.sub);
        }
        ctx.disableScissor();
        scrollbar(ctx, rightX + rightW - 4, top, bottom - top, queue.size() * QUEUE_ROW, qScroll);
    }

    /** 音源／外觀選擇器，以及自訂顏色對話框。 */
    private void drawMenu(DrawContext ctx, int mx, int my, float delta) {
        TextRenderer tr = textRenderer;
        Gfx.fillRound(ctx, x0, y0, panelW, panelH, t.panelR, menu == Menu.COLORS ? 0x66000000 : 0x33000000);
        t.popup(ctx, menuX, menuY, menuW, menuH);
        Text title = switch (menu) {
            case SOURCE -> Text.translatable("songrequest.source.title");
            case STYLE -> Text.translatable("songrequest.theme.title");
            case ADV -> Text.translatable("songrequest.adv.title");
            case LAYOUT -> Text.translatable("songrequest.layout.title");
            default -> Text.translatable("songrequest.colors.title");
        };
        textS(ctx, title, menuX + 12, menuY + 8, t.text);

        if (menu == Menu.SOURCE) {
            MusicProvider sel = Providers.selected();
            List<MusicProvider> all = Providers.ALL;
            int vis = visRows();
            for (int i = 0; i < vis; i++) {
                MusicProvider p = all.get(srcScroll + i);
                int ry = menuY + 24 + i * MENU_ROW;
                boolean hover = mx >= menuX + 6 && mx < menuX + menuW - 6 && my >= ry && my < ry + MENU_ROW;
                boolean on = p == sel;
                if (on || hover) t.row(ctx, menuX + 6, ry, menuW - 12, MENU_ROW - 1, on);
                text(ctx, p.displayName(), menuX + 16, ry + 5, on ? t.accent : t.text);
                if (!p.tag().isEmpty()) {
                    String tag = Text.translatable(p.tag()).getString();
                    text(ctx, tag, menuX + menuW - 14 - tr.getWidth(tag), ry + 5, t.sub);
                }
            }
            if (all.size() > vis) {
                int bh = Math.max(10, vis * MENU_ROW * vis / all.size());
                int by = menuY + 24 + (int) ((vis * MENU_ROW - bh) * (srcScroll / (double) (all.size() - vis)));
                Gfx.fillRound(ctx, menuX + menuW - 5, by, 2, bh, 1, Gfx.alpha(t.sub, 0xB0));
            }
            int fy = menuY + 24 + vis * MENU_ROW + 4;
            String cfgKey = sel.configLabel();
            if (cfgKey != null) {
                text(ctx, tr.trimToWidth(Text.translatable(cfgKey).getString(), menuW - 24), menuX + 12, fy + 2, t.sub);
                t.field(ctx, menuX + 8, fy + 14, menuW - 16, 20, cfgField.isFocused());
                cfgField.setY(fy + 18);
                cfgField.render(ctx, mx, my, delta);
            } else {
                text(ctx, "local".equals(sel.id()) ? tr.trimToWidth(com.songrequest.api.LocalProvider.pathString(), menuW - 24, true)
                        : Text.translatable("songrequest.cfg.none").getString(), menuX + 12, fy + 14, t.sub);
            }
        } else if (menu == Menu.STYLE) {
            drawStyleMenu(ctx, mx, my);
        } else if (menu == Menu.ADV) {
            drawAdvMenu(ctx, mx, my);
        } else if (menu == Menu.LAYOUT) {
            drawLayoutMenu(ctx, mx, my);
        } else {
            drawColorsDialog(ctx, mx, my, delta);
        }
    }

    /** 分段選擇器：外觀依目前風格而不同（玻璃：膠囊；Google：描邊＋打勾；Miuix：黑色凹槽＋浮起的選中塊）。 */
    private void segmented(DrawContext ctx, int y, String[] labels, int sel, int mx, int my) {
        int x = menuX + 12, w = menuW - 24, h = 20, n = labels.length;
        float segW = w / (float) n;
        float mr = Math.min(h / 2f, 10f * Config.get().corner);
        Theme.Style st = t.style;
        if (st == Theme.Style.GOOGLE) Gfx.stroke(ctx, x, y, w, h, h / 2f, 1f, Gfx.solid(Gfx.alpha(t.text, 0x70)));
        else if (st == Theme.Style.MIUIX) Gfx.fillRound(ctx, x, y, w, h, mr, t.dark ? 0xFF000000 : 0xFFE4E4E4);
        for (int i = 0; i < n; i++) {
            float x0s = x + segW * i;
            boolean on = i == sel;
            boolean hover = in(mx, my, (int) x0s, y, (int) segW, h);
            int tc;
            if (st == Theme.Style.GLASS) {
                t.pill(ctx, x0s + 1, y, segW - 2, h, hover, on);
                tc = t.pillText(on);
            } else if (st == Theme.Style.GOOGLE) {
                if (on) Gfx.fillRound(ctx, x0s + 1.5f, y + 1.5f, segW - 3, h - 3, (h - 3) / 2f, t.button);
                else if (hover) Gfx.fillRound(ctx, x0s + 1.5f, y + 1.5f, segW - 3, h - 3, (h - 3) / 2f, Gfx.alpha(t.text, 0x14));
                if (i > 0 && !on && i - 1 != sel) Gfx.fillRound(ctx, x0s, y + 4, 1, h - 8, 0, Gfx.alpha(t.text, 0x40));
                tc = t.text;
            } else {
                if (on) Gfx.fillRound(ctx, x0s + 2, y + 2, segW - 4, h - 4, Math.min((h - 4) / 2f, 8f * Config.get().corner), t.card);
                tc = on ? t.text : t.sub;
            }
            String label = (st == Theme.Style.GOOGLE && on ? "\u2713 " : "") + labels[i];
            ctx.drawText(textRenderer, label, Math.round(x0s + (segW - textRenderer.getWidth(label)) / 2f), y + 6, tc, false);
        }
    }

    private int segHit(double mx, double my, int y, int n) {
        int x = menuX + 12, w = menuW - 24;
        if (!in(mx, my, x, y, w, 20)) return -1;
        return Math.min(n - 1, (int) ((mx - x) / (w / (float) n)));
    }

    private void wideBtn(DrawContext ctx, int y, String key, boolean accent, int mx, int my) {
        int bx = menuX + 12, bw = menuW - 24;
        t.pill(ctx, bx, y, bw, 18, in(mx, my, bx, y, bw, 18), accent);
        Text l = Text.translatable(key);
        ctx.drawText(textRenderer, l, bx + (bw - textRenderer.getWidth(l)) / 2, y + 5, t.pillText(accent), false);
    }

    private void drawStyleMenu(DrawContext ctx, int mx, int my) {
        int idx = t.style == Theme.Style.GLASS ? 0 : t.style == Theme.Style.GOOGLE ? 1 : 2;
        segmented(ctx, menuY + 24, new String[]{Text.translatable("songrequest.style.glass").getString(), "Google", "Miuix"}, idx, mx, my);
        segmented(ctx, menuY + 50, new String[]{Text.translatable("songrequest.mode.dark").getString(), Text.translatable("songrequest.mode.light").getString()}, t.dark ? 0 : 1, mx, my);
        wideBtn(ctx, menuY + 80, "songrequest.adv.open", false, mx, my);
        wideBtn(ctx, menuY + 104, "songrequest.layout.open", false, mx, my);
        wideBtn(ctx, menuY + 128, "songrequest.colors.open", true, mx, my);
        wideBtn(ctx, menuY + 152, "songrequest.colors.reset_all", false, mx, my);
    }

    private void drawLayoutMenu(DrawContext ctx, int mx, int my) {
        Config c = Config.get();
        sliderRow(ctx, Text.translatable("songrequest.ui_scale", Math.round(c.uiScale * 100)).getString(), 12, (c.uiScale - 0.6f) / 1.0f, true);
        sliderRow(ctx, Text.translatable("songrequest.btn_x", Math.round(c.btnX * 100)).getString(), 14, c.btnX, true);
        sliderRow(ctx, Text.translatable("songrequest.btn_y", Math.round(c.btnY * 100)).getString(), 16, c.btnY, true);
        sliderRow(ctx, Text.translatable("songrequest.hud_scale", Math.round(c.hudScale * 100)).getString(), 13, (c.hudScale - 0.5f) / 2.5f, true);
        sliderRow(ctx, Text.translatable("songrequest.hud_y", c.hudY).getString(), 15, c.hudY / 150f, true);
        sliderRow(ctx, Text.translatable("songrequest.hud_x", Math.round(c.hudX * 100)).getString(), 17, c.hudX, true);
        wideBtn(ctx, menuY + 126, "songrequest.back", false, mx, my);
    }

    private void sliderRow(DrawContext ctx, String label, int id, float frac, boolean enabled) {
        text(ctx, label, menuX + 12, sy[id] - 13, enabled ? t.text : t.sub);
        if (enabled) t.slider(ctx, sx[id], sy[id], sw[id], frac);
    }

    private void drawAdvMenu(DrawContext ctx, int mx, int my) {
        Config cfg = Config.get();
        boolean glass = t.style == Theme.Style.GLASS;
        String blurVal = cfg.blur <= 0 ? Text.translatable("songrequest.blur.off").getString() : String.valueOf(cfg.blur);
        sliderRow(ctx, Text.translatable(glass ? "songrequest.blur" : "songrequest.blur.glass_only", blurVal).getString(), 2, cfg.blur / 5f, glass);
        sliderRow(ctx, Text.translatable("songrequest.corner", Math.round(cfg.corner * 100)).getString(), 3, (cfg.corner - 0.4f) / 1.2f, true);
        sliderRow(ctx, Text.translatable("songrequest.opacity", Math.round(cfg.opacity * 100)).getString(), 9, (cfg.opacity - 0.3f) / 1.3f, true);
        sliderRow(ctx, Text.translatable("songrequest.shadow", Math.round(cfg.shadow * 100)).getString(), 10, cfg.shadow / 2f, true);
        sliderRow(ctx, Text.translatable("songrequest.glare", Math.round(cfg.glare * 100)).getString(), 11, cfg.glare / 2f, true);
        wideBtn(ctx, menuY + 178, "songrequest.back", false, mx, my);
    }

    private void drawColorsDialog(DrawContext ctx, int mx, int my, float delta) {
        TextRenderer tr = textRenderer;
        // 左：六個可調項目
        for (int i = 0; i < Theme.KEYS.length; i++) {
            int ry = menuY + 28 + i * 22;
            boolean hover = mx >= menuX + 6 && mx < menuX + 118 && my >= ry && my < ry + 20;
            boolean on = i == colorIdx;
            if (on || hover) t.row(ctx, menuX + 6, ry, 112, 20, on);
            int col = Theme.resolve(t.style, t.dark, Theme.KEYS[i]);
            Gfx.fillRound(ctx, menuX + 12, ry + 4, 12, 12, 6, 0xFF9AA0A6);
            Gfx.fillRound(ctx, menuX + 12, ry + 4, 12, 12, 6, col);
            Gfx.stroke(ctx, menuX + 12, ry + 4, 12, 12, 6, 0.8f, Gfx.solid(0x66FFFFFF));
            text(ctx, tr.trimToWidth(Text.translatable("songrequest.color." + Theme.KEYS[i]).getString(), 80), menuX + 30, ry + 6, on ? t.accent : t.text);
        }
        // 右：預覽、十六進位、H S B A
        int rx = menuX + 124, rw = menuW - 124 - 12;
        int cur = hsv(ch, cs, cv, ca);
        Gfx.fillRound(ctx, rx, menuY + 28, rw, 22, 8, 0xFF9AA0A6);
        Gfx.fillRound(ctx, rx, menuY + 28, rw, 22, 8, cur);
        Gfx.stroke(ctx, rx, menuY + 28, rw, 22, 8, 0.8f, Gfx.solid(0x66FFFFFF));
        t.field(ctx, rx, menuY + 57, rw, 20, hexField.isFocused());
        hexField.render(ctx, mx, my, delta);

        float[] pos = {ch, cs, cv, ca};
        String[] names = {"H", "S", "B", "A"};
        int hue = hsv(ch, 1f, 1f, 1f);
        int[][] stops = {
                {hsv(0f, 1, 1, 1), hsv(1f / 6, 1, 1, 1), hsv(2f / 6, 1, 1, 1), hsv(3f / 6, 1, 1, 1), hsv(4f / 6, 1, 1, 1), hsv(5f / 6, 1, 1, 1), hsv(0.9999f, 1, 1, 1)},
                {hsv(ch, 0f, 1f, 1f), hue},
                {0xFF000000, hsv(ch, cs, 1f, 1f)},
                {hsv(ch, cs, cv, 0f), hsv(ch, cs, cv, 1f)}
        };
        for (int i = 0; i < 4; i++) {
            int id = 4 + i;
            text(ctx, names[i], rx, sy[id] + 3, t.sub);
            Gfx.gradientTrack(ctx, sx[id], sy[id] + 3, sw[id], 8, stops[i]);
            Gfx.stroke(ctx, sx[id], sy[id] + 3, sw[id], 8, 4, 0.6f, Gfx.solid(0x55FFFFFF));
            float kx = sx[id] + 5 + (sw[id] - 10) * pos[i];
            Gfx.shadow(ctx, kx - 6, sy[id] + 1, 12, 12, 6, 3, 0x55000000);
            Gfx.circle(ctx, kx, sy[id] + 7, 6f, 0xFFFFFFFF);
            Gfx.circle(ctx, kx, sy[id] + 7, 3.4f, hsv(ch, cs, cv, 1f));
        }
        // 按鈕
        int by = menuY + menuH - 28;
        int w1 = (rw - 6) / 2;
        boolean hr = mx >= rx && mx < rx + w1 && my >= by && my < by + 18;
        boolean hd = mx >= rx + w1 + 6 && mx < rx + rw && my >= by && my < by + 18;
        t.pill(ctx, rx, by, w1, 18, hr, false);
        t.pill(ctx, rx + w1 + 6, by, rw - w1 - 6, 18, hd, true);
        Text lr = Text.translatable("songrequest.colors.reset"), ld = Text.translatable("songrequest.colors.done");
        ctx.drawText(tr, lr, rx + (w1 - tr.getWidth(lr)) / 2, by + 5, t.pillText(false), t.shadowedText());
        ctx.drawText(tr, ld, rx + w1 + 6 + (rw - w1 - 6 - tr.getWidth(ld)) / 2, by + 5, t.pillText(true), t.shadowedText());
    }

    private void scrollbar(DrawContext ctx, int x, int top, int viewH, int contentH, double scroll) {
        if (contentH <= viewH) return;
        int barH = Math.max(14, viewH * viewH / contentH);
        int barY = top + (int) ((viewH - barH) * (scroll / (contentH - viewH)));
        Gfx.fillRound(ctx, x, barY, 2, barH, 1, Gfx.alpha(t.sub, 0xB0));
    }

    private static String fmt(long ms) {
        long s = Math.max(0, ms / 1000);
        return String.format("%d:%02d", s / 60, s % 60);
    }

    // ================================================================ 輸入

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (menu != Menu.NONE) {
            if (keyCode == GLFW.GLFW_KEY_ESCAPE || keyCode == GLFW.GLFW_KEY_ENTER || keyCode == GLFW.GLFW_KEY_KP_ENTER) {
                closeMenu();
                return true;
            }
            if (menu == Menu.SOURCE) cfgField.keyPressed(keyCode, scanCode, modifiers);
            if (menu == Menu.COLORS) hexField.keyPressed(keyCode, scanCode, modifiers);
            return true;
        }
        if (searchField.isFocused() && (keyCode == GLFW.GLFW_KEY_ENTER || keyCode == GLFW.GLFW_KEY_KP_ENTER)) {
            doSearch();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean charTyped(char chr, int modifiers) {
        if (menu == Menu.SOURCE) return cfgField.charTyped(chr, modifiers);
        if (menu == Menu.COLORS) return hexField.charTyped(chr, modifiers);
        if (menu != Menu.NONE) return true;
        return super.charTyped(chr, modifiers);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        mx /= k;
        my /= k;
        if (menu != Menu.NONE) return clickMenu(mx, my, button);

        if (button == 0) {
            for (Btn b : btns) {
                if (b.hit(mx, my)) {
                    b.action.run();
                    return true;
                }
            }
            if (startDrag(1, mx, my)) return true;
            Song nowSong = SongRequestClient.PLAYER.current();
            if (nowSong != null && nowSong.durationMs() > 0 && !SongRequestClient.PLAYER.isLoading() && startDrag(8, mx, my)) return true;
        }
        if (super.mouseClicked(mx, my, button)) return true;
        if (button != 0) return false;

        if (mx >= leftX && mx < leftX + leftW && my >= resY && my < resY + resH) {
            int idx = (int) ((my - (resY + 2) + resScroll) / RES_ROW);
            if (idx >= 0 && idx < results.size()) {
                Song s = results.get(idx);
                if (mx >= leftX + leftW - 28) {
                    SongRequestClient.PLAYER.enqueue(s);
                    setStatus(Text.translatable("songrequest.status.queued", s.name()).getString(), false);
                } else {
                    SongRequestClient.PLAYER.playNow(s);
                    setStatus(Text.translatable("songrequest.status.playing", s.name()).getString(), false);
                }
                return true;
            }
        }
        if (qH >= QUEUE_ROW && mx >= rightX && mx < rightX + rightW && my >= qY && my < qY + qH) {
            int idx = (int) ((my - (qY + 2) + qScroll) / QUEUE_ROW);
            List<Song> q = SongRequestClient.PLAYER.queueSnapshot();
            if (idx >= 0 && idx < q.size()) {
                if (mx >= rightX + rightW - 20) SongRequestClient.PLAYER.removeFromQueue(idx);
                else SongRequestClient.PLAYER.playFromQueue(idx);
                return true;
            }
        }
        return false;
    }

    private boolean startDrag(int id, double mx, double my) {
        if (mx >= sx[id] - 4 && mx < sx[id] + sw[id] + 4 && my >= sy[id] && my < sy[id] + 14) {
            drag = id;
            dragTo(id, mx);
            return true;
        }
        return false;
    }

    private void dragTo(int id, double mx) {
        int pad = id == 8 ? 0 : id >= 4 ? 5 : 4;
        double f = Math.max(0, Math.min(1, (mx - sx[id] - pad) / (sw[id] - 2.0 * pad)));
        Config cfg = Config.get();
        switch (id) {
            case 1 -> cfg.volume = (float) f;
            case 8 -> seekFrac = f;
            case 12 -> cfg.uiScale = (float) (Math.round((0.6 + f) * 20) / 20.0);
            case 13 -> cfg.hudScale = (float) (Math.round((0.5 + f * 2.5) * 20) / 20.0);
            case 14 -> cfg.btnX = (float) (Math.round(f * 100) / 100.0);
            case 15 -> cfg.hudY = (int) Math.round(f * 150);
            case 16 -> cfg.btnY = (float) (Math.round(f * 100) / 100.0);
            case 17 -> cfg.hudX = (float) (Math.round(f * 100) / 100.0);
            case 10 -> cfg.shadow = (float) (Math.round(f * 2 * 20) / 20.0);
            case 11 -> cfg.glare = (float) (Math.round(f * 2 * 20) / 20.0);
            case 9 -> cfg.opacity = (float) (Math.round((0.3 + f * 1.3) * 20) / 20.0);
            case 2 -> cfg.blur = (int) Math.round(f * 5);
            case 3 -> cfg.corner = (float) (Math.round((0.4 + f * 1.2) * 20) / 20.0);
            case 4 -> { ch = (float) Math.min(f, 0.9999); colorChanged(); }
            case 5 -> { cs = (float) f; colorChanged(); }
            case 6 -> { cv = (float) f; colorChanged(); }
            default -> { ca = (float) f; colorChanged(); }
        }
    }

    private static boolean in(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    private boolean clickMenu(double mx, double my, int button) {
        if (!in(mx, my, menuX, menuY, menuW, menuH)) {
            closeMenu();
            return true;
        }
        if (menu == Menu.SOURCE) {
            List<MusicProvider> all = Providers.ALL;
            for (int i = 0; i < visRows(); i++) {
                int ry = menuY + 24 + i * MENU_ROW;
                if (my >= ry && my < ry + MENU_ROW && mx >= menuX + 6 && mx < menuX + menuW - 6) {
                    Providers.select(all.get(srcScroll + i));
                    Config.save();
                    syncCfgField();
                    return true;
                }
            }
            if (cfgField.mouseClicked(mx, my, button)) setFocused(cfgField);
        } else if (menu == Menu.STYLE) {
            Config cfg = Config.get();
            int si = segHit(mx, my, menuY + 24, 3);
            if (si >= 0) cfg.style = new String[]{"glass", "google", "miuix"}[si];
            int mi = segHit(mx, my, menuY + 50, 2);
            if (mi >= 0) cfg.dark = mi == 0;
            int bx = menuX + 12, bw = menuW - 24;
            if (in(mx, my, bx, menuY + 80, bw, 18)) {
                menu = Menu.ADV;
                layoutMenu();
            } else if (in(mx, my, bx, menuY + 104, bw, 18)) {
                menu = Menu.LAYOUT;
                layoutMenu();
            } else if (in(mx, my, bx, menuY + 128, bw, 18)) {
                t = Theme.current();
                menu = Menu.COLORS;
                layoutMenu();
                loadColor();
            } else if (in(mx, my, bx, menuY + 152, bw, 18)) {
                Config.clearCustom("glass.");
                Config.clearCustom("google.");
                Config.clearCustom("miuix.");
                cfg.blur = 2;
                cfg.corner = 1.0f;
                cfg.opacity = 1.0f;
                cfg.shadow = 1.0f;
                cfg.glare = 1.0f;
            }
            Config.save();
        } else if (menu == Menu.LAYOUT) {
            for (int id = 12; id <= 17; id++) if (startDrag(id, mx, my)) return true;
            if (in(mx, my, menuX + 12, menuY + 126, menuW - 24, 18)) {
                menu = Menu.STYLE;
                layoutMenu();
            }
        } else if (menu == Menu.ADV) {
            if (t.style == Theme.Style.GLASS && startDrag(2, mx, my)) return true;
            for (int id : new int[]{3, 9, 10, 11}) if (startDrag(id, mx, my)) return true;
            if (in(mx, my, menuX + 12, menuY + 178, menuW - 24, 18)) {
                menu = Menu.STYLE;
                layoutMenu();
            }
        } else {
            for (int i = 0; i < Theme.KEYS.length; i++) {
                if (in(mx, my, menuX + 6, menuY + 28 + i * 22, 112, 20)) {
                    colorIdx = i;
                    loadColor();
                    return true;
                }
            }
            for (int id = 4; id <= 7; id++) if (startDrag(id, mx, my)) return true;
            int rx = menuX + 124, rw = menuW - 124 - 12, by = menuY + menuH - 28, w1 = (rw - 6) / 2;
            if (in(mx, my, rx, by, w1, 18)) {
                Config.get().custom.remove(colorKey());
                loadColor();
            } else if (in(mx, my, rx + w1 + 6, by, rw - w1 - 6, 18)) {
                closeMenu();
            } else if (hexField.mouseClicked(mx, my, button)) {
                setFocused(hexField);
            }
        }
        return true;
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        mx /= k;
        my /= k;
        if (drag > 0) {
            dragTo(drag, mx);
            return true;
        }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        mx /= k;
        my /= k;
        if (drag > 0) {
            if (drag == 8) {
                Song s = SongRequestClient.PLAYER.current();
                if (s != null) SongRequestClient.PLAYER.seek((long) (seekFrac * s.durationMs()));
            }
            int was = drag;
            drag = 0;
            Config.save();
            if (was == 12) init(); // 套用新的點歌台大小
            return true;
        }
        return super.mouseReleased(mx, my, button);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double horizontal, double vertical) {
        mx /= k;
        my /= k;
        if (menu == Menu.SOURCE) {
            srcScroll = Math.max(0, Math.min(Providers.ALL.size() - visRows(), srcScroll - (int) Math.signum(vertical)));
            layoutMenu();
            syncCfgField();
            return true;
        }
        if (menu != Menu.NONE) return true;
        if (mx >= leftX && mx < leftX + leftW && my >= resY && my < resY + resH) {
            double max = Math.max(0, results.size() * RES_ROW - (resH - 4));
            resScroll = Math.max(0, Math.min(max, resScroll - vertical * RES_ROW));
            return true;
        }
        if (mx >= rightX && mx < rightX + rightW && my >= qY && my < qY + qH) {
            double max = Math.max(0, SongRequestClient.PLAYER.queueSnapshot().size() * QUEUE_ROW - (qH - 4));
            qScroll = Math.max(0, Math.min(max, qScroll - vertical * QUEUE_ROW));
            return true;
        }
        return super.mouseScrolled(mx, my, horizontal, vertical);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    public void removed() {
        Blur.release();
        Config.save();
    }
}
