package com.songrequest.gui;

import com.songrequest.Config;
import com.songrequest.SongRequestClient;
import com.songrequest.api.NeteaseApi;
import com.songrequest.api.Song;
import com.songrequest.audio.MusicPlayer;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

/**
 * 點歌台：左邊搜尋＋結果列表（點歌名立即播放，點右側 + 加入佇列），
 * 右邊正在播放、控制按鈕、音量與播放佇列。完全不需要輸入指令。
 */
public class MusicScreen extends Screen {

    // 配色
    private static final int C_PANEL = 0xF0161A22;
    private static final int C_CARD = 0x28FFFFFF;
    private static final int C_HOVER = 0x33FFFFFF;
    private static final int C_ACCENT = 0xFF4FC3F7;
    private static final int C_TEXT = 0xFFFFFFFF;
    private static final int C_SUB = 0xFF9AA3B2;
    private static final int C_ERR = 0xFFFF7B7B;

    private static final int RES_ROW = 26;
    private static final int QUEUE_ROW = 16;

    // 靜態保存：關掉再開仍保留上次搜尋
    private static List<Song> results = new ArrayList<>();
    private static String lastQuery = "";
    private static String status = "";
    private static boolean statusError;
    private static boolean searching;

    private TextFieldWidget searchField;
    private ButtonWidget pauseBtn;
    private ButtonWidget hudBtn;

    private int panelW, panelH, x0, y0;
    private int leftX, leftW, rightX, rightW;
    private int resY, resH;
    private int qY, qH;
    private double resScroll, qScroll;

    public MusicScreen() {
        super(Text.translatable("songrequest.title"));
    }

    @Override
    protected void init() {
        panelW = Math.min(width - 16, 440);
        panelH = Math.min(height - 16, 250);
        x0 = (width - panelW) / 2;
        y0 = (height - panelH) / 2;
        leftX = x0 + 10;
        leftW = (panelW - 30) * 55 / 100;
        rightX = leftX + leftW + 10;
        rightW = panelW - 30 - leftW;

        String prev = searchField != null ? searchField.getText() : lastQuery;
        searchField = new TextFieldWidget(textRenderer, leftX, y0 + 22, leftW - 46, 18,
                Text.translatable("songrequest.search.hint"));
        searchField.setMaxLength(60);
        searchField.setText(prev);
        String hint = Text.translatable("songrequest.search.hint").getString();
        searchField.setSuggestion(prev.isEmpty() ? hint : null);
        searchField.setChangedListener(s -> searchField.setSuggestion(s.isEmpty() ? hint : null));
        addDrawableChild(searchField);
        setInitialFocus(searchField);

        addDrawableChild(ButtonWidget.builder(Text.translatable("songrequest.search.button"), b -> doSearch())
                .dimensions(leftX + leftW - 44, y0 + 22, 44, 18).build());

        resY = y0 + 46;
        resH = Math.max(20, panelH - 46 - 22);

        int bw = (rightW - 8) / 3;
        pauseBtn = addDrawableChild(ButtonWidget.builder(Text.translatable("songrequest.pause"),
                b -> SongRequestClient.PLAYER.togglePause()).dimensions(rightX, y0 + 90, bw, 18).build());
        addDrawableChild(ButtonWidget.builder(Text.translatable("songrequest.skip"),
                b -> SongRequestClient.PLAYER.skip()).dimensions(rightX + bw + 4, y0 + 90, bw, 18).build());
        addDrawableChild(ButtonWidget.builder(Text.translatable("songrequest.stop"),
                b -> SongRequestClient.PLAYER.stop()).dimensions(rightX + 2 * (bw + 4), y0 + 90, bw, 18).build());

        addDrawableChild(new VolumeSlider(rightX, y0 + 112, rightW, 16));

        hudBtn = addDrawableChild(ButtonWidget.builder(hudLabel(), b -> {
            Config.get().hudEnabled = !Config.get().hudEnabled;
            b.setMessage(hudLabel());
        }).dimensions(x0 + panelW - 76, y0 + 4, 66, 14).build());

        qY = y0 + 146;
        qH = Math.max(0, y0 + panelH - 8 - qY);
    }

    private static Text hudLabel() {
        return Text.translatable(Config.get().hudEnabled ? "songrequest.hud.on" : "songrequest.hud.off");
    }

    // ---------------------------------------------------------------- 動作

    private void doSearch() {
        String q = searchField.getText().trim();
        if (q.isEmpty() || searching) return;
        lastQuery = q;
        searching = true;
        setStatus(Text.translatable("songrequest.status.searching").getString(), false);
        MinecraftClient mc = MinecraftClient.getInstance();
        Thread t = new Thread(() -> {
            try {
                List<Song> found = NeteaseApi.search(q);
                mc.execute(() -> {
                    results = found;
                    resScroll = 0;
                    searching = false;
                    setStatus(found.isEmpty()
                            ? Text.translatable("songrequest.status.none").getString()
                            : Text.translatable("songrequest.status.found", found.size()).getString(), found.isEmpty());
                });
            } catch (Exception e) {
                SongRequestClient.LOGGER.warn("搜尋失敗", e);
                mc.execute(() -> {
                    searching = false;
                    setStatus(Text.translatable("songrequest.status.error").getString(), true);
                });
            }
        }, "SongRequest-Search");
        t.setDaemon(true);
        t.start();
    }

    private static void setStatus(String s, boolean err) {
        status = s;
        statusError = err;
    }

    // ---------------------------------------------------------------- 繪製

    @Override
    public void renderBackground(DrawContext context, int mouseX, int mouseY, float delta) {
        // 自己在 render() 畫背景，避免原版背景蓋住面板
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        MusicPlayer player = SongRequestClient.PLAYER;

        ctx.fill(0, 0, width, height, 0x88000000);
        ctx.fill(x0, y0, x0 + panelW, y0 + panelH, C_PANEL);
        ctx.drawBorder(x0, y0, panelW, panelH, 0x55FFFFFF);
        ctx.fill(x0, y0, x0 + panelW, y0 + 2, C_ACCENT);
        ctx.drawText(textRenderer, title, x0 + 10, y0 + 7, C_TEXT, true);

        pauseBtn.setMessage(Text.translatable(player.isPaused() ? "songrequest.resume" : "songrequest.pause"));

        drawResults(ctx, mx, my);
        drawNowPlaying(ctx, player);
        drawQueue(ctx, mx, my, player);

        // 狀態列
        if (!status.isEmpty()) {
            String s = textRenderer.trimToWidth(status, leftW);
            ctx.drawText(textRenderer, s, leftX, y0 + panelH - 16, statusError ? C_ERR : C_SUB, false);
        }

        super.render(ctx, mx, my, delta); // 按鈕、輸入框、滑桿
    }

    private void drawResults(DrawContext ctx, int mx, int my) {
        int top = resY, bottom = resY + resH;
        ctx.fill(leftX, top, leftX + leftW, bottom, C_CARD);

        if (results.isEmpty()) {
            Text hint = Text.translatable(searching ? "songrequest.status.searching" : "songrequest.empty");
            ctx.drawCenteredTextWithShadow(textRenderer, hint, leftX + leftW / 2, top + resH / 2 - 4, C_SUB);
            return;
        }

        ctx.enableScissor(leftX, top, leftX + leftW, bottom);
        int plusW = 20;
        for (int i = 0; i < results.size(); i++) {
            int ry = top + i * RES_ROW - (int) resScroll;
            if (ry + RES_ROW < top || ry > bottom) continue;
            Song s = results.get(i);
            boolean inList = my >= top && my < bottom && mx >= leftX && mx < leftX + leftW;
            boolean hover = inList && my >= ry && my < ry + RES_ROW;
            boolean hoverPlus = hover && mx >= leftX + leftW - plusW;
            if (hover) ctx.fill(leftX, ry, leftX + leftW, ry + RES_ROW, C_HOVER);

            boolean playing = SongRequestClient.PLAYER.current() != null
                    && SongRequestClient.PLAYER.current().id() == s.id();
            if (playing) ctx.fill(leftX, ry, leftX + 2, ry + RES_ROW, C_ACCENT);

            int textW = leftW - plusW - 40;
            ctx.drawText(textRenderer, textRenderer.trimToWidth(s.name(), textW), leftX + 6, ry + 4,
                    playing ? C_ACCENT : C_TEXT, false);
            String sub = s.artist() + (s.album().isEmpty() ? "" : " · " + s.album());
            ctx.drawText(textRenderer, textRenderer.trimToWidth(sub, textW), leftX + 6, ry + 15, C_SUB, false);

            String dur = s.durationText();
            ctx.drawText(textRenderer, dur, leftX + leftW - plusW - 4 - textRenderer.getWidth(dur), ry + 9, C_SUB, false);

            int px = leftX + leftW - plusW;
            if (hoverPlus) ctx.fill(px, ry + 2, px + plusW - 2, ry + RES_ROW - 2, C_HOVER);
            ctx.drawCenteredTextWithShadow(textRenderer, Text.literal("+"), px + (plusW - 2) / 2, ry + 9,
                    hoverPlus ? C_ACCENT : C_SUB);
        }
        ctx.disableScissor();

        drawScrollbar(ctx, leftX + leftW - 2, top, resH, results.size() * RES_ROW, resScroll);
    }

    private void drawNowPlaying(DrawContext ctx, MusicPlayer player) {
        int top = y0 + 22, bottom = y0 + 84;
        ctx.fill(rightX, top, rightX + rightW, bottom, C_CARD);

        Song cur = player.current();
        if (cur == null) {
            ctx.drawCenteredTextWithShadow(textRenderer, Text.translatable("songrequest.idle"),
                    rightX + rightW / 2, top + 26, C_SUB);
            return;
        }
        ctx.drawText(textRenderer, Text.translatable("songrequest.now_playing"), rightX + 6, top + 5, C_ACCENT, false);
        ctx.drawText(textRenderer, textRenderer.trimToWidth(cur.name(), rightW - 12), rightX + 6, top + 17, C_TEXT, true);
        ctx.drawText(textRenderer, textRenderer.trimToWidth(cur.artist(), rightW - 12), rightX + 6, top + 29, C_SUB, false);

        // 進度條
        long pos = player.positionMs();
        long dur = Math.max(1, cur.durationMs());
        float frac = player.isLoading() ? 0f : Math.max(0f, Math.min(1f, pos / (float) dur));
        int bx = rightX + 6, bw = rightW - 12, by = bottom - 16;
        ctx.fill(bx, by, bx + bw, by + 3, 0x44FFFFFF);
        ctx.fill(bx, by, bx + Math.round(bw * frac), by + 3, C_ACCENT);
        String left = player.isLoading() ? Text.translatable("songrequest.hud.loading").getString() : fmt(pos);
        ctx.drawText(textRenderer, left, bx, by + 6, C_SUB, false);
        String right = cur.durationText();
        ctx.drawText(textRenderer, right, bx + bw - textRenderer.getWidth(right), by + 6, C_SUB, false);
    }

    private void drawQueue(DrawContext ctx, int mx, int my, MusicPlayer player) {
        List<Song> queue = player.queueSnapshot();
        ctx.drawText(textRenderer, Text.translatable("songrequest.queue", queue.size()), rightX, y0 + 134, C_TEXT, false);
        if (qH < QUEUE_ROW) return;

        int top = qY, bottom = qY + qH;
        ctx.fill(rightX, top, rightX + rightW, bottom, C_CARD);
        if (queue.isEmpty()) {
            ctx.drawCenteredTextWithShadow(textRenderer, Text.translatable("songrequest.queue.empty"),
                    rightX + rightW / 2, top + Math.max(2, qH / 2 - 4), C_SUB);
            return;
        }
        qScroll = Math.max(0, Math.min(qScroll, Math.max(0, queue.size() * QUEUE_ROW - qH)));
        ctx.enableScissor(rightX, top, rightX + rightW, bottom);
        for (int i = 0; i < queue.size(); i++) {
            int ry = top + i * QUEUE_ROW - (int) qScroll;
            if (ry + QUEUE_ROW < top || ry > bottom) continue;
            Song s = queue.get(i);
            boolean inList = my >= top && my < bottom && mx >= rightX && mx < rightX + rightW;
            boolean hover = inList && my >= ry && my < ry + QUEUE_ROW;
            boolean hoverX = hover && mx >= rightX + rightW - 14;
            if (hover) ctx.fill(rightX, ry, rightX + rightW, ry + QUEUE_ROW, C_HOVER);
            String line = (i + 1) + ". " + s.name() + " - " + s.artist();
            ctx.drawText(textRenderer, textRenderer.trimToWidth(line, rightW - 22), rightX + 4, ry + 4, C_TEXT, false);
            ctx.drawText(textRenderer, "x", rightX + rightW - 10, ry + 4, hoverX ? C_ERR : C_SUB, false);
        }
        ctx.disableScissor();
        drawScrollbar(ctx, rightX + rightW - 2, top, qH, queue.size() * QUEUE_ROW, qScroll);
    }

    private static void drawScrollbar(DrawContext ctx, int x, int top, int viewH, int contentH, double scroll) {
        if (contentH <= viewH) return;
        int barH = Math.max(12, viewH * viewH / contentH);
        int barY = top + (int) ((viewH - barH) * (scroll / (contentH - viewH)));
        ctx.fill(x, barY, x + 2, barY + barH, 0x88FFFFFF);
    }

    private static String fmt(long ms) {
        long s = Math.max(0, ms / 1000);
        return String.format("%d:%02d", s / 60, s % 60);
    }

    // ---------------------------------------------------------------- 輸入

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (searchField.isFocused() && (keyCode == GLFW.GLFW_KEY_ENTER || keyCode == GLFW.GLFW_KEY_KP_ENTER)) {
            doSearch();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (super.mouseClicked(mx, my, button)) return true;
        if (button != 0) return false;

        // 搜尋結果
        if (mx >= leftX && mx < leftX + leftW && my >= resY && my < resY + resH) {
            int idx = (int) ((my - resY + resScroll) / RES_ROW);
            if (idx >= 0 && idx < results.size()) {
                Song s = results.get(idx);
                if (mx >= leftX + leftW - 20) {
                    SongRequestClient.PLAYER.enqueue(s);
                    setStatus(Text.translatable("songrequest.status.queued", s.name()).getString(), false);
                } else {
                    SongRequestClient.PLAYER.playNow(s);
                    setStatus(Text.translatable("songrequest.status.playing", s.name()).getString(), false);
                }
                return true;
            }
        }

        // 佇列
        if (qH >= QUEUE_ROW && mx >= rightX && mx < rightX + rightW && my >= qY && my < qY + qH) {
            int idx = (int) ((my - qY + qScroll) / QUEUE_ROW);
            List<Song> q = SongRequestClient.PLAYER.queueSnapshot();
            if (idx >= 0 && idx < q.size()) {
                if (mx >= rightX + rightW - 14) SongRequestClient.PLAYER.removeFromQueue(idx);
                else SongRequestClient.PLAYER.playFromQueue(idx);
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double horizontal, double vertical) {
        if (mx >= leftX && mx < leftX + leftW && my >= resY && my < resY + resH) {
            double max = Math.max(0, results.size() * RES_ROW - resH);
            resScroll = Math.max(0, Math.min(max, resScroll - vertical * RES_ROW));
            return true;
        }
        if (mx >= rightX && mx < rightX + rightW && my >= qY && my < qY + qH) {
            double max = Math.max(0, SongRequestClient.PLAYER.queueSnapshot().size() * QUEUE_ROW - qH);
            qScroll = Math.max(0, Math.min(max, qScroll - vertical * QUEUE_ROW));
            return true;
        }
        return super.mouseScrolled(mx, my, horizontal, vertical);
    }

    @Override
    public boolean shouldPause() {
        return false; // 單人遊戲開著點歌台時世界照常運作
    }

    @Override
    public void removed() {
        Config.save();
    }

    // ---------------------------------------------------------------- 音量滑桿

    private class VolumeSlider extends SliderWidget {
        VolumeSlider(int x, int y, int w, int h) {
            super(x, y, w, h, Text.empty(), Config.get().volume);
            updateMessage();
        }

        @Override
        protected void updateMessage() {
            setMessage(Text.translatable("songrequest.volume", (int) Math.round(value * 100)));
        }

        @Override
        protected void applyValue() {
            Config.get().volume = (float) value;
        }
    }
}
