package com.songrequest.gui;

import com.songrequest.Config;
import com.songrequest.SongRequestClient;
import com.songrequest.api.MusicProvider;
import com.songrequest.api.Providers;
import com.songrequest.api.Song;
import com.songrequest.audio.MusicPlayer;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

/**
 * 液態玻璃風格的點歌台。所有按鈕、滑桿都是自繪，只有兩個文字輸入框使用原版元件。
 * 左：搜尋與結果（點歌名播放、點 + 加入佇列）；右：正在播放、控制、音量、佇列；
 * 右上「音源」按鈕打開 API 選擇器（含各音源的 Cookie／Key／網址設定）。
 */
public class MusicScreen extends Screen {

    private static final int RES_ROW = 28;
    private static final int QUEUE_ROW = 18;

    private static List<Song> results = new ArrayList<>();
    private static String lastQuery = "";
    private static String status = "";
    private static boolean statusError;
    private static boolean searching;

    /** 自繪按鈕。 */
    private static final class Btn {
        int x, y, w, h;
        final Supplier<Text> label;
        final Runnable action;
        final boolean accent;

        Btn(Supplier<Text> label, boolean accent, Runnable action) {
            this.label = label;
            this.accent = accent;
            this.action = action;
        }

        void set(int x, int y, int w, int h) {
            this.x = x; this.y = y; this.w = w; this.h = h;
        }

        boolean hit(double mx, double my) {
            return mx >= x && mx < x + w && my >= y && my < y + h;
        }
    }

    private TextFieldWidget searchField;
    private TextFieldWidget cfgField;
    private final List<Btn> btns = new ArrayList<>();
    private Btn searchBtn, pauseBtn, skipBtn, stopBtn, sourceBtn, hudBtn, closeBtn;

    private boolean menuOpen;
    private boolean draggingVolume;

    private int panelW, panelH, x0, y0;
    private int leftX, leftW, rightX, rightW;
    private int resY, resH, qY, qH;
    private int volX, volY, volW;
    private int menuX, menuY, menuW, menuH;
    private double resScroll, qScroll;

    public MusicScreen() {
        super(Text.translatable("songrequest.title"));
    }

    // ================================================================ 初始化

    @Override
    protected void init() {
        panelW = Math.min(width - 16, 460);
        panelH = Math.min(height - 16, 264);
        x0 = (width - panelW) / 2;
        y0 = (height - panelH) / 2;
        leftX = x0 + 12;
        leftW = (panelW - 36) * 55 / 100;
        rightX = leftX + leftW + 12;
        rightW = panelW - 36 - leftW;

        btns.clear();

        // 搜尋欄（無底，外框由玻璃膠囊繪製）
        String prev = searchField != null ? searchField.getText() : lastQuery;
        searchField = new TextFieldWidget(textRenderer, leftX + 9, y0 + 36, leftW - 62, 12, Text.translatable("songrequest.search.hint"));
        searchField.setDrawsBackground(false);
        searchField.setMaxLength(60);
        searchField.setText(prev);
        String hint = Text.translatable("songrequest.search.hint").getString();
        searchField.setSuggestion(prev.isEmpty() ? hint : null);
        searchField.setChangedListener(s -> searchField.setSuggestion(s.isEmpty() ? hint : null));
        addDrawableChild(searchField);
        setInitialFocus(searchField);

        // 音源設定欄位（只在選單打開時繪製與接收事件）
        String prevCfg = cfgField != null ? cfgField.getText() : "";
        cfgField = new TextFieldWidget(textRenderer, 0, 0, 100, 12, Text.empty());
        cfgField.setDrawsBackground(false);
        cfgField.setMaxLength(600);
        cfgField.setText(prevCfg);
        cfgField.setChangedListener(v -> Config.setApi(Providers.selected().id(), v));
        addSelectableChild(cfgField);

        searchBtn = add(Text.translatable("songrequest.search.button"), true, this::doSearch);
        pauseBtn = add(null, false, () -> SongRequestClient.PLAYER.togglePause());
        skipBtn = add(Text.translatable("songrequest.skip"), false, () -> SongRequestClient.PLAYER.skip());
        stopBtn = add(Text.translatable("songrequest.stop"), false, () -> SongRequestClient.PLAYER.stop());
        hudBtn = add(null, false, () -> Config.get().hudEnabled = !Config.get().hudEnabled);
        sourceBtn = add(null, false, this::toggleMenu);
        closeBtn = add(Text.literal("×"), false, this::close);

        // 位置
        closeBtn.set(x0 + panelW - 12 - 18, y0 + 8, 18, 14);
        hudBtn.set(closeBtn.x - 4 - 62, y0 + 8, 62, 14);
        sourceBtn.set(hudBtn.x - 4 - 104, y0 + 8, 104, 14);

        searchBtn.set(leftX + leftW - 46, y0 + 31, 46, 22);
        resY = y0 + 58;
        resH = Math.max(20, panelH - 58 - 26);

        int bw = (rightW - 8) / 3;
        pauseBtn.set(rightX, y0 + 100, bw, 18);
        skipBtn.set(rightX + bw + 4, y0 + 100, bw, 18);
        stopBtn.set(rightX + 2 * (bw + 4), y0 + 100, bw, 18);

        volX = rightX + 56;
        volY = y0 + 126;
        volW = rightW - 56;

        qY = y0 + 160;
        qH = Math.max(0, y0 + panelH - 12 - qY);

        menuW = Math.min(224, panelW - 24);
        menuX = x0 + panelW - 12 - menuW;
        menuY = y0 + 26;
        menuH = 24 + Providers.ALL.size() * 18 + 44;

        syncCfgField();
    }

    private Btn add(Text fixed, boolean accent, Runnable action) {
        Btn b = new Btn(fixed == null ? () -> Text.empty() : () -> fixed, accent, action);
        btns.add(b);
        return b;
    }

    private void toggleMenu() {
        menuOpen = !menuOpen;
        if (menuOpen) {
            syncCfgField();
        } else {
            Config.save();
            setFocused(searchField);
        }
    }

    /** 讓設定欄位反映目前選取音源的設定。 */
    private void syncCfgField() {
        MusicProvider p = Providers.selected();
        cfgField.setText(Config.api(p.id()));
        int fy = menuY + 24 + Providers.ALL.size() * 18 + 20;
        cfgField.setX(menuX + 14);
        cfgField.setY(fy + 4);
        cfgField.setWidth(menuW - 28);
    }

    // ================================================================ 動作

    private void doSearch() {
        String q = searchField.getText().trim();
        if (q.isEmpty() || searching) return;
        lastQuery = q;
        searching = true;
        final MusicProvider provider = Providers.selected();
        setStatus(Text.translatable("songrequest.status.searching").getString(), false);
        MinecraftClient mc = MinecraftClient.getInstance();
        Thread t = new Thread(() -> {
            try {
                List<Song> found = provider.search(q);
                mc.execute(() -> {
                    results = found;
                    resScroll = 0;
                    searching = false;
                    setStatus(found.isEmpty()
                            ? Text.translatable("songrequest.status.none").getString()
                            : Text.translatable("songrequest.status.found", found.size()).getString(), found.isEmpty());
                });
            } catch (Exception e) {
                SongRequestClient.LOGGER.warn("搜尋失敗 ({})", provider.id(), e);
                boolean needCfg = "need_config".equals(e.getMessage());
                mc.execute(() -> {
                    searching = false;
                    setStatus(Text.translatable(needCfg ? "songrequest.status.need_cfg" : "songrequest.status.error").getString(), true);
                    if (needCfg && !menuOpen) toggleMenu();
                });
            }
        }, "SongRequest-Search");
        t.setDaemon(true);
        t.start();
    }

    private static void setStatus(String s, boolean err) {
        status = s;
        statusError = err;
    }

    // ================================================================ 繪製

    @Override
    public void renderBackground(DrawContext context, int mouseX, int mouseY, float delta) {
        // 在 render() 自己畫背景
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        MusicPlayer player = SongRequestClient.PLAYER;
        TextRenderer tr = textRenderer;
        boolean blocked = menuOpen; // 選單打開時，底下的元件不顯示 hover

        // 背景：偏冷色的漸層暗化
        ctx.fillGradient(0, 0, width, height, 0x7A0B1220, 0x9A02050C);
        Glass.panel(ctx, x0, y0, panelW, panelH, 12, true);

        // 標題列
        ctx.fill(x0 + 12, y0 + 12, x0 + 15, y0 + 20, Glass.ACCENT);
        ctx.drawText(tr, title, x0 + 20, y0 + 11, Glass.TEXT, true);
        int creditX = x0 + 20 + tr.getWidth(title) + 8;
        int creditMax = sourceBtn.x - creditX - 6;
        if (creditMax > 30) {
            ctx.drawText(tr, tr.trimToWidth(Text.translatable("songrequest.credit").getString(), creditMax), creditX, y0 + 11, Glass.SUB, false);
        }

        // 搜尋膠囊
        Glass.roundRect(ctx, leftX, y0 + 31, leftW, 22, 11, 0x30000000);
        Glass.roundOutline(ctx, leftX, y0 + 31, leftW, 22, 11, searchField.isFocused() ? 0xAA5AC8FA : 0x40FFFFFF);
        searchField.setY(y0 + 36);

        drawResults(ctx, mx, my, blocked);
        drawNowPlaying(ctx, player);
        drawVolume(ctx);
        drawQueue(ctx, mx, my, player, blocked);

        // 狀態列
        if (!status.isEmpty()) {
            ctx.drawText(tr, tr.trimToWidth(status, leftW), leftX + 2, y0 + panelH - 18, statusError ? Glass.ERR : Glass.SUB, false);
        }

        // 標題列按鈕與控制按鈕
        MusicProvider sel = Providers.selected();
        for (Btn b : btns) {
            Text label;
            if (b == pauseBtn) label = Text.translatable(player.isPaused() ? "songrequest.resume" : "songrequest.pause");
            else if (b == hudBtn) label = Text.translatable(Config.get().hudEnabled ? "songrequest.hud.on" : "songrequest.hud.off");
            else if (b == sourceBtn) label = Text.literal(tr.trimToWidth(sel.displayName(), b.w - 20) + " ▾");
            else label = b.label.get();
            boolean hover = !blocked && b.hit(mx, my);
            drawBtn(ctx, b, label, hover || (b == sourceBtn && menuOpen));
        }

        super.render(ctx, mx, my, delta); // 搜尋輸入框

        if (menuOpen) drawMenu(ctx, mx, my, delta);
    }

    private void drawBtn(DrawContext ctx, Btn b, Text label, boolean hover) {
        Glass.pill(ctx, b.x, b.y, b.w, b.h, hover, b.accent);
        int w = textRenderer.getWidth(label);
        ctx.drawText(textRenderer, label, b.x + (b.w - w) / 2, b.y + (b.h - 8) / 2 + 1, Glass.TEXT, true);
    }

    private void drawResults(DrawContext ctx, int mx, int my, boolean blocked) {
        TextRenderer tr = textRenderer;
        Glass.card(ctx, leftX, resY, leftW, resH, 8);
        int top = resY + 2, bottom = resY + resH - 2;

        if (results.isEmpty()) {
            Text hint = Text.translatable(searching ? "songrequest.status.searching" : "songrequest.empty");
            ctx.drawCenteredTextWithShadow(tr, hint, leftX + leftW / 2, resY + resH / 2 - 4, Glass.SUB);
            return;
        }
        resScroll = Math.max(0, Math.min(resScroll, Math.max(0, results.size() * RES_ROW - (bottom - top))));
        ctx.enableScissor(leftX, top, leftX + leftW, bottom);
        int plusW = 22;
        Song cur = SongRequestClient.PLAYER.current();
        for (int i = 0; i < results.size(); i++) {
            int ry = top + i * RES_ROW - (int) resScroll;
            if (ry + RES_ROW < top || ry > bottom) continue;
            Song s = results.get(i);
            boolean inList = !blocked && my >= top && my < bottom && mx >= leftX && mx < leftX + leftW;
            boolean hover = inList && my >= ry && my < ry + RES_ROW;
            boolean hoverPlus = hover && mx >= leftX + leftW - plusW - 6;
            boolean playing = cur != null && cur.key().equals(s.key());
            if (hover || playing) Glass.roundRect(ctx, leftX + 3, ry + 1, leftW - 6, RES_ROW - 2, 7, playing ? 0x335AC8FA : 0x30FFFFFF);
            if (playing) ctx.fill(leftX + 5, ry + 8, leftX + 7, ry + RES_ROW - 8, Glass.ACCENT);

            int textW = leftW - plusW - 52;
            ctx.drawText(tr, tr.trimToWidth(s.name(), textW), leftX + 12, ry + 5, playing ? Glass.ACCENT : Glass.TEXT, false);
            String sub = s.artist() + (s.album().isEmpty() ? "" : " · " + s.album());
            ctx.drawText(tr, tr.trimToWidth(sub, textW), leftX + 12, ry + 16, Glass.SUB, false);

            if (s.durationMs() > 0) {
                String dur = s.durationText();
                ctx.drawText(tr, dur, leftX + leftW - plusW - 10 - tr.getWidth(dur), ry + 10, Glass.SUB, false);
            }
            int px = leftX + leftW - plusW - 4;
            Glass.pill(ctx, px, ry + 5, plusW, 18, hoverPlus, false);
            ctx.drawCenteredTextWithShadow(tr, Text.literal("+"), px + plusW / 2, ry + 10, hoverPlus ? Glass.ACCENT : Glass.TEXT);
        }
        ctx.disableScissor();
        scrollbar(ctx, leftX + leftW - 4, top, bottom - top, results.size() * RES_ROW, resScroll);
    }

    private void drawNowPlaying(DrawContext ctx, MusicPlayer player) {
        TextRenderer tr = textRenderer;
        int top = y0 + 30, h = 62;
        Glass.card(ctx, rightX, top, rightW, h, 9);
        Song cur = player.current();
        if (cur == null) {
            ctx.drawCenteredTextWithShadow(tr, Text.translatable("songrequest.idle"), rightX + rightW / 2, top + h / 2 - 4, Glass.SUB);
            return;
        }
        ctx.drawText(tr, Text.translatable("songrequest.now_playing"), rightX + 10, top + 6, Glass.ACCENT, false);
        ctx.drawText(tr, tr.trimToWidth(cur.name(), rightW - 20), rightX + 10, top + 17, Glass.TEXT, true);
        ctx.drawText(tr, tr.trimToWidth(cur.artist(), rightW - 20), rightX + 10, top + 28, Glass.SUB, false);

        long pos = player.positionMs();
        long dur = Math.max(1, cur.durationMs());
        float frac = player.isLoading() || cur.durationMs() <= 0 ? 0f : Math.max(0f, Math.min(1f, pos / (float) dur));
        int bx = rightX + 10, bw = rightW - 20, by = top + h - 18;
        Glass.roundRect(ctx, bx, by, bw, 4, 2, 0x44FFFFFF);
        int fw = Math.round(bw * frac);
        if (fw > 0) Glass.roundRect(ctx, bx, by, Math.max(4, fw), 4, 2, Glass.ACCENT);
        if (fw > 0) Glass.roundRect(ctx, bx + fw - 3, by - 2, 7, 8, 3, 0xFFFFFFFF);
        String left = player.isLoading() ? Text.translatable("songrequest.hud.loading").getString() : fmt(pos);
        ctx.drawText(tr, left, bx, by + 7, Glass.SUB, false);
        if (cur.durationMs() > 0) {
            String right = cur.durationText();
            ctx.drawText(tr, right, bx + bw - tr.getWidth(right), by + 7, Glass.SUB, false);
        }
    }

    private void drawVolume(DrawContext ctx) {
        TextRenderer tr = textRenderer;
        float v = Config.get().volume;
        ctx.drawText(tr, Text.translatable("songrequest.volume", Math.round(v * 100)), rightX + 2, volY + 3, Glass.SUB, false);
        int ty = volY + 5;
        Glass.roundRect(ctx, volX, ty, volW, 4, 2, 0x44FFFFFF);
        int fw = Math.round(volW * v);
        if (fw > 0) Glass.roundRect(ctx, volX, ty, Math.max(4, fw), 4, 2, Glass.ACCENT);
        int kx = volX + Math.round((volW - 8) * v);
        Glass.roundRect(ctx, kx, ty - 3, 8, 10, 4, 0xFFFFFFFF);
    }

    private void drawQueue(DrawContext ctx, int mx, int my, MusicPlayer player, boolean blocked) {
        TextRenderer tr = textRenderer;
        List<Song> queue = player.queueSnapshot();
        ctx.drawText(tr, Text.translatable("songrequest.queue", queue.size()), rightX + 2, y0 + 147, Glass.TEXT, false);
        if (qH < QUEUE_ROW) return;
        Glass.card(ctx, rightX, qY, rightW, qH, 8);
        if (queue.isEmpty()) {
            ctx.drawCenteredTextWithShadow(tr, Text.translatable("songrequest.queue.empty"), rightX + rightW / 2, qY + Math.max(2, qH / 2 - 4), Glass.SUB);
            return;
        }
        int top = qY + 2, bottom = qY + qH - 2;
        qScroll = Math.max(0, Math.min(qScroll, Math.max(0, queue.size() * QUEUE_ROW - (bottom - top))));
        ctx.enableScissor(rightX, top, rightX + rightW, bottom);
        for (int i = 0; i < queue.size(); i++) {
            int ry = top + i * QUEUE_ROW - (int) qScroll;
            if (ry + QUEUE_ROW < top || ry > bottom) continue;
            Song s = queue.get(i);
            boolean inList = !blocked && my >= top && my < bottom && mx >= rightX && mx < rightX + rightW;
            boolean hover = inList && my >= ry && my < ry + QUEUE_ROW;
            boolean hoverX = hover && mx >= rightX + rightW - 20;
            if (hover) Glass.roundRect(ctx, rightX + 3, ry + 1, rightW - 6, QUEUE_ROW - 2, 6, 0x30FFFFFF);
            String line = (i + 1) + ". " + s.name() + " - " + s.artist();
            ctx.drawText(tr, tr.trimToWidth(line, rightW - 30), rightX + 9, ry + 5, Glass.TEXT, false);
            ctx.drawText(tr, "×", rightX + rightW - 14, ry + 5, hoverX ? Glass.ERR : Glass.SUB, false);
        }
        ctx.disableScissor();
        scrollbar(ctx, rightX + rightW - 4, top, bottom - top, queue.size() * QUEUE_ROW, qScroll);
    }

    /** API 選擇器：音源列表 + 該音源的設定欄位。 */
    private void drawMenu(DrawContext ctx, int mx, int my, float delta) {
        TextRenderer tr = textRenderer;
        ctx.fill(x0, y0, x0 + panelW, y0 + panelH, 0x33000000);
        Glass.panel(ctx, menuX, menuY, menuW, menuH, 10, true);
        ctx.drawText(tr, Text.translatable("songrequest.source.title"), menuX + 12, menuY + 8, Glass.TEXT, true);

        MusicProvider sel = Providers.selected();
        List<MusicProvider> all = Providers.ALL;
        for (int i = 0; i < all.size(); i++) {
            MusicProvider p = all.get(i);
            int ry = menuY + 24 + i * 18;
            boolean hover = mx >= menuX + 6 && mx < menuX + menuW - 6 && my >= ry && my < ry + 18;
            boolean on = p == sel;
            if (on || hover) Glass.roundRect(ctx, menuX + 6, ry, menuW - 12, 17, 6, on ? 0x445AC8FA : 0x30FFFFFF);
            ctx.drawText(tr, p.displayName(), menuX + 16, ry + 5, on ? Glass.ACCENT : Glass.TEXT, false);
            if (!p.tag().isEmpty()) {
                String tag = Text.translatable(p.tag()).getString();
                ctx.drawText(tr, tag, menuX + menuW - 14 - tr.getWidth(tag), ry + 5, Glass.SUB, false);
            }
        }

        int fy = menuY + 24 + all.size() * 18 + 4;
        String cfgKey = sel.configLabel();
        if (cfgKey != null) {
            ctx.drawText(tr, tr.trimToWidth(Text.translatable(cfgKey).getString(), menuW - 24), menuX + 12, fy + 2, Glass.SUB, false);
            Glass.roundRect(ctx, menuX + 8, fy + 14, menuW - 16, 20, 8, 0x30000000);
            Glass.roundOutline(ctx, menuX + 8, fy + 14, menuW - 16, 20, 8, cfgField.isFocused() ? 0xAA5AC8FA : 0x40FFFFFF);
            cfgField.setY(fy + 18);
            cfgField.render(ctx, mx, my, delta);
        } else {
            ctx.drawText(tr, Text.translatable("songrequest.cfg.none"), menuX + 12, fy + 14, Glass.SUB, false);
        }
    }

    private static void scrollbar(DrawContext ctx, int x, int top, int viewH, int contentH, double scroll) {
        if (contentH <= viewH) return;
        int barH = Math.max(14, viewH * viewH / contentH);
        int barY = top + (int) ((viewH - barH) * (scroll / (contentH - viewH)));
        Glass.roundRect(ctx, x, barY, 2, barH, 1, 0x88FFFFFF);
    }

    private static String fmt(long ms) {
        long s = Math.max(0, ms / 1000);
        return String.format("%d:%02d", s / 60, s % 60);
    }

    // ================================================================ 輸入

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (menuOpen) {
            if (keyCode == GLFW.GLFW_KEY_ESCAPE || keyCode == GLFW.GLFW_KEY_ENTER || keyCode == GLFW.GLFW_KEY_KP_ENTER) {
                toggleMenu();
                return true;
            }
            return cfgField.keyPressed(keyCode, scanCode, modifiers) || true;
        }
        if (searchField.isFocused() && (keyCode == GLFW.GLFW_KEY_ENTER || keyCode == GLFW.GLFW_KEY_KP_ENTER)) {
            doSearch();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean charTyped(char chr, int modifiers) {
        if (menuOpen) return cfgField.charTyped(chr, modifiers);
        return super.charTyped(chr, modifiers);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (menuOpen) return clickMenu(mx, my, button);

        if (button == 0) {
            for (Btn b : btns) {
                if (b.hit(mx, my)) {
                    b.action.run();
                    return true;
                }
            }
            // 音量滑桿
            if (mx >= volX - 4 && mx < volX + volW + 4 && my >= volY && my < volY + 14) {
                draggingVolume = true;
                setVolumeFromMouse(mx);
                return true;
            }
        }
        if (super.mouseClicked(mx, my, button)) return true;
        if (button != 0) return false;

        if (mx >= leftX && mx < leftX + leftW && my >= resY && my < resY + resH) {
            int idx = (int) ((my - (resY + 2) + resScroll) / RES_ROW);
            if (idx >= 0 && idx < results.size()) {
                Song s = results.get(idx);
                if (mx >= leftX + leftW - 28) {
                    SongRequestClient.PLAYER.enqueue(s);
                    setStatus(Text.translatable("songrequest.status.queued", s.name()).getString(), false);
                } else {
                    SongRequestClient.PLAYER.playNow(s);
                    setStatus(Text.translatable("songrequest.status.playing", s.name()).getString(), false);
                }
                return true;
            }
        }
        if (qH >= QUEUE_ROW && mx >= rightX && mx < rightX + rightW && my >= qY && my < qY + qH) {
            int idx = (int) ((my - (qY + 2) + qScroll) / QUEUE_ROW);
            List<Song> q = SongRequestClient.PLAYER.queueSnapshot();
            if (idx >= 0 && idx < q.size()) {
                if (mx >= rightX + rightW - 20) SongRequestClient.PLAYER.removeFromQueue(idx);
                else SongRequestClient.PLAYER.playFromQueue(idx);
                return true;
            }
        }
        return false;
    }

    private boolean clickMenu(double mx, double my, int button) {
        boolean inside = mx >= menuX && mx < menuX + menuW && my >= menuY && my < menuY + menuH;
        if (!inside) {
            // 點到來源按鈕本身＝收起；點別處也收起
            toggleMenu();
            return true;
        }
        List<MusicProvider> all = Providers.ALL;
        for (int i = 0; i < all.size(); i++) {
            int ry = menuY + 24 + i * 18;
            if (my >= ry && my < ry + 18 && mx >= menuX + 6 && mx < menuX + menuW - 6) {
                Providers.select(all.get(i));
                Config.save();
                syncCfgField();
                return true;
            }
        }
        if (cfgField.mouseClicked(mx, my, button)) {
            setFocused(cfgField);
        }
        return true;
    }

    private void setVolumeFromMouse(double mx) {
        float v = (float) Math.max(0, Math.min(1, (mx - volX - 4) / (volW - 8)));
        Config.get().volume = v;
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (draggingVolume) {
            setVolumeFromMouse(mx);
            return true;
        }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        if (draggingVolume) {
            draggingVolume = false;
            Config.save();
            return true;
        }
        return super.mouseReleased(mx, my, button);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double horizontal, double vertical) {
        if (menuOpen) return true;
        if (mx >= leftX && mx < leftX + leftW && my >= resY && my < resY + resH) {
            double max = Math.max(0, results.size() * RES_ROW - (resH - 4));
            resScroll = Math.max(0, Math.min(max, resScroll - vertical * RES_ROW));
            return true;
        }
        if (mx >= rightX && mx < rightX + rightW && my >= qY && my < qY + qH) {
            double max = Math.max(0, SongRequestClient.PLAYER.queueSnapshot().size() * QUEUE_ROW - (qH - 4));
            qScroll = Math.max(0, Math.min(max, qScroll - vertical * QUEUE_ROW));
            return true;
        }
        return super.mouseScrolled(mx, my, horizontal, vertical);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    public void removed() {
        Config.save();
    }
}
