package com.songrequest.gui;

import com.songrequest.Config;
import net.minecraft.client.gui.DrawContext;

/**
 * 兩套介面風格：液態玻璃（Apple 風：模糊背景 + 半透明玻璃）與 Google（Material You：不透明的色塊卡片）。
 * 每套各有深色／淺色；六種顏色都能在「自訂顏色」裡覆寫（含透明度）。
 */
public final class Theme {
    public enum Style { GLASS, GOOGLE }

    /** 可自訂的顏色項目。 */
    public static final String[] KEYS = {"bg", "panel", "card", "button", "accent", "text"};

    public final Style style;
    public final boolean dark;
    public final int bg, panel, card, button, accent, text;
    public final int sub, err, onAccent, buttonText, rowHover, rowSel, track, field;
    final float panelR, cardR;

    private Theme(Style style, boolean dark) {
        this.style = style;
        this.dark = dark;
        this.bg = resolve(style, dark, "bg");
        this.panel = resolve(style, dark, "panel");
        this.card = resolve(style, dark, "card");
        this.button = resolve(style, dark, "button");
        this.accent = resolve(style, dark, "accent");
        this.text = resolve(style, dark, "text");
        float k = Config.get().corner;
        this.panelR = (style == Style.GLASS ? 16f : 14f) * k;
        this.cardR = (style == Style.GLASS ? 12f : 12f) * k;
        this.sub = Gfx.alpha(text, 0xB0);
        this.err = dark ? 0xFFFF8A8A : 0xFFBA1A1A;
        this.onAccent = luminance(accent) > 0.55f ? 0xFF14181E : 0xFFFFFFFF;
        this.buttonText = text;
        this.rowHover = Gfx.alpha(text, 0x1C);
        this.rowSel = Gfx.alpha(accent, 0x44);
        this.track = Gfx.alpha(text, 0x3A);
        this.field = style == Style.GLASS
                ? (dark ? 0x40000000 : 0x78FFFFFF)
                : Gfx.mix(card, text, 0.07f);
    }

    public static Theme current() {
        Config c = Config.get();
        return new Theme("google".equals(c.style) ? Style.GOOGLE : Style.GLASS, c.dark);
    }

    public static String keyPrefix(Style s, boolean dark) {
        return (s == Style.GLASS ? "glass" : "google") + "." + (dark ? "dark" : "light") + ".";
    }

    /** 預設顏色（不含自訂）。 */
    public static int defaultColor(Style s, boolean dark, String key) {
        if (s == Style.GLASS) {
            if (dark) {
                return switch (key) {
                    case "bg" -> 0x44101828;
                    case "panel" -> 0x3CDCE6FF;
                    case "card" -> 0x22FFFFFF;
                    case "button" -> 0x38FFFFFF;
                    case "accent" -> 0xFF0A84FF;
                    default -> 0xFFFFFFFF;
                };
            }
            return switch (key) {
                case "bg" -> 0x30FFFFFF;
                case "panel" -> 0x78FFFFFF;
                case "card" -> 0x58FFFFFF;
                case "button" -> 0x99FFFFFF;
                case "accent" -> 0xFF007AFF;
                default -> 0xFF111418;
            };
        }
        if (dark) {
            return switch (key) {
                case "bg" -> 0x99000000;
                case "panel" -> 0xFF121318;
                case "card" -> 0xFF1E1F25;
                case "button" -> 0xFF3D4759;
                case "accent" -> 0xFFA8C8FF;
                default -> 0xFFE3E2E9;
            };
        }
        return switch (key) {
            case "bg" -> 0x66000000;
            case "panel" -> 0xFFFAF8FF;
            case "card" -> 0xFFEDEDF4;
            case "button" -> 0xFFD6E3FF;
            case "accent" -> 0xFF415F91;
            default -> 0xFF1A1B20;
        };
    }

    public static int resolve(Style s, boolean dark, String key) {
        Integer c = Config.customColor(keyPrefix(s, dark) + key);
        return c != null ? c : defaultColor(s, dark, key);
    }

    static float luminance(int argb) {
        float r = ((argb >> 16) & 255) / 255f, g = ((argb >> 8) & 255) / 255f, b = (argb & 255) / 255f;
        return 0.2126f * r + 0.7152f * g + 0.0722f * b;
    }

    public boolean shadowedText() {
        return style == Style.GLASS && dark;
    }

    private boolean glass() {
        return style == Style.GLASS;
    }

    /** 沒有真的模糊時，玻璃面板要更不透明一點才讀得清楚。 */
    private int frost(int argb, int extra) {
        if (!glass() || Blur.isActive()) return argb;
        return Gfx.alpha(argb, ((argb >>> 24) & 255) + extra);
    }

    // ================================================================ 繪製

    public void scrim(DrawContext c, int w, int h, boolean inWorld) {
        c.fill(0, 0, w, h, inWorld ? bg : Gfx.scaleAlpha(bg, 0.6f));
    }

    public void panel(DrawContext c, float x, float y, float w, float h) {
        panelImpl(c, x, y, w, h, false);
    }

    /** 彈出選單／對話框：比主面板更不透明，疊在主面板上也讀得清楚。 */
    public void popup(DrawContext c, float x, float y, float w, float h) {
        panelImpl(c, x, y, w, h, true);
    }

    private void panelImpl(DrawContext c, float x, float y, float w, float h, boolean popup) {
        float r = panelR;
        if (glass()) {
            int base = frost(panel, 0x30);
            if (popup) base = Gfx.alpha(base, Math.min(255, ((base >>> 24) & 255) + 0x38));
            Gfx.shadow(c, x, y + 4, w, h, r, 16, dark ? 0x58000000 : 0x2E2A3A5A);
            Gfx.fill(c, x, y, w, h, r, Gfx.vertical(y, y + h, Gfx.mix(base, 0xFFFFFFFF, dark ? 0.10f : 0.25f), base), Gfx.px());
            Gfx.fill(c, x + 0.8f, y + 0.8f, w - 1.6f, h * 0.42f, r - 0.8f,
                    Gfx.vertical(y, y + h * 0.42f, 0x2EFFFFFF, 0x00FFFFFF), Gfx.px());
            Gfx.stroke(c, x, y, w, h, r, 0.9f, Gfx.diagonal(x, y, w, h, dark ? 0xCCFFFFFF : 0xF0FFFFFF, dark ? 0x30FFFFFF : 0x80FFFFFF));
            Gfx.stroke(c, x + 1.3f, y + 1.3f, w - 2.6f, h - 2.6f, r - 1.3f, 0.5f, Gfx.solid(0x1AFFFFFF));
        } else {
            Gfx.shadow(c, x, y + 3, w, h, r, 12, dark ? 0x50000000 : 0x30000000);
            Gfx.fillRound(c, x, y, w, h, r, panel);
        }
    }

    public void card(DrawContext c, float x, float y, float w, float h) {
        float r = cardR;
        if (glass()) {
            Gfx.fill(c, x, y, w, h, r, Gfx.vertical(y, y + h, Gfx.mix(frost(card, 0x18), 0xFFFFFFFF, 0.08f), frost(card, 0x18)), Gfx.px());
            Gfx.stroke(c, x, y, w, h, r, 0.6f, Gfx.diagonal(x, y, w, h, 0x70FFFFFF, 0x18FFFFFF));
        } else {
            Gfx.fillRound(c, x, y, w, h, r, card);
        }
    }

    public void pill(DrawContext c, float x, float y, float w, float h, boolean hover, boolean accentBtn) {
        float r = h / 2f;
        if (glass()) {
            int base = accentBtn ? Gfx.alpha(accent, 0xE0) : frost(button, 0x18);
            if (hover) base = Gfx.mix(base, 0xFFFFFFFF, accentBtn ? 0.22f : 0.16f);
            if (hover && !accentBtn) base = Gfx.alpha(base, Math.min(255, ((base >>> 24) & 255) + 0x1C));
            if (accentBtn) Gfx.shadow(c, x, y + 1, w, h, r, 5, Gfx.alpha(accent, hover ? 0x70 : 0x50));
            Gfx.fill(c, x, y, w, h, r, Gfx.vertical(y, y + h, Gfx.mix(base, 0xFFFFFFFF, 0.14f), base), Gfx.px());
            Gfx.fill(c, x + 0.6f, y + 0.6f, w - 1.2f, h * 0.5f, r - 0.6f, Gfx.vertical(y, y + h * 0.5f, 0x30FFFFFF, 0x00FFFFFF), Gfx.px());
            Gfx.stroke(c, x, y, w, h, r, 0.7f, Gfx.diagonal(x, y, w, h, hover ? 0xFFFFFFFF : 0xB8FFFFFF, 0x38FFFFFF));
        } else {
            int base = accentBtn ? accent : button;
            Gfx.fillRound(c, x, y, w, h, r, base);
            if (hover) Gfx.fillRound(c, x, y, w, h, r, Gfx.alpha(accentBtn ? onAccent : buttonText, 0x1F)); // M3 state layer
        }
    }

    public int pillText(boolean accentBtn) {
        return accentBtn ? onAccent : buttonText;
    }

    public void row(DrawContext c, float x, float y, float w, float h, boolean selected) {
        float r = Math.min(glass() ? 8f : 9f, h / 2f) * Config.get().corner;
        Gfx.fillRound(c, x, y, w, h, Math.min(r, h / 2f), selected ? rowSel : rowHover);
    }

    public void field(DrawContext c, float x, float y, float w, float h, boolean focused) {
        float r = h / 2f;
        if (glass()) {
            Gfx.fillRound(c, x, y, w, h, r, field);
            Gfx.stroke(c, x, y, w, h, r, 0.8f, Gfx.solid(focused ? accent : (dark ? 0x40FFFFFF : 0x90FFFFFF)));
        } else {
            Gfx.fillRound(c, x, y, w, h, r, field);
            if (focused) Gfx.stroke(c, x, y, w, h, r, 1.2f, Gfx.solid(accent));
        }
    }

    /** 音量等滑桿，區域 (x, y, w, 14)。 */
    public void slider(DrawContext c, float x, float y, float w, float frac) {
        if (glass()) {
            Gfx.fillRound(c, x, y + 5.5f, w, 3f, 1.5f, track);
            if (frac > 0) Gfx.fillRound(c, x, y + 5.5f, Math.max(3f, w * frac), 3f, 1.5f, accent);
            float kx = x + 5.5f + (w - 11f) * frac;
            Gfx.shadow(c, kx - 5.5f, y + 2f, 11, 11, 5.5f, 3, 0x66000000);
            Gfx.circle(c, kx, y + 7f, 5.5f, 0xFFFFFFFF);
            Gfx.stroke(c, kx - 5.5f, y + 1.5f, 11, 11, 5.5f, 0.5f, Gfx.solid(0x40000000));
        } else { // M3：軌道被圓角把手切開
            float hx = x + (w - 4f) * frac;
            Gfx.fillRound(c, x, y + 4f, Math.max(0f, hx - 3f - x), 6f, 3f, accent);
            Gfx.fillRound(c, hx + 7f, y + 4f, Math.max(0f, x + w - hx - 7f), 6f, 3f, track);
            Gfx.fillRound(c, hx, y, 4f, 14f, 2f, accent);
        }
    }

    /** 播放進度。Material 風格的已播放段是流動的波浪線（暫停時變平）。 */
    public void progress(DrawContext c, float x, float y, float w, float frac, boolean animate) {
        float fw = w * frac;
        if (glass()) {
            Gfx.fillRound(c, x, y + 0.5f, w, 3f, 1.5f, track);
            if (fw > 0) Gfx.fillRound(c, x, y + 0.5f, Math.max(3f, fw), 3f, 1.5f, accent);
            if (fw > 0) {
                Gfx.shadow(c, x + fw - 4f, y - 2f, 8, 8, 4f, 3, 0x55000000);
                Gfx.circle(c, x + fw, y + 2f, 4f, 0xFFFFFFFF);
            }
        } else {
            Gfx.fillRound(c, x + fw + 2f, y + 0.5f, Math.max(0f, w - fw - 2f), 3f, 1.5f, track);
            double t = System.nanoTime() / 1.0e9;
            Gfx.wave(c, x, y + 2f, fw, animate ? 1.5f : 0f, t * 5, 2.6f, accent);
        }
    }

    /** 歌詞字幕底板。 */
    public void hudPlate(DrawContext c, int x1, int y1, int x2, int y2) {
        float w = x2 - x1, h = y2 - y1, r = Math.min(h / 2f, panelR);
        if (glass()) {
            int base = Gfx.alpha(panel, Math.min(255, ((panel >>> 24) & 255) + 0x50));
            Gfx.shadow(c, x1, y1 + 2, w, h, r, 8, 0x40000000);
            Gfx.fill(c, x1, y1, w, h, r, Gfx.vertical(y1, y2, Gfx.mix(base, 0xFFFFFFFF, 0.12f), base), Gfx.px());
            Gfx.stroke(c, x1, y1, w, h, r, 0.8f, Gfx.diagonal(x1, y1, w, h, 0xC0FFFFFF, 0x30FFFFFF));
        } else {
            Gfx.shadow(c, x1, y1 + 2, w, h, r, 8, 0x40000000);
            Gfx.fillRound(c, x1, y1, w, h, r, Gfx.alpha(panel, 0xEE));
        }
    }
}
