package com.songrequest;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

/** config/songrequest.json */
public final class Config {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("songrequest.json");

    /** 目前選擇的音源代號（見 Providers）。 */
    public String source = "netease";
    /** 各音源的設定值：netease/qq 填 Cookie，jamendo 填 client_id，custom 填 API 網址。 */
    public java.util.Map<String, String> api = new java.util.HashMap<>();

    /** 0~1，歌曲音量（再乘上遊戲的主音量與音樂音量）。 */
    public float volume = 0.8f;
    /** 是否在螢幕正上方顯示歌名與歌詞字幕。 */
    public boolean hudEnabled = true;
    /** 是否顯示翻譯歌詞（若有）。 */
    public boolean showTranslation = true;
    /** 字幕後方的半透明底板。 */
    public boolean hudBackground = true;
    /** 字幕距離螢幕頂端的像素（有 Boss 血條時可調大）。 */
    public int hudY = 6;
    /** 字幕縮放倍率。 */
    public float hudScale = 1.0f;
    /** 歌詞時間微調（毫秒），正值＝歌詞提早出現。 */
    public int lyricOffsetMs = 0;

    private static Config instance = new Config();

    public static String api(String providerId) {
        String v = instance.api == null ? null : instance.api.get(providerId);
        return v == null ? "" : v.trim();
    }

    public static void setApi(String providerId, String value) {
        if (instance.api == null) instance.api = new java.util.HashMap<>();
        instance.api.put(providerId, value == null ? "" : value.trim());
    }

    public static Config get() {
        return instance;
    }

    public static void load() {
        try {
            if (Files.exists(FILE)) {
                Config c = GSON.fromJson(Files.readString(FILE), Config.class);
                if (c != null) instance = c;
            }
        } catch (Exception e) {
            SongRequestClient.LOGGER.warn("讀取設定失敗，使用預設值", e);
        }
        instance.volume = Math.max(0f, Math.min(1f, instance.volume));
        instance.hudScale = Math.max(0.5f, Math.min(3f, instance.hudScale));
        save();
    }

    public static void save() {
        try {
            Files.createDirectories(FILE.getParent());
            Files.writeString(FILE, GSON.toJson(instance));
        } catch (IOException e) {
            SongRequestClient.LOGGER.warn("儲存設定失敗", e);
        }
    }
}
