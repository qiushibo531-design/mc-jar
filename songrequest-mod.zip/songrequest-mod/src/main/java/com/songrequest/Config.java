package com.songrequest;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

/** config/songrequest.json */
public final class Config {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("songrequest.json");

    /** 目前選擇的音源代號（見 Providers）。 */
    public String source = "netease";
    /** 介面風格：glass（液態玻璃）或 google（Material You）。 */
    public String style = "glass";
    /** 深色模式。 */
    public boolean dark = true;
    /** 背景模糊強度 0（關）~3（強），只對液態玻璃有效。 */
    public int blur = 2;
    /** 圓角大小倍率（0.4 ~ 1.6）。 */
    public float corner = 1.0f;
    /** 自訂顏色，鍵為 "風格.模式.項目"（例如 glass.dark.panel），值為 #AARRGGBB。 */
    public java.util.Map<String, String> custom = new java.util.HashMap<>();
    /** 各音源的設定值：netease/qq 填 Cookie，jamendo 填 client_id，custom 填 API 網址。 */
    public java.util.Map<String, String> api = new java.util.HashMap<>();

    /** 0~1，歌曲音量（再乘上遊戲的主音量與音樂音量）。 */
    public float volume = 0.8f;
    /** 是否在螢幕正上方顯示歌名與歌詞字幕。 */
    public boolean hudEnabled = true;
    /** 是否顯示翻譯歌詞（若有）。 */
    public boolean showTranslation = true;
    /** 字幕後方的半透明底板。 */
    public boolean hudBackground = true;
    /** 字幕距離螢幕頂端的像素（有 Boss 血條時可調大）。 */
    public int hudY = 6;
    /** 字幕縮放倍率。 */
    public float hudScale = 1.0f;
    /** 歌詞時間微調（毫秒），正值＝歌詞提早出現。 */
    public int lyricOffsetMs = 0;

    private static Config instance = new Config();

    /** 取得自訂顏色（ARGB），沒有自訂則回傳 null。 */
    public static Integer customColor(String key) {
        String v = instance.custom == null ? null : instance.custom.get(key);
        if (v == null) return null;
        try {
            String h = v.startsWith("#") ? v.substring(1) : v;
            long n = Long.parseLong(h, 16);
            return h.length() <= 6 ? (int) (0xFF000000L | n) : (int) n;
        } catch (NumberFormatException e) {
            return null;
        }
    }

    public static void setCustomColor(String key, int argb) {
        if (instance.custom == null) instance.custom = new java.util.HashMap<>();
        instance.custom.put(key, String.format("#%08X", argb));
    }

    public static void clearCustom(String prefix) {
        if (instance.custom != null) instance.custom.keySet().removeIf(k -> k.startsWith(prefix));
    }

    public static String api(String providerId) {
        String v = instance.api == null ? null : instance.api.get(providerId);
        return v == null ? "" : v.trim();
    }

    public static void setApi(String providerId, String value) {
        if (instance.api == null) instance.api = new java.util.HashMap<>();
        instance.api.put(providerId, value == null ? "" : value.trim());
    }

    public static Config get() {
        return instance;
    }

    public static void load() {
        try {
            if (Files.exists(FILE)) {
                Config c = GSON.fromJson(Files.readString(FILE), Config.class);
                if (c != null) instance = c;
            }
        } catch (Exception e) {
            SongRequestClient.LOGGER.warn("讀取設定失敗，使用預設值", e);
        }
        instance.volume = Math.max(0f, Math.min(1f, instance.volume));
        instance.hudScale = Math.max(0.5f, Math.min(3f, instance.hudScale));
        instance.blur = Math.max(0, Math.min(3, instance.blur));
        instance.corner = Math.max(0.4f, Math.min(1.6f, instance.corner));
        if (instance.custom == null) instance.custom = new java.util.HashMap<>();
        if (!"glass".equals(instance.style) && !"google".equals(instance.style)) instance.style = "glass";
        save();
    }

    public static void save() {
        try {
            Files.createDirectories(FILE.getParent());
            Files.writeString(FILE, GSON.toJson(instance));
        } catch (IOException e) {
            SongRequestClient.LOGGER.warn("儲存設定失敗", e);
        }
    }
}
