# SongRequest 点歌台（Fabric 1.20.4）
作者：狮子叔叔Uncle Lion　授权：MIT

圖形介面點歌台，參考 SimpMusic 重寫：

- **按 `M` 開啟點歌台**：搜尋 → 點歌名立即播放 / 點右側 `+` 加入佇列。完全不用輸入指令。
- **字幕在螢幕正上方**：歌名 - 歌手、當前歌詞（大字）、翻譯或下一句（小字）。不再使用 Minecraft 右下角的聲音字幕。
- 播放佇列、暫停/繼續、下一首、停止、音量滑桿；無版權/VIP 歌曲會自動跳過。
- 快捷鍵（可在「按鍵控制」改）：`M` 開啟、下一首、暫停（後兩者預設未綁定）。
- 設定檔 `config/songrequest.json`：`hudY`（字幕距頂部）、`hudScale`、`showTranslation`、`hudBackground`、`lyricOffsetMs`（歌詞快慢微調）。

## 建置
```
./gradlew build        # 產物在 build/libs/songrequest-1.2.1.jar
./gradlew runClient    # 開發環境測試
```
需要 JDK 17+。依賴：Fabric Loader ≥0.15、Fabric API 0.97.3+1.20.4。MP3 解碼庫 jlayer 已用 Jar-in-Jar 內嵌。

## 結構
- `api/` 網易雲搜尋、歌詞（LRC＋翻譯）、音源
- `audio/` 佇列與解碼播放（與 Minecraft 無關），以 OpenAL 輸出
- `gui/MusicScreen` 點歌介面　`hud/LyricsHud` 頂部字幕

## 外觀（點歌台右上角「外觀」按鈕，選了立即套用）
兩套風格：**液態玻璃**（高斯模糊背景＋毛玻璃，失敗時自動退回磨砂半透明）與 **Google**（Material You，波浪進度條）。各有深色／淺色；圓角為抗鋸齒的平滑多邊形。在「外觀」裡可調模糊強度、圓角大小，並自訂背景、面板、卡片、按鈕、強調色、文字顏色（含透明度，HSB 滑桿或十六進位）。歌詞字幕同步套用。

## 主界面點歌
主界面與暫停選單左上角有「♪ 點歌」按鈕，可在沒進世界時點歌、暫停、切歌；回到主界面後歌會繼續播，主界面也會顯示歌名與歌詞字幕。

## 音源（點歌台右上角「音源」按鈕打開 API 選擇器）
| 音源 | 說明 |
|---|---|
| 网易云音乐 | 預設；可填 Cookie 播更多歌 |
| QQ音乐 | 實驗；多數歌需 Cookie |
| 酷我音乐 / 咪咕音乐 | 實驗；非官方網頁介面 |
| Audius | 官方公開 API，免費完整曲目 |
| Deezer | 官方公開 API，30 秒試聽 |
| Jamendo | 官方 API，CC 授權完整曲目，需免費 client_id |
| 自建 API | 相容 NeteaseCloudMusicApi 的伺服器，填你自己的網址 |

各音源的 Cookie / Key / 網址直接在選擇器裡填寫（存入 `config/songrequest.json` 的 `api`）。
無法播放時動作列會顯示原因代碼，完整資訊在 `logs/latest.log` 搜尋 `SongRequest`。
新增音源：實作 `api/MusicProvider` 並加進 `api/Providers.ALL`。

## 不支援的平台
Spotify、Apple Music、YouTube Music、Tidal、汽水音乐：沒有公開的完整音訊串流（DRM 或僅限官方客戶端），不做。

## 本地音樂
遊戲目錄下會自動建立 `Local music` 資料夾，把 MP3／OGG 放進去（可放子資料夾），在點歌台的音源選「本地音乐」，搜尋欄留空按搜尋即列出全部，輸入文字可過濾。同名的 `.lrc` 會自動當作歌詞。


## 音源
網易雲音樂、QQ音樂（實驗）、酷我、咪咕（實驗）、酷狗（實驗）、Audius（免費完整）、Internet Archive（免費完整）、ccMixter（CC 授權完整）、網路電台（MP3 串流）、Deezer（30 秒試聽）、Jamendo（需 client_id）、自建 API、本地音樂。
不支援：Spotify、Apple Music、YouTube Music、Tidal、汽水音樂（沒有可公開使用的播放介面）。

## 更新紀錄
### 1.2.1
- 修正主界面按鈕文字／閃爍標語仍蓋在點歌台上（原因是文字寫入的深度擋住了面板：現在先清深度緩衝，繪製形狀時關閉深度測試）。
- 本地音樂：搜尋欄殘留文字時不再過濾成空；資料夾沒有檔案時會顯示完整路徑；音源選單裡也會顯示 `Local music` 的位置。
- 搜尋失敗會顯示具體原因（方便排查網路電台等音源）；電台增加更多鏡像節點。
### 1.2.0
- 新增音源：酷狗、Internet Archive、ccMixter、網路電台；音源清單太長時可用滾輪捲動。
- 外觀新增「進階效果」：模糊強度（0–5）、圓角、不透明度、陰影強度、高光強度（概念參考 ReGlass 的 Blur / Tint Alpha / Shadow / Glare 設定）。
- 修正：主界面的按鈕文字、閃爍標語蓋在點歌台上；取消介面文字陰影；輸入框改為自繪，不再出現重複字。
- 進度條可拖動跳轉；停止不再清空佇列，新增「清空」按鈕。
- 新增本地音樂（`Local music` 資料夾，MP3／OGG，同名 .lrc 為歌詞）。
### 1.1.0
- 兩套風格：液態玻璃（高斯模糊）與 Google（Material You），抗鋸齒圓角，六種顏色可自訂（含透明度）。
- 主界面／暫停選單也能開點歌台。
### 1.0.0
- 首版：圖形點歌台、頂部歌詞字幕、OpenAL 播放。
