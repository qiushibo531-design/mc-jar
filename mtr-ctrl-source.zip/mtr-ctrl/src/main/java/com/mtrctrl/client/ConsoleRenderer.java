package com.mtrctrl.client;

import com.mtrctrl.block.ControlConsoleBlock;
import com.mtrctrl.block.ControlConsoleBlockEntity;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.block.entity.BlockEntityRenderer;
import net.minecraft.client.render.block.entity.BlockEntityRendererFactory;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.RotationAxis;

/**
 * 控制台渲染器：把离控制台最近那条线的 ATS 运行监视画面画在上方大显示器上。
 */
public final class ConsoleRenderer implements BlockEntityRenderer<ControlConsoleBlockEntity> {

	/** 屏幕设计尺寸（像素），对应模型里上方显示器 13 × 6 个单位；1 像素 = 1/128 格。 */
	private static final int SCREEN_W = 104;
	private static final int SCREEN_H = 48;
	private static final float SCALE = 1.0F / 128.0F;

	private boolean failed;

	public ConsoleRenderer(BlockEntityRendererFactory.Context context) {
	}

	@Override
	public void render(ControlConsoleBlockEntity entity, float tickDelta, MatrixStack matrices, VertexConsumerProvider vertexConsumers, int light, int overlay) {
		if (failed) {
			return;
		}
		final MinecraftClient client = MinecraftClient.getInstance();
		if (!ClientDataUtil.isInWorld(client)) {
			return;
		}
		matrices.push();
		try {
			final NetworkSnapshot snapshot = NetworkSnapshot.get(client);
			final MapData map = MapData.get(client);
			final Direction facing = entity.getCachedState().get(ControlConsoleBlock.FACING);
			final NetworkSnapshot.Line line = AtsLayouts.nearestLine(snapshot, entity.getPos().getX() + 0.5, entity.getPos().getZ() + 0.5);

			matrices.translate(0.5, 0.5, 0.5);
			matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-facing.asRotation()));
			// 模型里上方显示器屏幕：x 1.5~14.5、y 19~25、z=13.5（朝北的一面）。
			matrices.translate(-0.40625, 1.0625, -0.3396);
			matrices.scale(SCALE, -SCALE, SCALE);

			final WallPainter painter = new WallPainter(matrices, vertexConsumers, client.textRenderer, 0, 0, SCREEN_W, SCREEN_H);
			AtsLayouts.draw(new WallCanvas(painter), snapshot, map, 0, 0, SCREEN_W, SCREEN_H, line, false);
			painter.flush();
		} catch (RuntimeException e) {
			failed = true;
			e.printStackTrace();
		} finally {
			matrices.pop();
		}
	}
}
