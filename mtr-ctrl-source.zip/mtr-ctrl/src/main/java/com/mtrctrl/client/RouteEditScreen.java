package com.mtrctrl.client;

import java.util.ArrayList;
import java.util.List;

import org.mtr.core.data.Route;
import org.mtr.core.data.RoutePlatformData;
import org.mtr.mod.client.MinecraftClientData;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

/**
 * 改路线：列出线路的停靠站，可「移除」某个站、「设为终点」截断线路。
 */
public final class RouteEditScreen extends Screen {

	private static final int ROW_HEIGHT = 18;
	private static final int BG = 0xE6222222;

	private final long routeId;
	private final List<String> stationNames = new ArrayList<>();
	private final List<ButtonZone> buttons = new ArrayList<>();

	private int scroll = 0;

	public RouteEditScreen(long routeId) {
		super(Text.translatable("mtrctrl.route.edit"));
		this.routeId = routeId;
		rebuild();
	}

	private void rebuild() {
		stationNames.clear();
		final MinecraftClient client = MinecraftClient.getInstance();
		final MinecraftClientData data = ClientDataUtil.data(client);
		if (data == null) {
			return;
		}
		final Route route = data.routeIdMap.get(routeId);
		if (route == null) {
			return;
		}
		for (final RoutePlatformData rpd : route.getRoutePlatforms()) {
			final String name = rpd.getPlatform() == null ? "" : rpd.getPlatform().getStationName();
			stationNames.add(name == null || name.isEmpty() ? "-" : name);
		}
	}

	@Override
	public boolean shouldPause() {
		return false;
	}

	@Override
	public void render(DrawContext context, int mouseX, int mouseY, float delta) {
		rebuild();
		buttons.clear();
		context.fill(0, 0, width, height, BG);

		final int titleY = 8;
		context.drawTextWithShadow(textRenderer, Text.translatable("mtrctrl.route.edit"), 8, titleY, 0xFFFFC94D);
		context.drawTextWithShadow(textRenderer, Formatting.GRAY + OverlayUtil.tr("mtrctrl.route.edit_hint"), 8, titleY + textRenderer.fontHeight + 2, 0xFFFFFFFF);

		final int listTop = titleY + textRenderer.fontHeight * 2 + 10;
		final int currentTerminal = stationNames.size() - 1;

		for (int i = 0; i < stationNames.size(); i++) {
			final int rowY = listTop + i * ROW_HEIGHT - scroll;
			if (rowY < listTop - ROW_HEIGHT || rowY > height) {
				continue;
			}
			final boolean isTerminal = i == currentTerminal;
			final String line = (i + 1) + ". " + stationNames.get(i) + (isTerminal ? "  ← " + OverlayUtil.tr("mtrctrl.route.current_terminal") : "");
			context.drawTextWithShadow(textRenderer, line, 8, rowY, isTerminal ? 0xFF3ECB6B : 0xFFFFFFFF);

			// 移除按钮
			final String removeLabel = OverlayUtil.tr("mtrctrl.route.remove");
			final int removeW = textRenderer.getWidth(removeLabel) + 10;
			final int removeX = width - removeW - 10;
			context.fill(removeX, rowY, removeX + removeW, rowY + ROW_HEIGHT - 2, 0xFF8A2E2E);
			context.drawTextWithShadow(textRenderer, removeLabel, removeX + 5, rowY + 5, 0xFFFFFFFF);
			buttons.add(new ButtonZone(i, ButtonZone.Action.REMOVE, removeX, rowY, removeW, ROW_HEIGHT - 2));

			// 设为终点按钮
			final String terminalLabel = OverlayUtil.tr("mtrctrl.route.set_terminal");
			final int terminalW = textRenderer.getWidth(terminalLabel) + 10;
			final int terminalX = removeX - terminalW - 6;
			context.fill(terminalX, rowY, terminalX + terminalW, rowY + ROW_HEIGHT - 2, 0xFF2E4E6E);
			context.drawTextWithShadow(textRenderer, terminalLabel, terminalX + 5, rowY + 5, 0xFFFFFFFF);
			buttons.add(new ButtonZone(i, ButtonZone.Action.SET_TERMINAL, terminalX, rowY, terminalW, ROW_HEIGHT - 2));
		}
	}

	@Override
	public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
		scroll -= (int) (verticalAmount * ROW_HEIGHT * 2);
		if (scroll < 0) {
			scroll = 0;
		}
		return true;
	}

	@Override
	public boolean mouseClicked(double mouseX, double mouseY, int button) {
		if (button != 0) {
			return super.mouseClicked(mouseX, mouseY, button);
		}
		for (final ButtonZone zone : buttons) {
			if (mouseX >= zone.x && mouseX <= zone.x + zone.w && mouseY >= zone.y && mouseY <= zone.y + zone.h) {
				final MinecraftClient client = MinecraftClient.getInstance();
				final boolean changed;
				if (zone.action == ButtonZone.Action.REMOVE) {
					changed = RouteEditor.removePlatform(client, routeId, zone.index);
				} else {
					changed = RouteEditor.changeTerminal(client, routeId, zone.index + 1);
				}
				if (changed) {
					rebuild();
				}
				return true;
			}
		}
		return super.mouseClicked(mouseX, mouseY, button);
	}

	private static final class ButtonZone {
		enum Action { REMOVE, SET_TERMINAL }

		final int index;
		final Action action;
		final int x;
		final int y;
		final int w;
		final int h;

		ButtonZone(int index, Action action, int x, int y, int w, int h) {
			this.index = index;
			this.action = action;
			this.x = x;
			this.y = y;
			this.w = w;
			this.h = h;
		}
	}
}
