package com.mtrctrl.client;

/**
 * 线路颜色：认得出港铁线路名时用官方色，否则按名称哈希从调色板取色。
 */
public final class LineColors {

	private static final int[] PALETTE = {
			0xFFE2231A, 0xFF0075C2, 0xFF00AB4E, 0xFF7D499D, 0xFFF7943E,
			0xFF5EB7E8, 0xFF923011, 0xFFF173AC, 0xFFB5BD00, 0xFF00888A
	};

	private static final String[][] KNOWN = {
			{"南港島|南港岛|South Island", "B5BD00"},
			{"荃灣|荃湾|Tsuen Wan", "E2231A"},
			{"港島|港岛|Island", "0075C2"},
			{"觀塘|观塘|Kwun Tong", "00AB4E"},
			{"將軍澳|将军澳|Tseung Kwan O", "7D499D"},
			{"東涌|东涌|Tung Chung", "F7943E"},
			{"東鐵|东铁|East Rail", "5EB7E8"},
			{"屯馬|屯马|Tuen Ma", "923011"},
			{"迪士尼|Disney", "F173AC"},
			{"機場|机场|Airport", "00888A"}
	};

	private LineColors() {
	}

	public static int of(String lineKey) {
		for (final String[] entry : KNOWN) {
			for (final String keyword : entry[0].split("\\|")) {
				if (lineKey.contains(keyword)) {
					return 0xFF000000 | Integer.parseInt(entry[1], 16);
				}
			}
		}
		return PALETTE[Math.floorMod(lineKey.hashCode(), PALETTE.length)];
	}
}
