package com.mtrctrl.client;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

/**
 * 对 MTR 内部数据的「容错读取」：用反射按名字取字段 / 调方法，名字对不上时返回 null / NaN，
 * 而不是让整个模组编译失败或崩溃。只用于读取站点、月台、轨道形状这类不同 MTR 小版本间可能有差异的数据。
 */
public final class Reflect {

	private static final Map<String, Method> METHODS = new HashMap<>();
	private static final Map<String, Field> FIELDS = new HashMap<>();
	private static final Method NONE;

	static {
		Method none = null;
		try {
			none = Object.class.getMethod("hashCode");
		} catch (NoSuchMethodException ignored) {
			// 不会发生
		}
		NONE = none;
	}

	private Reflect() {
	}

	/** 调用名为 name、参数个数相同的公共方法；失败返回 null。 */
	public static Object call(Object target, String name, Object... args) {
		if (target == null) {
			return null;
		}
		try {
			final Class<?> type = target.getClass();
			final String key = type.getName() + "#" + name + "#" + args.length;
			Method method = METHODS.get(key);
			if (method == null) {
				method = findMethod(type, name, args.length);
				METHODS.put(key, method == null ? NONE : method);
			}
			if (method == null || method == NONE) {
				return null;
			}
			return method.invoke(target, args);
		} catch (ReflectiveOperationException | RuntimeException e) {
			return null;
		}
	}

	/** 读取名为 name 的字段（含父类）；失败返回 null。 */
	public static Object field(Object target, String name) {
		if (target == null) {
			return null;
		}
		try {
			final Class<?> type = target.getClass();
			final String key = type.getName() + "." + name;
			Field field = FIELDS.get(key);
			if (field == null && !FIELDS.containsKey(key)) {
				for (Class<?> c = type; c != null && field == null; c = c.getSuperclass()) {
					try {
						field = c.getDeclaredField(name);
					} catch (NoSuchFieldException ignored) {
						// 继续找父类
					}
				}
				if (field != null) {
					field.setAccessible(true);
				}
				FIELDS.put(key, field);
			}
			return field == null ? null : field.get(target);
		} catch (ReflectiveOperationException | RuntimeException e) {
			return null;
		}
	}

	/** 依次尝试：同名字段、同名无参方法、getXxx 方法，取到数字就返回，否则 NaN。 */
	public static double num(Object target, String name) {
		if (target == null) {
			return Double.NaN;
		}
		Object value = field(target, name);
		if (!(value instanceof Number)) {
			value = call(target, name);
		}
		if (!(value instanceof Number)) {
			value = call(target, "get" + Character.toUpperCase(name.charAt(0)) + name.substring(1));
		}
		return value instanceof Number n ? n.doubleValue() : Double.NaN;
	}

	public static double number(Object value) {
		return value instanceof Number n ? n.doubleValue() : Double.NaN;
	}

	public static boolean bool(Object value) {
		return value instanceof Boolean b && b;
	}

	public static String string(Object value) {
		return value instanceof String s ? s : null;
	}

	private static Method findMethod(Class<?> type, String name, int argCount) {
		for (final Method method : type.getMethods()) {
			if (method.getName().equals(name) && method.getParameterCount() == argCount) {
				try {
					method.setAccessible(true);
				} catch (RuntimeException ignored) {
					// 保持默认可见性
				}
				return method;
			}
		}
		return null;
	}
}
