package com.mtrctrl.client;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.mtr.core.data.VehicleCar;
import org.mtr.core.data.Route;
import org.mtr.core.tool.Vector;
import org.mtr.libraries.it.unimi.dsi.fastutil.objects.ObjectArrayList;
import org.mtr.libraries.it.unimi.dsi.fastutil.objects.ObjectObjectImmutablePair;
import org.mtr.core.data.RoutePlatformData;
import org.mtr.mod.client.MinecraftClientData;
import org.mtr.mod.data.VehicleExtension;

import net.minecraft.client.MinecraftClient;

/**
 * 某一时刻 MTR 路网的只读快照：所有线路、每辆列车（速度 / 下一站 / 距月台）以及列车在线路上的位置。
 * 大屏与控制面板共用，约每 100 毫秒刷新一次，避免每块屏幕每帧重复计算。
 */
public final class NetworkSnapshot {

	/** 一辆在线路上运行的列车。 */
	public static final class Train {
		public VehicleExtension vehicle;
		public long id;
		public long routeId;
		public String lineKey = "?";
		public String lineShown = "-";
		public String destShown = "-";
		public String nextShown = "-";
		public double kmh;
		public Double distance;
		public boolean moving;
		public List<String> stops = new ArrayList<>();
		/** 在线路轴上的位置（0 ~ 站数-1，小数表示两站之间）；未知为 NaN。 */
		public double axisPos = Double.NaN;
		/** 下一站在线路轴上的序号，未知为 -1。 */
		public int nextAxis = -1;
		/** 是否沿线路轴的反方向行驶（画在下行轨）。 */
		public boolean reverse;
		/** 停在站外等信号 / 被拦停。 */
		public boolean waiting;
		/** 线路颜色（ARGB）。 */
		public int color = 0xFFD94BE6;
		/** 每节车厢在世界里的线段：{x1, z1, x2, z2}。 */
		public final List<double[]> cars = new ArrayList<>();
		/** 车头世界坐标，未知为 NaN。 */
		public double headX = Double.NaN;
		public double headZ = Double.NaN;
	}

	/** 一条线路（把同名、不同方向的路线合并）。 */
	public static final class Line {
		public String key;
		public String name;
		public int color;
		/** 线路轴：该线路最长一条路线的各站（已按界面语言取名）。 */
		public List<String> axis = new ArrayList<>();
		public List<String> axisRaw = new ArrayList<>();
		public final List<Train> trains = new ArrayList<>();
	}

	public final List<Line> lines = new ArrayList<>();
	public final List<Train> trains = new ArrayList<>();
	public int heldRails;
	private MinecraftClientData data;

	/** 这条轨道现在是否被占用 / 拦停（大屏上画红色）。 */
	public boolean isBlocked(String hexId) {
		return RailBlockManager.isHeld(hexId) || data != null && data.blockedRailIds.contains(hexId);
	}

	private static NetworkSnapshot cache;
	private static long cacheTimeMs;

	private NetworkSnapshot() {
	}

	public static NetworkSnapshot get(MinecraftClient client) {
		final long now = System.currentTimeMillis();
		if (cache == null || now - cacheTimeMs > 100 || now < cacheTimeMs) {
			cache = build(client);
			cacheTimeMs = now;
		}
		return cache;
	}

	private static NetworkSnapshot build(MinecraftClient client) {
		final NetworkSnapshot snap = new NetworkSnapshot();
		snap.heldRails = RailBlockManager.heldCount();
		final MinecraftClientData data = ClientDataUtil.data(client);
		if (data == null) {
			return snap;
		}
		snap.data = data;

		final Map<String, Line> byKey = new TreeMap<>();
		for (final VehicleExtension vehicle : data.vehicles) {
			try {
				final Train train = readTrain(data, vehicle);
				snap.trains.add(train);
				Line line = byKey.get(train.lineKey);
				if (line == null) {
					line = new Line();
					line.key = train.lineKey;
					line.name = train.lineShown;
					line.color = train.color;
					byKey.put(train.lineKey, line);
				}
				line.trains.add(train);
				if (train.stops.size() > line.axisRaw.size()) {
					line.axisRaw = new ArrayList<>(train.stops);
				}
			} catch (RuntimeException ignored) {
				// 某辆列车数据暂时不完整时直接跳过，不影响其他列车。
			}
		}

		for (final Line line : byKey.values()) {
			for (final String raw : line.axisRaw) {
				line.axis.add(Fonts.pick(raw));
			}
			for (final Train train : line.trains) {
				locate(line, train);
			}
			snap.lines.add(line);
		}
		return snap;
	}

	private static Train readTrain(MinecraftClientData data, VehicleExtension vehicle) {
		final Train train = new Train();
		train.vehicle = vehicle;
		train.id = vehicle.getId();
		train.routeId = vehicle.vehicleExtraData.getThisRouteId();

		final String routeRaw = nz(vehicle.vehicleExtraData.getThisRouteName());
		final String[] nameParts = routeRaw.split("\\|\\|", 2);
		train.lineKey = nameParts[0].isBlank() ? "?" : nameParts[0];
		train.lineShown = Fonts.pick(train.lineKey);

		if (train.routeId != 0) {
			final Route route = data.routeIdMap.get(train.routeId);
			if (route != null) {
				final double rawColor = Reflect.number(Reflect.call(route, "getColor"));
				train.color = Double.isNaN(rawColor) ? LineColors.of(train.lineKey) : 0xFF000000 | (int) rawColor;
				for (final RoutePlatformData rpd : route.getRoutePlatforms()) {
					final String name = rpd.getPlatform() == null ? "" : rpd.getPlatform().getStationName();
					train.stops.add(name == null ? "" : name);
				}
			}
		}

		if (nameParts.length > 1 && !nameParts[1].isBlank()) {
			train.destShown = Fonts.pick(nameParts[1]);
		} else if (!train.stops.isEmpty()) {
			train.destShown = Fonts.pick(train.stops.get(train.stops.size() - 1));
		}

		final String nextRaw = nz(vehicle.vehicleExtraData.getNextStationName());
		train.nextShown = Fonts.pick(nextRaw);
		train.kmh = ClientDataUtil.speedKmh(vehicle);
		train.moving = train.kmh > 0.5;
		try {
			train.distance = ClientDataUtil.distanceToPlatform(vehicle);
		} catch (RuntimeException e) {
			train.distance = null;
		}
		train.waiting = !train.moving && train.distance != null && train.distance > 8;
		readCars(train, vehicle);
		return train;
	}

	/** 读出每节车厢首尾转向架的世界坐标，用来在地图上按真实形状画出整列车。 */
	private static void readCars(Train train, VehicleExtension vehicle) {
		final ObjectArrayList<ObjectObjectImmutablePair<VehicleCar, ObjectArrayList<ObjectObjectImmutablePair<Vector, Vector>>>> cars =
				vehicle.getSmoothedVehicleCarsAndPositions(0);
		for (int i = 0; i < cars.size(); i++) {
			final ObjectArrayList<ObjectObjectImmutablePair<Vector, Vector>> bogies = cars.get(i).right();
			if (bogies.isEmpty()) {
				continue;
			}
			final Vector a = bogies.get(0).left();
			final Vector b = bogies.get(bogies.size() - 1).right();
			train.cars.add(new double[] {a.x, a.z, b.x, b.z});
			if (i == 0) {
				train.headX = a.x;
				train.headZ = a.z;
			}
		}
	}

	/** 算出列车在线路轴上的位置。 */
	private static void locate(Line line, Train train) {
		if (line.axisRaw.isEmpty() || train.stops.isEmpty()) {
			return;
		}
		final int i = indexOfStop(train.stops, train.nextShown);
		if (i < 0) {
			return;
		}
		final double b = axisOf(line, train, i);
		final double a = axisOf(line, train, Math.max(i - 1, 0));
		final double fraction;
		if (train.distance == null) {
			fraction = train.moving ? 0.5 : 1.0;
		} else {
			fraction = 1.0 - Math.max(0.0, Math.min(1.0, train.distance / 400.0));
		}
		train.axisPos = a + (b - a) * fraction;
		train.nextAxis = (int) Math.round(b);
		train.reverse = axisOf(line, train, 0) > axisOf(line, train, train.stops.size() - 1);
	}

	private static double axisOf(Line line, Train train, int index) {
		final String shown = Fonts.pick(train.stops.get(index));
		final int found = line.axis.indexOf(shown);
		if (found >= 0) {
			return found;
		}
		final int n = train.stops.size();
		return Math.round(index * (line.axis.size() - 1.0) / Math.max(1, n - 1));
	}

	private static int indexOfStop(List<String> stops, String nextShown) {
		for (int i = 0; i < stops.size(); i++) {
			if (Fonts.pick(stops.get(i)).equals(nextShown)) {
				return i;
			}
		}
		return -1;
	}

	private static String nz(String value) {
		return value == null ? "" : value;
	}
}
