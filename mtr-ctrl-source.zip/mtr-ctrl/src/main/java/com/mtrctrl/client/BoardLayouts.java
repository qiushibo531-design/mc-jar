package com.mtrctrl.client;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

import com.mtrctrl.client.NetworkSnapshot.Line;
import com.mtrctrl.client.NetworkSnapshot.Train;

/**
 * 大屏内容：仿港铁控制中心的两种画面。
 * <ul>
 *   <li>模式 0：线路示意图——黑底白色轨道，每条线上下行两股道，站点、信号灯、移动的列车。</li>
 *   <li>模式 1：线路总览——青色方格的 MIMIC SUMMARY、CCTV 方块、列车状态表。</li>
 * </ul>
 */
public final class BoardLayouts {

	private static final DateTimeFormatter CLOCK = DateTimeFormatter.ofPattern("HH:mm:ss");

	private static final int BG = 0xFF04070B;
	private static final int HEADER_BG = 0xFF0B1118;
	private static final int HEADER_LINE = 0xFF35506B;
	private static final int TITLE = 0xFFE8D9A8;
	private static final int CYAN = 0xFF7FD6FF;
	private static final int TRACK = 0xFFD5DCE6;
	private static final int GREEN = 0xFF2ECC71;
	private static final int RED = 0xFFFF4B3E;
	private static final int YELLOW = 0xFFFFD23F;
	private static final int MAGENTA = 0xFFD94BE6;
	private static final int TEAL = 0xFF1FB8B0;
	private static final int DIM = 0xFF8FA3B5;
	private static final int PANEL = 0xFF0A1219;

	private BoardLayouts() {
	}

	// ================================================================ 公共页眉

	private static void header(WallPainter p, NetworkSnapshot s, float w, String title) {
		p.rect(0, 0, w, 16, HEADER_BG, WallPainter.Z_PANEL);
		p.rect(0, 15, w, 1, HEADER_LINE, WallPainter.Z_LINE);
		final String clock = LocalTime.now().format(CLOCK);
		if (w < 200) {
			p.text(clock, w / 2, 4, 9, 0xFFFFFFFF, 1);
			return;
		}
		p.text(title, 6, 4, 8, TITLE, 0);
		p.text(clock, w / 2, 3, 10, 0xFFFFFFFF, 1);
		final String stats = OverlayUtil.tr("mtrctrl.board.trains") + " " + s.trains.size()
				+ "   " + OverlayUtil.tr("mtrctrl.board.held") + " " + s.heldRails;
		p.text(stats, w - 6, 4, 8, CYAN, 2);
	}

	// ================================================================ 模式 0：线路示意图

	public static void diagram(WallPainter p, NetworkSnapshot s, float w, float h) {
		p.rect(0, 0, w, h, BG, WallPainter.Z_BG);
		header(p, s, w, OverlayUtil.tr("mtrctrl.board.title"));

		final float top = 20;
		final float bottom = h - (w >= 200 ? 12 : 2);
		if (s.lines.isEmpty()) {
			p.text(OverlayUtil.tr("mtrctrl.board.no_train"), w / 2, h / 2 - 4, 9, CYAN, 1);
			return;
		}

		final float avail = bottom - top;
		final float laneH = Math.min(60, Math.max(30, avail / s.lines.size()));
		final int fit = (int) Math.max(1, Math.floor(avail / laneH));
		final int shown = Math.min(fit, s.lines.size());
		for (int i = 0; i < shown; i++) {
			lane(p, s.lines.get(i), top + i * laneH, laneH, w);
		}
		if (shown < s.lines.size()) {
			p.text("+" + (s.lines.size() - shown) + " " + OverlayUtil.tr("mtrctrl.board.more_lines"), w - 6, bottom - 8, 6, DIM, 2);
		}
		if (w >= 200) {
			legend(p, w, h);
		}
	}

	private static void lane(WallPainter p, Line line, float ly, float laneH, float w) {
		final float tagW = w < 200 ? 0 : 48;
		final float xs = tagW + 8;
		final float xe = w - 8;
		final float upY = ly + laneH * 0.40F;
		final float dnY = upY + Math.min(12, laneH * 0.28F);

		if (tagW > 0) {
			final float chipY = (upY + dnY) / 2 - 7;
			p.rect(4, chipY, tagW - 6, 14, line.color, WallPainter.Z_PANEL);
			p.text(p.fit(line.name, 8, tagW - 12), 4 + (tagW - 6) / 2, chipY + 3, 8, 0xFFFFFFFF, 1);
		}
		p.rect(xs - 6, ly + 1, xe - xs + 12, 1.5F, line.color, WallPainter.Z_LINE);

		// 双股轨道 + 两端渡线
		p.rect(xs - 4, upY - 0.6F, xe - xs + 8, 1.2F, TRACK, WallPainter.Z_LINE);
		p.rect(xs - 4, dnY - 0.6F, xe - xs + 8, 1.2F, TRACK, WallPainter.Z_LINE);
		p.line(xs - 4, upY, xs - 8, (upY + dnY) / 2, 1.2F, TRACK, WallPainter.Z_LINE);
		p.line(xs - 8, (upY + dnY) / 2, xs - 4, dnY, 1.2F, TRACK, WallPainter.Z_LINE);
		p.line(xe + 4, upY, xe + 8, (upY + dnY) / 2, 1.2F, TRACK, WallPainter.Z_LINE);
		p.line(xe + 8, (upY + dnY) / 2, xe + 4, dnY, 1.2F, TRACK, WallPainter.Z_LINE);

		final int n = line.axis.size();
		final boolean[] redUp = new boolean[n];
		final boolean[] redDown = new boolean[n];
		for (final Train t : line.trains) {
			if (t.waiting && t.nextAxis >= 0 && t.nextAxis < n) {
				(t.reverse ? redDown : redUp)[t.nextAxis] = true;
			}
		}

		float lastAbove = -1000;
		float lastBelow = -1000;
		for (int i = 0; i < n; i++) {
			final float x = axisX(i, n, xs, xe);
			p.rect(x - 0.7F, upY, 1.4F, dnY - upY, line.color, WallPainter.Z_MARK);
			p.rect(x - 1.8F, upY - 1.8F, 3.6F, 3.6F, 0xFFFFFFFF, WallPainter.Z_MARK);
			p.rect(x - 1.8F, dnY - 1.8F, 3.6F, 3.6F, 0xFFFFFFFF, WallPainter.Z_MARK);
			p.rect(x + 3, upY - 3.5F, 2, 2, redUp[i] ? RED : GREEN, WallPainter.Z_MARK);
			p.rect(x + 3, dnY + 1.5F, 2, 2, redDown[i] ? RED : GREEN, WallPainter.Z_MARK);

			final String name = line.axis.get(i);
			final float tw = p.width(name, 6);
			if (x - tw / 2 > lastAbove + 2) {
				p.text(name, x, upY - 11, 6, 0xFFE9EEF5, 1);
				lastAbove = x + tw / 2;
			} else if (x - tw / 2 > lastBelow + 2) {
				p.text(name, x, dnY + 4.5F, 6, 0xFFB8C4D2, 1);
				lastBelow = x + tw / 2;
			}
		}

		// 列车
		for (final Train t : line.trains) {
			if (Double.isNaN(t.axisPos)) {
				continue;
			}
			final float x = axisXf((float) t.axisPos, n, xs, xe);
			final float y = t.reverse ? dnY : upY;
			p.rect(x - 4.8F, y - 3.0F, 9.6F, 6.0F, 0xFFFFFFFF, WallPainter.Z_MARK + 0.3F);
			p.rect(x - 4.0F, y - 2.2F, 8.0F, 4.4F, t.moving ? MAGENTA : YELLOW, WallPainter.Z_MARK + 0.6F);
		}
		p.rect(0, ly + laneH - 1, w, 1, 0xFF131C26, WallPainter.Z_PANEL);
	}

	private static float axisX(int i, int n, float xs, float xe) {
		return axisXf(i, n, xs, xe);
	}

	private static float axisXf(float pos, int n, float xs, float xe) {
		if (n <= 1) {
			return (xs + xe) / 2;
		}
		return xs + (xe - xs) * pos / (n - 1);
	}

	private static void legend(WallPainter p, float w, float h) {
		final float y = h - 9;
		float x = 6;
		p.rect(x, y + 1, 8, 4.4F, MAGENTA, WallPainter.Z_MARK);
		p.text(OverlayUtil.tr("mtrctrl.board.legend_moving"), x + 11, y, 6, DIM, 0);
		x += 11 + p.width(OverlayUtil.tr("mtrctrl.board.legend_moving"), 6) + 10;
		p.rect(x, y + 1, 8, 4.4F, YELLOW, WallPainter.Z_MARK);
		p.text(OverlayUtil.tr("mtrctrl.board.legend_stopped"), x + 11, y, 6, DIM, 0);
		x += 11 + p.width(OverlayUtil.tr("mtrctrl.board.legend_stopped"), 6) + 10;
		p.rect(x, y + 1.2F, 3, 3, GREEN, WallPainter.Z_MARK);
		p.rect(x + 4, y + 1.2F, 3, 3, RED, WallPainter.Z_MARK);
		p.text(OverlayUtil.tr("mtrctrl.board.legend_signal"), x + 10, y, 6, DIM, 0);
	}

	// ================================================================ 模式 1：线路总览

	public static void summary(WallPainter p, NetworkSnapshot s, float w, float h) {
		p.rect(0, 0, w, h, BG, WallPainter.Z_BG);
		header(p, s, w, OverlayUtil.tr("mtrctrl.board.summary"));

		final boolean wide = w >= 260;
		final float split = wide ? w * 0.56F : w;
		mimic(p, s, 4, 20, split - 8, h - 24);
		if (wide) {
			table(p, s, split + 2, 20, w - split - 6, h - 24);
		}
	}

	/** 左侧：MIMIC SUMMARY 青色方格 + 下方的 CCTV 方块。 */
	private static void mimic(WallPainter p, NetworkSnapshot s, float x, float y, float width, float height) {
		p.rect(x, y, width, height, PANEL, WallPainter.Z_PANEL);
		p.text(OverlayUtil.tr("mtrctrl.board.mimic"), x + 4, y + 3, 7, TITLE, 0);

		float cy = y + 16;
		final float tag = width < 120 ? 0 : 34;
		final float sq = 8;
		final float gap = 2;
		final int perRow = (int) Math.max(1, Math.floor((width - tag - 10) / (sq + gap)));

		if (s.lines.isEmpty()) {
			p.text(OverlayUtil.tr("mtrctrl.board.no_train"), x + width / 2, y + height / 2 - 4, 8, CYAN, 1);
			return;
		}
		for (final Line line : s.lines) {
			final int n = Math.max(1, line.axis.size());
			final int rows = (n + perRow - 1) / perRow;
			final float rowsH = rows * (sq + gap) + 4;
			if (cy + rowsH > y + height - 4) {
				break;
			}
			if (tag > 0) {
				p.rect(x + 4, cy, tag - 4, 10, line.color, WallPainter.Z_MARK);
				p.text(p.fit(line.name, 7, tag - 8), x + 4 + (tag - 4) / 2, cy + 1.5F, 7, 0xFFFFFFFF, 1);
			}
			for (int i = 0; i < n; i++) {
				final int col = i % perRow;
				final int row = i / perRow;
				int color = TEAL;
				for (final Train t : line.trains) {
					if (t.nextAxis == i) {
						color = t.waiting ? RED : YELLOW;
						break;
					}
				}
				p.rect(x + tag + 4 + col * (sq + gap), cy + row * (sq + gap), sq, sq, color, WallPainter.Z_MARK);
			}
			cy += rowsH + 2;
		}

		// CCTV 装饰方块
		final float camTop = cy + 2;
		final float camH = y + height - 4 - camTop;
		if (camH >= 36 && width >= 100) {
			p.text("CCTV", x + 4, camTop, 6, DIM, 0);
			final int cols = 3;
			final int rowsCam = camH >= 66 ? 2 : 1;
			final float cw = (width - 8 - (cols - 1) * 3) / cols;
			final float ch = Math.min(30, (camH - 10 - (rowsCam - 1) * 3) / rowsCam);
			for (int r = 0; r < rowsCam; r++) {
				for (int c = 0; c < cols; c++) {
					final float cx = x + 4 + c * (cw + 3);
					final float cyy = camTop + 9 + r * (ch + 3);
					p.rect(cx, cyy, cw, ch, 0xFF2A3038, WallPainter.Z_MARK);
					p.rect(cx + 1, cyy + 1, cw - 2, ch - 2, 0xFF151A20, WallPainter.Z_MARK + 0.3F);
					p.text("CAM " + (r * cols + c + 1), cx + 3, cyy + 2, 5, DIM, 0);
				}
			}
		}
	}

	/** 右侧：列车状态表。 */
	private static void table(WallPainter p, NetworkSnapshot s, float x, float y, float width, float height) {
		p.rect(x, y, width, height, PANEL, WallPainter.Z_PANEL);
		p.text(OverlayUtil.tr("mtrctrl.board.table"), x + 4, y + 3, 7, TITLE, 0);

		final float[] colX = {4, width * 0.20F, width * 0.42F, width * 0.68F, width * 0.80F};
		final float[] colW = {colX[1] - colX[0] - 2, colX[2] - colX[1] - 2, colX[3] - colX[2] - 2, colX[4] - colX[3] - 2, width - colX[4] - 4};
		final String[] heads = {
				OverlayUtil.tr("mtrctrl.board.col_line"), OverlayUtil.tr("mtrctrl.board.col_dest"),
				OverlayUtil.tr("mtrctrl.board.col_next"), OverlayUtil.tr("mtrctrl.board.col_speed"),
				OverlayUtil.tr("mtrctrl.board.col_dist")};
		final float headY = y + 15;
		for (int c = 0; c < heads.length; c++) {
			p.text(p.fit(heads[c], 6, colW[c]), x + colX[c], headY, 6, DIM, 0);
		}
		p.rect(x + 2, headY + 9, width - 4, 1, HEADER_LINE, WallPainter.Z_LINE);

		final float rowH = 9;
		final int maxRows = (int) Math.max(0, Math.floor((y + height - (headY + 12)) / rowH));
		final List<Train> trains = s.trains;
		for (int i = 0; i < Math.min(maxRows, trains.size()); i++) {
			final Train t = trains.get(i);
			final float ry = headY + 12 + i * rowH;
			final int color = t.moving ? CYAN : YELLOW;
			p.text(p.fit(t.lineShown, 6, colW[0]), x + colX[0], ry, 6, color, 0);
			p.text(p.fit(t.destShown, 6, colW[1]), x + colX[1], ry, 6, color, 0);
			p.text(p.fit(t.nextShown, 6, colW[2]), x + colX[2], ry, 6, color, 0);
			p.text(String.format("%.0f", t.kmh), x + colX[3], ry, 6, 0xFFFFFFFF, 0);
			p.text(t.distance == null ? "-" : String.format("%.0f", t.distance), x + colX[4], ry, 6, 0xFFFFFFFF, 0);
		}
		if (trains.size() > maxRows && maxRows > 0) {
			p.text("+" + (trains.size() - maxRows), x + width - 4, y + height - 9, 6, DIM, 2);
		}
	}
}
