package com.mtrctrl.client;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

import com.mtrctrl.client.NetworkSnapshot.Line;
import com.mtrctrl.client.NetworkSnapshot.Train;

/**
 * 大屏内容：仿控制中心的三种画面。
 * <ul>
 *   <li>模式 0：全网地图——所有轨道按真实形状（含弯道）画出，叠加车站、月台、换乘站、信号、占用（红）和整列车。</li>
 *   <li>模式 1：站场放大图——以最近的车站为中心放大，显示月台编号、股道、信号和列车。</li>
 *   <li>模式 2：全网总览——青色方格的 MIMIC SUMMARY、CCTV 方块、列车状态表。</li>
 * </ul>
 */
public final class BoardLayouts {

	private static final DateTimeFormatter CLOCK = DateTimeFormatter.ofPattern("HH:mm:ss");

	private static final int BG = 0xFF04070B;
	private static final int HEADER_BG = 0xFF0B1118;
	private static final int HEADER_LINE = 0xFF35506B;
	private static final int TITLE = 0xFFE8D9A8;
	private static final int CYAN = 0xFF7FD6FF;
	private static final int TRACK = 0xFFD5DCE6;
	private static final int GREEN = 0xFF2ECC71;
	private static final int RED = 0xFFFF4B3E;
	private static final int YELLOW = 0xFFFFD23F;
	private static final int MAGENTA = 0xFFD94BE6;
	private static final int TEAL = 0xFF1FB8B0;
	private static final int DIM = 0xFF8FA3B5;
	private static final int PANEL = 0xFF0A1219;

	private BoardLayouts() {
	}

	// ================================================================ 公共页眉

	private static void header(WallPainter p, NetworkSnapshot s, float w, String title) {
		p.rect(0, 0, w, 16, HEADER_BG, WallPainter.Z_PANEL);
		p.rect(0, 15, w, 1, HEADER_LINE, WallPainter.Z_LINE);
		final String clock = LocalTime.now().format(CLOCK);
		if (w < 200) {
			p.text(clock, w / 2, 4, 9, 0xFFFFFFFF, 1);
			return;
		}
		p.text(title, 6, 4, 8, TITLE, 0);
		p.text(clock, w / 2, 3, 10, 0xFFFFFFFF, 1);
		final String stats = OverlayUtil.tr("mtrctrl.board.trains") + " " + s.trains.size()
				+ "   " + OverlayUtil.tr("mtrctrl.board.held") + " " + s.heldRails;
		p.text(stats, w - 6, 4, 8, CYAN, 2);
	}

	// ================================================================ 地图模式（真实轨道几何）

	private static final int PLATFORM_DEFAULT = 0xFFD94BE6;
	private static final int GOLD = 0xFFFFC94D;

	/** 世界坐标 → 设计坐标的变换。 */
	private static final class View {
		final double ox;
		final double oz;
		final float px;
		final float py;
		final float scale;

		View(double ox, double oz, float px, float py, float scale) {
			this.ox = ox;
			this.oz = oz;
			this.px = px;
			this.py = py;
			this.scale = scale;
		}

		float sx(double x) {
			return px + (float) ((x - ox) * scale);
		}

		float sy(double z) {
			return py + (float) ((z - oz) * scale);
		}

		/** 把整张路网等比缩放后居中放进给定矩形。 */
		static View fit(MapData m, float ax, float ay, float aw, float ah) {
			final double ex = Math.max(m.maxX - m.minX, 20);
			final double ez = Math.max(m.maxZ - m.minZ, 20);
			final float scale = (float) Math.min(aw / ex, ah / ez);
			return new View((m.minX + m.maxX) / 2, (m.minZ + m.maxZ) / 2, ax + aw / 2, ay + ah / 2, scale);
		}

		/** 以某个车站为中心放大。 */
		static View zoom(MapData.Station st, float ax, float ay, float aw, float ah) {
			final double extent = Math.max(Math.max(st.maxX - st.minX, st.maxZ - st.minZ), 12) + 36;
			final float scale = (float) Math.max(0.4, Math.min(8.0, Math.min(aw, ah) / extent));
			return new View(st.cx, st.cz, ax + aw / 2, ay + ah / 2, scale);
		}
	}

	/** 全网地图：所有轨道按真实形状（含弯道）画出，叠加车站、月台、信号、列车。 */
	public static void map(WallPainter p, NetworkSnapshot s, MapData m, float w, float h) {
		p.rect(0, 0, w, h, BG, WallPainter.Z_BG);
		header(p, s, w, OverlayUtil.tr("mtrctrl.board.title"));
		final boolean full = w >= 200;
		final float ax = 4;
		final float ay = 20;
		final float aw = w - 8;
		final float ah = h - ay - (full ? 12 : 3);
		if (m.isEmpty()) {
			p.text(OverlayUtil.tr("mtrctrl.board.no_rail"), w / 2, h / 2 - 4, 9, CYAN, 1);
			return;
		}
		final View view = View.fit(m, ax, ay, aw, ah);
		drawNetwork(p, s, m, view, false);
		drawStations(p, m, view, null, w, h, 0, false);
		drawTrains(p, s, view, false);
		if (full) {
			legend(p, w, h);
		}
	}

	/** 站场放大图：以离大屏最近的车站为中心，看清月台编号、股道、信号与列车。 */
	public static void zoom(WallPainter p, NetworkSnapshot s, MapData m, float w, float h, double boardX, double boardZ) {
		MapData.Station focus = null;
		double best = Double.MAX_VALUE;
		for (final MapData.Station st : m.stations) {
			final double d = (st.cx - boardX) * (st.cx - boardX) + (st.cz - boardZ) * (st.cz - boardZ);
			if (d < best) {
				best = d;
				focus = st;
			}
		}
		if (focus == null) {
			map(p, s, m, w, h);
			return;
		}
		p.rect(0, 0, w, h, BG, WallPainter.Z_BG);
		header(p, s, w, OverlayUtil.tr("mtrctrl.board.title"));

		final float ax = 4;
		final float ay = 20;
		final float aw = w - 8;
		final float ah = h - ay - 4;
		final View view = View.zoom(focus, ax, ay, aw, ah);
		drawNetwork(p, s, m, view, true);

		// 站台范围
		final float x0 = view.sx(focus.minX);
		final float y0 = view.sy(focus.minZ);
		final float x1 = view.sx(focus.maxX);
		final float y1 = view.sy(focus.maxZ);
		if (p.visible(x0, y0, x1, y1)) {
			p.rect(x0, y0, x1 - x0, 0.8F, 0xFF4B5C6E, WallPainter.Z_PANEL);
			p.rect(x0, y1, x1 - x0, 0.8F, 0xFF4B5C6E, WallPainter.Z_PANEL);
			p.rect(x0, y0, 0.8F, y1 - y0, 0xFF4B5C6E, WallPainter.Z_PANEL);
			p.rect(x1, y0, 0.8F, y1 - y0, 0xFF4B5C6E, WallPainter.Z_PANEL);
		}

		// 月台编号
		for (final MapData.Platform platform : focus.platforms) {
			final float px = view.sx(platform.x);
			final float py = view.sy(platform.z);
			final int color = platform.color != 0 ? platform.color : PLATFORM_DEFAULT;
			p.rect(px - 6, py - 14, 12, 9, color, WallPainter.Z_MARK);
			p.text(platform.name.isEmpty() ? "-" : platform.name, px, py - 13, 8, 0xFFFFFFFF, 1);
		}
		drawTrains(p, s, view, true);
		drawStations(p, m, view, focus, w, h, 1, true);

		// 左上角：站名、坐标、线路色块
		final String name = Fonts.pick(focus.name);
		p.text(name, ax + 6, ay + 4, 14, 0xFFFFFFFF, 0);
		p.text(String.format("(%.0f, %.0f)", focus.cx, focus.cz), ax + 6, ay + 20, 7, DIM, 0);
		float chipX = ax + 6;
		for (final int color : focus.colors) {
			p.rect(chipX, ay + 31, 14, 4, color, WallPainter.Z_MARK);
			chipX += 16;
		}
		if (focus.interchange) {
			p.text(OverlayUtil.tr("mtrctrl.board.interchange"), ax + 6, ay + 38, 7, GOLD, 0);
		}
	}

	private static void drawNetwork(WallPainter p, NetworkSnapshot s, MapData m, View v, boolean zoom) {
		for (final MapData.RailLine r : m.rails) {
			final float bx0 = v.sx(r.minX) - 4;
			final float by0 = v.sy(r.minZ) - 4;
			final float bx1 = v.sx(r.maxX) + 4;
			final float by1 = v.sy(r.maxZ) + 4;
			if (!p.visible(bx0, by0, bx1, by1)) {
				continue;
			}
			final boolean blocked = s.isBlocked(r.hexId);
			final int color;
			final float thickness;
			final float z;
			if (r.platform) {
				color = blocked ? RED : r.color != 0 ? r.color : PLATFORM_DEFAULT;
				thickness = zoom ? 3.6F : 2.2F;
				z = WallPainter.Z_LINE + 0.3F;
			} else if (r.siding) {
				color = blocked ? RED : 0xFF56626E;
				thickness = zoom ? 1.4F : 1.0F;
				z = WallPainter.Z_LINE - 0.2F;
			} else {
				color = blocked ? RED : TRACK;
				thickness = zoom ? 1.8F : 1.2F;
				z = WallPainter.Z_LINE;
			}
			for (int i = 0; i + 1 < r.xs.length; i++) {
				p.line(v.sx(r.xs[i]), v.sy(r.zs[i]), v.sx(r.xs[i + 1]), v.sy(r.zs[i + 1]), thickness, color, z);
			}
			if (r.signal) {
				final float size = zoom ? 3.4F : 2.2F;
				final float sx = v.sx(r.xs[0]);
				final float sy = v.sy(r.zs[0]);
				p.rect(sx - size / 2, sy - size / 2, size, size, blocked ? RED : GREEN, WallPainter.Z_MARK);
			}
		}
	}

	private static void drawTrains(WallPainter p, NetworkSnapshot s, View v, boolean zoom) {
		final float body = zoom ? 3.6F : 2.6F;
		for (final NetworkSnapshot.Train t : s.trains) {
			final int color = t.moving ? t.color : YELLOW;
			for (final double[] c : t.cars) {
				final float x1 = v.sx(c[0]);
				final float y1 = v.sy(c[1]);
				final float x2 = v.sx(c[2]);
				final float y2 = v.sy(c[3]);
				p.line(x1, y1, x2, y2, body + 1.6F, 0xFFFFFFFF, WallPainter.Z_MARK + 0.2F);
				p.line(x1, y1, x2, y2, body, color, WallPainter.Z_MARK + 0.5F);
			}
			if (zoom && !Double.isNaN(t.headX)) {
				final float hx = v.sx(t.headX);
				final float hy = v.sy(t.headZ);
				p.text(t.lineShown + " → " + t.destShown, hx + 5, hy - 10, 6, 0xFFFFFFFF, 0);
			}
		}
	}

	private record Placed(String text, float x, float y, float size, int color, int[] chips) {
	}

	/** 站名排版缓存：最多同时缓存 8 种（路网版本 + 画面尺寸 + 模式）组合。 */
	private static final java.util.LinkedHashMap<String, List<Placed>> LABEL_CACHE = new java.util.LinkedHashMap<>(16, 0.75F, true) {
		@Override
		protected boolean removeEldestEntry(java.util.Map.Entry<String, List<Placed>> eldest) {
			return size() > 8;
		}
	};

	/** 车站标记 + 不重叠的站名（结果按「路网版本 + 画面尺寸 + 模式」缓存）。 */
	private static void drawStations(WallPainter p, MapData m, View v, MapData.Station focus, float w, float h, int mode, boolean zoom) {
		final String key = m.version + "|" + w + "|" + h + "|" + mode + "|" + (focus == null ? "" : focus.name + focus.cx);
		final List<float[]> taken = new java.util.ArrayList<>();

		// 标记
		for (final MapData.Station st : m.stations) {
			final float mx = v.sx(st.cx);
			final float my = v.sy(st.cz);
			final float r = zoom ? (st.interchange ? 5F : 3.6F) : (st.interchange ? 3.6F : 2.6F);
			if (!zoom || st != focus) {
				if (p.visible(mx - r - 2, my - r - 2, mx + r + 2, my + r + 2)) {
					p.rect(mx - r - 1, my - r - 1, 2 * r + 2, 2 * r + 2, 0xFFFFFFFF, WallPainter.Z_MARK + 0.8F);
					p.rect(mx - r, my - r, 2 * r, 2 * r, 0xFF0E1620, WallPainter.Z_MARK + 1.0F);
					if (st.interchange) {
						p.rect(mx - r + 1.3F, my - r + 1.3F, 2 * r - 2.6F, 2 * r - 2.6F, GOLD, WallPainter.Z_MARK + 1.2F);
					}
				}
			}
			taken.add(new float[] {mx - r - 1, my - r - 1, mx + r + 1, my + r + 1});
		}

		List<Placed> labels = LABEL_CACHE.get(key);
		if (labels == null) {
			labels = new java.util.ArrayList<>();
			LABEL_CACHE.put(key, labels);
			final List<MapData.Station> order = new java.util.ArrayList<>(m.stations);
			order.sort((a, b) -> Boolean.compare(b.interchange, a.interchange));
			for (final MapData.Station st : order) {
				if (st == focus) {
					continue;
				}
				final String name = Fonts.pick(st.name);
				final float size = zoom ? 7 : (st.interchange ? 7 : 6);
				final float tw = p.width(name, size);
				final float th = size + 1;
				final float mx = v.sx(st.cx);
				final float my = v.sy(st.cz);
				final float r = zoom ? (st.interchange ? 5F : 3.6F) : (st.interchange ? 3.6F : 2.6F);
				final float extra = st.interchange ? 5 : 0;
				final float[][] candidates = {
						{mx + r + 3, my - th / 2},
						{mx - r - 3 - tw, my - th / 2},
						{mx - tw / 2, my - r - th - 2},
						{mx - tw / 2, my + r + 2}
				};
				for (final float[] c : candidates) {
					final float[] box = {c[0] - 1, c[1] - 1, c[0] + tw + 1, c[1] + th + extra + 1};
					if (box[0] < 0 || box[2] > w || box[1] < 18 || box[3] > h) {
						continue;
					}
					if (overlaps(taken, box)) {
						continue;
					}
					taken.add(box);
					final int[] chips = new int[st.colors.size()];
					for (int i = 0; i < chips.length; i++) {
						chips[i] = st.colors.get(i);
					}
					labels.add(new Placed(name, c[0], c[1], size, st.interchange ? GOLD : 0xFFE9EEF5, chips));
					break;
				}
			}
		}
		for (final Placed label : labels) {
			final float tw = p.width(label.text, label.size);
			if (!p.visible(label.x, label.y, label.x + tw, label.y + label.size + 6)) {
				continue;
			}
			p.text(label.text, label.x, label.y, label.size, label.color, 0);
			float cx = label.x;
			for (final int color : label.chips) {
				p.rect(cx, label.y + label.size + 1.5F, 4, 2.5F, color, WallPainter.Z_MARK);
				cx += 5;
			}
		}
	}

	private static boolean overlaps(List<float[]> boxes, float[] box) {
		for (final float[] other : boxes) {
			if (box[0] < other[2] && box[2] > other[0] && box[1] < other[3] && box[3] > other[1]) {
				return true;
			}
		}
		return false;
	}

	private static void legend(WallPainter p, float w, float h) {
		final float y = h - 9;
		float x = 6;
		p.rect(x, y + 1.5F, 8, 1.4F, RED, WallPainter.Z_MARK);
		p.text(OverlayUtil.tr("mtrctrl.board.legend_blocked"), x + 11, y, 6, DIM, 0);
		x += 11 + p.width(OverlayUtil.tr("mtrctrl.board.legend_blocked"), 6) + 10;
		p.rect(x, y + 1.2F, 3, 3, GREEN, WallPainter.Z_MARK);
		p.rect(x + 4, y + 1.2F, 3, 3, RED, WallPainter.Z_MARK);
		p.text(OverlayUtil.tr("mtrctrl.board.legend_signal"), x + 10, y, 6, DIM, 0);
		x += 10 + p.width(OverlayUtil.tr("mtrctrl.board.legend_signal"), 6) + 10;
		p.rect(x, y + 1.2F, 8, 3, PLATFORM_DEFAULT, WallPainter.Z_MARK);
		p.text(OverlayUtil.tr("mtrctrl.board.legend_platform"), x + 11, y, 6, DIM, 0);
		x += 11 + p.width(OverlayUtil.tr("mtrctrl.board.legend_platform"), 6) + 10;
		p.rect(x, y + 1, 8, 3.6F, MAGENTA, WallPainter.Z_MARK);
		p.text(OverlayUtil.tr("mtrctrl.board.legend_train"), x + 11, y, 6, DIM, 0);
		x += 11 + p.width(OverlayUtil.tr("mtrctrl.board.legend_train"), 6) + 10;
		p.rect(x, y + 0.5F, 4.4F, 4.4F, GOLD, WallPainter.Z_MARK);
		p.text(OverlayUtil.tr("mtrctrl.board.legend_interchange"), x + 8, y, 6, DIM, 0);
	}

	// ================================================================ 总览模式

	public static void summary(WallPainter p, NetworkSnapshot s, float w, float h) {
		p.rect(0, 0, w, h, BG, WallPainter.Z_BG);
		header(p, s, w, OverlayUtil.tr("mtrctrl.board.summary"));

		final boolean wide = w >= 260;
		final float split = wide ? w * 0.56F : w;
		mimic(p, s, 4, 20, split - 8, h - 24);
		if (wide) {
			table(p, s, split + 2, 20, w - split - 6, h - 24);
		}
	}

	/** 左侧：MIMIC SUMMARY 青色方格 + 下方的 CCTV 方块。 */
	private static void mimic(WallPainter p, NetworkSnapshot s, float x, float y, float width, float height) {
		p.rect(x, y, width, height, PANEL, WallPainter.Z_PANEL);
		p.text(OverlayUtil.tr("mtrctrl.board.mimic"), x + 4, y + 3, 7, TITLE, 0);

		float cy = y + 16;
		final float tag = width < 120 ? 0 : 34;
		final float sq = 8;
		final float gap = 2;
		final int perRow = (int) Math.max(1, Math.floor((width - tag - 10) / (sq + gap)));

		if (s.lines.isEmpty()) {
			p.text(OverlayUtil.tr("mtrctrl.board.no_train"), x + width / 2, y + height / 2 - 4, 8, CYAN, 1);
			return;
		}
		for (final Line line : s.lines) {
			final int n = Math.max(1, line.axis.size());
			final int rows = (n + perRow - 1) / perRow;
			final float rowsH = rows * (sq + gap) + 4;
			if (cy + rowsH > y + height - 4) {
				break;
			}
			if (tag > 0) {
				p.rect(x + 4, cy, tag - 4, 10, line.color, WallPainter.Z_MARK);
				p.text(p.fit(line.name, 7, tag - 8), x + 4 + (tag - 4) / 2, cy + 1.5F, 7, 0xFFFFFFFF, 1);
			}
			for (int i = 0; i < n; i++) {
				final int col = i % perRow;
				final int row = i / perRow;
				int color = TEAL;
				for (final Train t : line.trains) {
					if (t.nextAxis == i) {
						color = t.waiting ? RED : YELLOW;
						break;
					}
				}
				p.rect(x + tag + 4 + col * (sq + gap), cy + row * (sq + gap), sq, sq, color, WallPainter.Z_MARK);
			}
			cy += rowsH + 2;
		}

		// CCTV 装饰方块
		final float camTop = cy + 2;
		final float camH = y + height - 4 - camTop;
		if (camH >= 36 && width >= 100) {
			p.text("CCTV", x + 4, camTop, 6, DIM, 0);
			final int cols = 3;
			final int rowsCam = camH >= 66 ? 2 : 1;
			final float cw = (width - 8 - (cols - 1) * 3) / cols;
			final float ch = Math.min(30, (camH - 10 - (rowsCam - 1) * 3) / rowsCam);
			for (int r = 0; r < rowsCam; r++) {
				for (int c = 0; c < cols; c++) {
					final float cx = x + 4 + c * (cw + 3);
					final float cyy = camTop + 9 + r * (ch + 3);
					p.rect(cx, cyy, cw, ch, 0xFF2A3038, WallPainter.Z_MARK);
					p.rect(cx + 1, cyy + 1, cw - 2, ch - 2, 0xFF151A20, WallPainter.Z_MARK + 0.3F);
					p.text("CAM " + (r * cols + c + 1), cx + 3, cyy + 2, 5, DIM, 0);
				}
			}
		}
	}

	/** 右侧：列车状态表。 */
	private static void table(WallPainter p, NetworkSnapshot s, float x, float y, float width, float height) {
		p.rect(x, y, width, height, PANEL, WallPainter.Z_PANEL);
		p.text(OverlayUtil.tr("mtrctrl.board.table"), x + 4, y + 3, 7, TITLE, 0);

		final float[] colX = {4, width * 0.20F, width * 0.42F, width * 0.68F, width * 0.80F};
		final float[] colW = {colX[1] - colX[0] - 2, colX[2] - colX[1] - 2, colX[3] - colX[2] - 2, colX[4] - colX[3] - 2, width - colX[4] - 4};
		final String[] heads = {
				OverlayUtil.tr("mtrctrl.board.col_line"), OverlayUtil.tr("mtrctrl.board.col_dest"),
				OverlayUtil.tr("mtrctrl.board.col_next"), OverlayUtil.tr("mtrctrl.board.col_speed"),
				OverlayUtil.tr("mtrctrl.board.col_dist")};
		final float headY = y + 15;
		for (int c = 0; c < heads.length; c++) {
			p.text(p.fit(heads[c], 6, colW[c]), x + colX[c], headY, 6, DIM, 0);
		}
		p.rect(x + 2, headY + 9, width - 4, 1, HEADER_LINE, WallPainter.Z_LINE);

		final float rowH = 9;
		final int maxRows = (int) Math.max(0, Math.floor((y + height - (headY + 12)) / rowH));
		final List<Train> trains = s.trains;
		for (int i = 0; i < Math.min(maxRows, trains.size()); i++) {
			final Train t = trains.get(i);
			final float ry = headY + 12 + i * rowH;
			final int color = t.moving ? CYAN : YELLOW;
			p.text(p.fit(t.lineShown, 6, colW[0]), x + colX[0], ry, 6, color, 0);
			p.text(p.fit(t.destShown, 6, colW[1]), x + colX[1], ry, 6, color, 0);
			p.text(p.fit(t.nextShown, 6, colW[2]), x + colX[2], ry, 6, color, 0);
			p.text(String.format("%.0f", t.kmh), x + colX[3], ry, 6, 0xFFFFFFFF, 0);
			p.text(t.distance == null ? "-" : String.format("%.0f", t.distance), x + colX[4], ry, 6, 0xFFFFFFFF, 0);
		}
		if (trains.size() > maxRows && maxRows > 0) {
			p.text("+" + (trains.size() - maxRows), x + width - 4, y + height - 9, 6, DIM, 2);
		}
	}
}
