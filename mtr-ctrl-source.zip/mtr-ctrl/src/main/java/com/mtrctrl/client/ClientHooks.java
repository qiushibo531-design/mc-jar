package com.mtrctrl.client;

import net.minecraft.client.MinecraftClient;

/**
 * 供公共（服务端也会加载的）方块类调用的客户端入口。
 * 把对 MinecraftClient / Screen 的引用隔离在这里，避免专用服务端加载方块类时报 NoClassDefFoundError。
 */
public final class ClientHooks {

	private ClientHooks() {
	}

	public static void openControlScreen() {
		MinecraftClient.getInstance().setScreen(new ControlScreen());
	}
}
