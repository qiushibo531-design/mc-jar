package com.mtrctrl.client;

/** 世界里显示器上的画布。 */
public final class WallCanvas implements Canvas {

	private final WallPainter painter;

	public WallCanvas(WallPainter painter) {
		this.painter = painter;
	}

	private static float z(int layer) {
		return WallPainter.Z_BG + layer * 0.5F;
	}

	@Override
	public void rect(float x, float y, float w, float h, int argb, int layer) {
		painter.rect(x, y, w, h, argb, z(layer));
	}

	@Override
	public void line(float x1, float y1, float x2, float y2, float thickness, int argb, int layer) {
		painter.line(x1, y1, x2, y2, thickness, argb, z(layer));
	}

	@Override
	public void text(String text, float x, float y, float size, int argb, int align) {
		painter.text(text, x, y, size, argb, align);
	}

	@Override
	public float width(String text, float size) {
		return painter.width(text, size);
	}
}
