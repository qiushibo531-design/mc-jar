package com.mtrctrl.client;

import org.mtr.core.data.Route;
import org.mtr.mod.client.MinecraftClientData;

import com.mtrctrl.block.DisplayScreenBlock;
import com.mtrctrl.block.DisplayScreenBlockEntity;

import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.block.entity.BlockEntityRenderer;
import net.minecraft.client.render.block.entity.BlockEntityRendererFactory;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.world.World;

/**
 * 显示屏渲染器：把整面「视频墙」的内容，由左上角的主屏统一绘制。
 *
 * <p>画面以「1/96 格」为坐标单位：原点在墙的左上角，+x 向右、+y 向下；墙的尺寸为
 * {@code 96*width × 96*height}。路线以各自官方颜色显示，模拟总控大屏的彩色线路。</p>
 */
public final class DisplayScreenRenderer implements BlockEntityRenderer<DisplayScreenBlockEntity> {

	private static final float SCALE = 1.0F / 96.0F;
	private static final int LINE_HEIGHT = 8;
	private static final int MARGIN = 4;
	private static final int TITLE_COLOR = 0xFFFFC94D;
	private static final int INFO_COLOR = 0xFF9ADBFF;

	public DisplayScreenRenderer(BlockEntityRendererFactory.Context context) {
	}

	@Override
	public void render(DisplayScreenBlockEntity entity, float tickDelta, MatrixStack matrices, VertexConsumerProvider vertexConsumers, int light, int overlay) {
		final World world = entity.getWorld();
		if (world == null) {
			return;
		}
		final Direction facing = entity.getCachedState().get(DisplayScreenBlock.FACING);
		final Wall wall = Wall.find(world, entity.getPos(), facing);
		if (!wall.isMaster) {
			return;
		}

		final MinecraftClient client = MinecraftClient.getInstance();
		if (client == null || client.player == null) {
			return;
		}
		final TextRenderer font = client.textRenderer;
		final MinecraftClientData data = ClientDataUtil.data(client);

		matrices.push();
		matrices.translate(0.5, 0.5, 0.5);
		matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-facing.asRotation()));
		matrices.translate(-0.5, 0.5, 0.51);
		matrices.scale(SCALE, -SCALE, SCALE);

		draw(font, OverlayUtil.tr("mtrctrl.screen.title"), MARGIN, MARGIN, TITLE_COLOR, matrices, vertexConsumers, light);
		int y = MARGIN + LINE_HEIGHT + 2;

		if (data == null) {
			draw(font, OverlayUtil.tr("mtrctrl.screen.no_data"), MARGIN, y, INFO_COLOR, matrices, vertexConsumers, light);
			matrices.pop();
			return;
		}

		final int wallHeight = 96 * wall.height;
		final int maxRows = Math.max(1, (wallHeight - MARGIN * 2) / (LINE_HEIGHT + 2) - 1);

		int shown = 0;
		for (final Route route : data.routes) {
			if (shown >= maxRows) {
				break;
			}
			final int color = 0xFF000000 | route.getColor();
			draw(font, "━ " + formatRouteName(route.getName()), MARGIN, y, color, matrices, vertexConsumers, light);
			y += LINE_HEIGHT + 2;
			shown++;
		}

		y += 4;
		draw(font, OverlayUtil.tr("mtrctrl.screen.trains") + " " + data.vehicles.size(), MARGIN, y, INFO_COLOR, matrices, vertexConsumers, light);

		matrices.pop();
	}

	private static void draw(TextRenderer font, String text, float x, float y, int color, MatrixStack matrices, VertexConsumerProvider vertexConsumers, int light) {
		font.draw(Text.literal(text), x, y, color, false, matrices.peek().getPositionMatrix(), vertexConsumers, TextRenderer.TextLayerType.NORMAL, 0x00000000, light);
	}

	private static String formatRouteName(String name) {
		return name == null || name.isEmpty() ? "-" : name.split("\\|\\|")[0];
	}

	/**
	 * 一面「视频墙」：由同朝向、互相贴合的显示屏方块组成的矩形。
	 */
	private static final class Wall {
		final boolean isMaster;
		final int width;
		final int height;

		private Wall(boolean isMaster, int width, int height) {
			this.isMaster = isMaster;
			this.width = width;
			this.height = height;
		}

		static Wall find(World world, BlockPos pos, Direction facing) {
			final Direction left = facing.rotateYCounterclockwise();
			final Direction right = facing.rotateYClockwise();
			// 左边或上边还有同朝向屏幕，则本块不是主屏。
			if (isScreen(world, pos.offset(left), facing) || isScreen(world, pos.offset(Direction.UP), facing)) {
				return new Wall(false, 0, 0);
			}
			int width = 1;
			while (isScreen(world, pos.offset(right, width), facing)) {
				width++;
			}
			int height = 1;
			while (isScreen(world, pos.offset(Direction.DOWN, height), facing)) {
				height++;
			}
			return new Wall(true, width, height);
		}

		private static boolean isScreen(World world, BlockPos pos, Direction facing) {
			final BlockState state = world.getBlockState(pos);
			return state.getBlock() instanceof DisplayScreenBlock && state.get(DisplayScreenBlock.FACING) == facing;
		}
	}
}
