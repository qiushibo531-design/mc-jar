package com.mtrctrl.client;

import org.mtr.core.data.Rail;
import org.mtr.core.data.VehicleCar;
import org.mtr.core.tool.Vector;
import org.mtr.libraries.it.unimi.dsi.fastutil.objects.ObjectArrayList;
import org.mtr.libraries.it.unimi.dsi.fastutil.objects.ObjectObjectImmutablePair;
import org.mtr.mod.client.MinecraftClientData;
import org.mtr.mod.client.VehicleRidingMovement;
import org.mtr.mod.data.VehicleExtension;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;

/**
 * 读取 MTR 客户端数据的公共辅助方法，均对「未进入世界 / 数据未同步」做了空安全处理。
 */
public final class ClientDataUtil {

	/** MTR 的 speed 单位是「米/毫秒」，乘以 3600 得到「千米/小时」。 */
	private static final double KMH = 3600.0;

	private ClientDataUtil() {
	}

	public static boolean isInWorld(MinecraftClient client) {
		return client != null && client.world != null && client.player != null;
	}

	/** 返回 MTR 客户端数据单例；未进入世界时返回 null。 */
	public static MinecraftClientData data(MinecraftClient client) {
		return isInWorld(client) ? MinecraftClientData.getInstance() : null;
	}

	/** 玩家正在乘坐的列车，没有则返回 null。 */
	public static VehicleExtension ridingVehicle(MinecraftClient client) {
		final MinecraftClientData data = data(client);
		if (data == null) {
			return null;
		}
		for (final VehicleExtension vehicle : data.vehicles) {
			if (VehicleRidingMovement.isRiding(vehicle.getId())) {
				return vehicle;
			}
		}
		return null;
	}

	/** 距离玩家最近的列车（可选最大半径，单位格）。 */
	public static VehicleExtension nearestVehicle(MinecraftClient client, double maxRadius) {
		final MinecraftClientData data = data(client);
		if (data == null) {
			return null;
		}
		final PlayerEntity player = client.player;
		VehicleExtension nearest = null;
		double nearestDist = Double.MAX_VALUE;
		for (final VehicleExtension vehicle : data.vehicles) {
			final Vector head = headPosition(vehicle);
			if (head == null) {
				continue;
			}
			final double dx = head.x - player.getX();
			final double dy = head.y - player.getY();
			final double dz = head.z - player.getZ();
			final double dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
			if (dist < nearestDist && dist <= maxRadius) {
				nearestDist = dist;
				nearest = vehicle;
			}
		}
		return nearest;
	}

	/** 速度 → 千米/小时。 */
	public static double speedKmh(VehicleExtension vehicle) {
		return vehicle.getSpeed() * KMH;
	}

	/** 列车头到下一月台停靠点的距离（米）；没有则返回 null。 */
	public static Double distanceToPlatform(VehicleExtension vehicle) {
		final org.mtr.libraries.it.unimi.dsi.fastutil.doubles.DoubleObjectImmutablePair<org.mtr.libraries.it.unimi.dsi.fastutil.doubles.DoubleDoubleImmutablePair> details =
				vehicle.getPlatformStoppingDetails();
		return details == null ? null : details.leftDouble();
	}

	/** 列车头世界坐标（取首车首转向架），用字段 x/y/z 访问；取不到时返回 null。 */
	public static Vector headPosition(VehicleExtension vehicle) {
		final ObjectArrayList<ObjectObjectImmutablePair<VehicleCar, ObjectArrayList<ObjectObjectImmutablePair<Vector, Vector>>>> cars =
				vehicle.getSmoothedVehicleCarsAndPositions(0);
		if (cars.isEmpty()) {
			return null;
		}
		final ObjectArrayList<ObjectObjectImmutablePair<Vector, Vector>> bogies = cars.get(0).right();
		if (bogies.isEmpty()) {
			return null;
		}
		return bogies.get(0).left();
	}

	/** 列车头当前所在轨道的十六进制 id；找不到时返回 null。 */
	public static String railHexIdAtHead(MinecraftClient client, VehicleExtension vehicle) {
		final Vector head = headPosition(vehicle);
		if (head == null) {
			return null;
		}
		final MinecraftClientData data = data(client);
		if (data == null) {
			return null;
		}
		Rail nearest = null;
		double nearestDist = Double.MAX_VALUE;
		for (final Rail rail : data.rails) {
			final double cx = (rail.railMath.minX + rail.railMath.maxX) / 2;
			final double cy = (rail.railMath.minY + rail.railMath.maxY) / 2;
			final double cz = (rail.railMath.minZ + rail.railMath.maxZ) / 2;
			final double dx = cx - head.x;
			final double dy = cy - head.y;
			final double dz = cz - head.z;
			final double dist = dx * dx + dy * dy + dz * dz;
			if (dist < nearestDist) {
				nearestDist = dist;
				nearest = rail;
			}
		}
		return nearest == null ? null : nearest.getHexId();
	}
}
