package com.mtrctrl.client;

/**
 * 画布抽象：同一份 ATS 画面代码既能画在世界里的显示器上（WallPainter），也能画在界面里（DrawContext）。
 * layer 越大越靠前（0 底、1 轨道、2 占用、3 车站、4 信号/道岔、5 列车）。
 */
public interface Canvas {

	void rect(float x, float y, float w, float h, int argb, int layer);

	void line(float x1, float y1, float x2, float y2, float thickness, int argb, int layer);

	/** align：0 左 / 1 中 / 2 右；size 为大致字高（像素）。 */
	void text(String text, float x, float y, float size, int argb, int align);

	float width(String text, float size);
}
