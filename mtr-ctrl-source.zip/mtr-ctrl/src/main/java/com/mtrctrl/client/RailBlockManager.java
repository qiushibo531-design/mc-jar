package com.mtrctrl.client;

import java.util.HashSet;
import java.util.Set;

import org.mtr.core.operation.BlockRails;
import org.mtr.libraries.it.unimi.dsi.fastutil.ints.IntArrayList;
import org.mtr.libraries.it.unimi.dsi.fastutil.objects.ObjectArrayList;
import org.mtr.mod.InitClient;
import org.mtr.mod.packet.PacketBlockRails;

import net.minecraft.client.MinecraftClient;

/**
 * 「持续拦停」轨道管理。
 *
 * <p>MTR 的 {@link BlockRails} 手动拦停只持续约 1 秒，所以这里记录要拦停的轨道，
 * 并在客户端每帧里周期性重发 {@code PacketBlockRails}；停止重发即自动放行。</p>
 */
public final class RailBlockManager {

	private static final Set<String> HELD_RAIL_IDS = new HashSet<>();
	private static final int RESEND_INTERVAL_TICKS = 20;
	private static int tickCounter = 0;

	private RailBlockManager() {
	}

	public static boolean isHeld(String railHexId) {
		return HELD_RAIL_IDS.contains(railHexId);
	}

	/** 切换某条轨道的拦停状态，返回切换后的状态（true=拦停）。 */
	public static boolean toggle(String railHexId) {
		if (HELD_RAIL_IDS.contains(railHexId)) {
			HELD_RAIL_IDS.remove(railHexId);
			return false;
		}
		HELD_RAIL_IDS.add(railHexId);
		return true;
	}

	public static void clear() {
		HELD_RAIL_IDS.clear();
	}

	public static int heldCount() {
		return HELD_RAIL_IDS.size();
	}

	/** 每帧调用；每 20 tick（约 1 秒）重发一次拦停指令。 */
	public static void tick(MinecraftClient client) {
		tickCounter++;
		if (tickCounter % RESEND_INTERVAL_TICKS != 0 || HELD_RAIL_IDS.isEmpty()) {
			return;
		}
		if (!ClientDataUtil.isInWorld(client)) {
			return;
		}

		final ObjectArrayList<String> railIds = new ObjectArrayList<>();
		HELD_RAIL_IDS.forEach(railIds::add);
		// 空颜色 = 用每条轨道自己的信号色拦停（拦停所有经过该轨道的列车）。
		final IntArrayList signalColors = new IntArrayList();

		InitClient.REGISTRY_CLIENT.sendPacketToServer(new PacketBlockRails(new BlockRails(railIds, signalColors)));
	}
}
