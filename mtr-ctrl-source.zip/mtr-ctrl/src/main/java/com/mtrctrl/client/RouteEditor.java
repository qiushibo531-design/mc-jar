package com.mtrctrl.client;

import java.util.function.Consumer;

import org.mtr.core.data.Route;
import org.mtr.core.data.RoutePlatformData;
import org.mtr.core.operation.UpdateDataRequest;
import org.mtr.libraries.it.unimi.dsi.fastutil.objects.ObjectArrayList;
import org.mtr.mod.InitClient;
import org.mtr.mod.client.MinecraftClientData;
import org.mtr.mod.packet.PacketUpdateData;

import net.minecraft.client.MinecraftClient;

/**
 * 线路编辑：通过 MTR 的 {@link UpdateDataRequest}（UPDATE_DATA 操作）回写线路数据。
 */
public final class RouteEditor {

	private RouteEditor() {
	}

	/** 把终点改为第 newTerminalCount 个月台（保留前 newTerminalCount 个）。 */
	public static boolean changeTerminal(MinecraftClient client, long routeId, int newTerminalCount) {
		return updateRoute(client, routeId, platforms -> {
			while (platforms.size() > newTerminalCount) {
				platforms.remove(platforms.size() - 1);
			}
		});
	}

	/** 移除线路中的某个月台（改路线：调整停靠站）。 */
	public static boolean removePlatform(MinecraftClient client, long routeId, int index) {
		return updateRoute(client, routeId, platforms -> {
			if (index >= 0 && index < platforms.size()) {
				platforms.remove(index);
			}
		});
	}

	/** 线路的月台数量。 */
	public static int platformCount(MinecraftClient client, long routeId) {
		final MinecraftClientData data = ClientDataUtil.data(client);
		if (data == null) {
			return 0;
		}
		final Route route = data.routeIdMap.get(routeId);
		return route == null ? 0 : route.getRoutePlatforms().size();
	}

	private static boolean updateRoute(MinecraftClient client, long routeId, Consumer<ObjectArrayList<RoutePlatformData>> mutation) {
		final MinecraftClientData data = ClientDataUtil.data(client);
		if (data == null) {
			return false;
		}
		final Route route = data.routeIdMap.get(routeId);
		if (route == null) {
			return false;
		}
		final ObjectArrayList<RoutePlatformData> platforms = route.getRoutePlatforms();
		final int before = platforms.size();
		mutation.accept(platforms);
		if (platforms.size() == before || platforms.size() < 2) {
			return false;
		}

		final UpdateDataRequest request = new UpdateDataRequest(data).addRoute(route);
		InitClient.REGISTRY_CLIENT.sendPacketToServer(new PacketUpdateData(request));
		return true;
	}
}
