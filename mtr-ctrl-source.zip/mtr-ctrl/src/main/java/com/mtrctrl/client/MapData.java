package com.mtrctrl.client;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.mtr.core.data.Rail;
import org.mtr.core.data.Route;
import org.mtr.core.data.RoutePlatformData;
import org.mtr.mod.client.MinecraftClientData;

import net.minecraft.client.MinecraftClient;

/**
 * 路网的几何快照：每一条轨道（含弯道，按真实形状采样成折线）、每个车站（范围、月台、换乘）。
 * 构建比较重，所以每隔几秒（或轨道数量变化时）才重建一次。
 */
public final class MapData {

	/** 一条轨道的折线（世界坐标 x / z）。 */
	public static final class RailLine {
		public String hexId = "";
		public double[] xs;
		public double[] zs;
		public double minX;
		public double maxX;
		public double minZ;
		public double maxZ;
		public boolean platform;
		public boolean siding;
		public boolean signal;
		/** 月台轨道所属线路的颜色（ARGB），没有则为 0。 */
		public int color;
	}

	public static final class Platform {
		public String name = "";
		public double x;
		public double z;
		public int color = 0;
	}

	public static final class Station {
		public String name = "-";
		public double minX;
		public double maxX;
		public double minZ;
		public double maxZ;
		public double cx;
		public double cz;
		public boolean interchange;
		public final List<Integer> colors = new ArrayList<>();
		public final List<Platform> platforms = new ArrayList<>();
	}

	public final List<RailLine> rails = new ArrayList<>();
	public final List<Station> stations = new ArrayList<>();
	public double minX = Double.MAX_VALUE;
	public double maxX = -Double.MAX_VALUE;
	public double minZ = Double.MAX_VALUE;
	public double maxZ = -Double.MAX_VALUE;
	public int version;

	private static MapData cache;
	private static long builtMs;
	private static int builtRailCount = -1;
	private static int versionCounter;

	private MapData() {
	}

	public boolean isEmpty() {
		return rails.isEmpty() && stations.isEmpty();
	}

	public static MapData get(MinecraftClient client) {
		final MinecraftClientData data = ClientDataUtil.data(client);
		if (data == null) {
			return new MapData();
		}
		final long now = System.currentTimeMillis();
		final int railCount = data.rails.size();
		if (cache == null || railCount != builtRailCount || now - builtMs > 10000 || now < builtMs) {
			cache = build(data);
			builtMs = now;
			builtRailCount = railCount;
		}
		return cache;
	}

	private static MapData build(MinecraftClientData data) {
		final MapData map = new MapData();
		map.version = ++versionCounter;

		for (final Rail rail : data.rails) {
			try {
				final RailLine line = readRail(rail);
				if (line != null) {
					map.rails.add(line);
					map.extend(line.minX, line.minZ);
					map.extend(line.maxX, line.maxZ);
				}
			} catch (RuntimeException ignored) {
				// 单条轨道读取失败就跳过
			}
		}

		// 每个月台被哪些线路（颜色）使用
		final Map<Long, Set<Integer>> platformColors = new HashMap<>();
		for (final Route route : data.routeIdMap.values()) {
			try {
				final double raw = Reflect.number(Reflect.call(route, "getColor"));
				if (Double.isNaN(raw)) {
					continue;
				}
				final int color = 0xFF000000 | (int) raw;
				for (final RoutePlatformData rpd : route.getRoutePlatforms()) {
					final Object platform = rpd.getPlatform();
					final double id = Reflect.number(Reflect.call(platform, "getId"));
					if (!Double.isNaN(id)) {
						platformColors.computeIfAbsent((long) id, k -> new HashSet<>()).add(color);
					}
				}
			} catch (RuntimeException ignored) {
				// 跳过读取失败的线路
			}
		}

		final Object stationsObject = Reflect.field(data, "stations");
		if (stationsObject instanceof Iterable<?> iterable) {
			for (final Object stationObject : iterable) {
				try {
					final Station station = readStation(stationObject, platformColors);
					if (station != null) {
						map.stations.add(station);
						map.extend(station.minX, station.minZ);
						map.extend(station.maxX, station.maxZ);
					}
				} catch (RuntimeException ignored) {
					// 跳过读取失败的车站
				}
			}
		}
		// 给月台轨道配上最近月台的线路颜色
		for (final RailLine line : map.rails) {
			if (!line.platform) {
				continue;
			}
			final double mx = (line.minX + line.maxX) / 2;
			final double mz = (line.minZ + line.maxZ) / 2;
			double best = 20 * 20;
			for (final Station station : map.stations) {
				for (final Platform platform : station.platforms) {
					final double d = (platform.x - mx) * (platform.x - mx) + (platform.z - mz) * (platform.z - mz);
					if (d < best && platform.color != 0) {
						best = d;
						line.color = platform.color;
					}
				}
			}
		}
		return map;
	}

	private void extend(double x, double z) {
		minX = Math.min(minX, x);
		maxX = Math.max(maxX, x);
		minZ = Math.min(minZ, z);
		maxZ = Math.max(maxZ, z);
	}

	// ------------------------------------------------------------------ 轨道

	private static RailLine readRail(Rail rail) {
		final RailLine line = new RailLine();
		line.hexId = rail.getHexId();
		line.platform = Reflect.bool(Reflect.call(rail, "isPlatform"));
		line.siding = Reflect.bool(Reflect.call(rail, "isSiding"));
		final Object signals = Reflect.call(rail, "getSignalColors");
		line.signal = signals != null && Reflect.call(signals, "isEmpty") instanceof Boolean empty && !empty;

		final double length = Reflect.number(Reflect.call(rail.railMath, "getLength"));
		final List<double[]> points = new ArrayList<>();
		if (length > 0.5) {
			final int segments = Math.max(1, Math.min(48, (int) Math.ceil(length / 5.0)));
			for (int i = 0; i <= segments; i++) {
				final Object vector = Reflect.call(rail.railMath, "getPosition", length * i / segments, Boolean.FALSE);
				final double x = Reflect.num(vector, "x");
				final double z = Reflect.num(vector, "z");
				if (!Double.isNaN(x) && !Double.isNaN(z)) {
					points.add(new double[] {x, z});
				}
			}
		}
		if (points.size() < 2) {
			// 取不到形状时退化成包围盒对角线
			points.clear();
			points.add(new double[] {rail.railMath.minX, rail.railMath.minZ});
			points.add(new double[] {rail.railMath.maxX, rail.railMath.maxZ});
		}
		simplify(points);

		line.xs = new double[points.size()];
		line.zs = new double[points.size()];
		line.minX = Double.MAX_VALUE;
		line.minZ = Double.MAX_VALUE;
		line.maxX = -Double.MAX_VALUE;
		line.maxZ = -Double.MAX_VALUE;
		for (int i = 0; i < points.size(); i++) {
			line.xs[i] = points.get(i)[0];
			line.zs[i] = points.get(i)[1];
			line.minX = Math.min(line.minX, line.xs[i]);
			line.maxX = Math.max(line.maxX, line.xs[i]);
			line.minZ = Math.min(line.minZ, line.zs[i]);
			line.maxZ = Math.max(line.maxZ, line.zs[i]);
		}
		return line;
	}

	/** 去掉近似共线的中间点（直线只保留两端）。 */
	private static void simplify(List<double[]> points) {
		for (int i = points.size() - 2; i >= 1; i--) {
			final double[] a = points.get(i - 1);
			final double[] b = points.get(i);
			final double[] c = points.get(i + 1);
			final double cross = (b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0]);
			final double base = Math.hypot(c[0] - a[0], c[1] - a[1]);
			if (base > 0 && Math.abs(cross) / base < 0.05) {
				points.remove(i);
			}
		}
	}

	// ------------------------------------------------------------------ 车站

	private static Station readStation(Object object, Map<Long, Set<Integer>> platformColors) {
		final Station station = new Station();
		final String name = Reflect.string(Reflect.call(object, "getName"));
		station.name = name == null || name.isBlank() ? "-" : name;
		station.minX = Reflect.number(Reflect.call(object, "getMinX"));
		station.maxX = Reflect.number(Reflect.call(object, "getMaxX"));
		station.minZ = Reflect.number(Reflect.call(object, "getMinZ"));
		station.maxZ = Reflect.number(Reflect.call(object, "getMaxZ"));

		final Set<Integer> colors = new HashSet<>();
		final Object savedRails = Reflect.field(object, "savedRails");
		if (savedRails instanceof Iterable<?> iterable) {
			for (final Object platformObject : iterable) {
				final Platform platform = new Platform();
				final String platformName = Reflect.string(Reflect.call(platformObject, "getName"));
				platform.name = platformName == null ? "" : platformName;
				final Object mid = Reflect.call(platformObject, "getMidPosition");
				platform.x = Reflect.num(mid, "x");
				platform.z = Reflect.num(mid, "z");
				final double id = Reflect.number(Reflect.call(platformObject, "getId"));
				final Set<Integer> own = Double.isNaN(id) ? null : platformColors.get((long) id);
				if (own != null && !own.isEmpty()) {
					platform.color = own.iterator().next();
					colors.addAll(own);
				}
				if (!Double.isNaN(platform.x) && !Double.isNaN(platform.z)) {
					station.platforms.add(platform);
				}
			}
		}
		if (Double.isNaN(station.minX) || Double.isNaN(station.minZ) || Double.isNaN(station.maxX) || Double.isNaN(station.maxZ)) {
			if (station.platforms.isEmpty()) {
				return null;
			}
			station.minX = Double.MAX_VALUE;
			station.minZ = Double.MAX_VALUE;
			station.maxX = -Double.MAX_VALUE;
			station.maxZ = -Double.MAX_VALUE;
			for (final Platform platform : station.platforms) {
				station.minX = Math.min(station.minX, platform.x - 10);
				station.maxX = Math.max(station.maxX, platform.x + 10);
				station.minZ = Math.min(station.minZ, platform.z - 10);
				station.maxZ = Math.max(station.maxZ, platform.z + 10);
			}
		}
		station.cx = (station.minX + station.maxX) / 2;
		station.cz = (station.minZ + station.maxZ) / 2;
		station.colors.addAll(colors);
		station.interchange = colors.size() > 1;
		return station;
	}
}
