package com.mtrctrl.client;

import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

/**
 * 字体与多语言名称工具。屏幕与界面统一使用思源宋体（assets/mtrctrl/font/song.json）。
 */
public final class Fonts {

	public static final Identifier SONG = new Identifier("mtrctrl", "song");
	private static final Style SONG_STYLE = Style.EMPTY.withFont(SONG);

	private Fonts() {
	}

	/** 用宋体显示的文本。 */
	public static Text song(String text) {
		return Text.literal(text).setStyle(SONG_STYLE);
	}

	/** 当前界面语言是否为中文（由语言文件里的 mtrctrl.lang.code 决定）。 */
	public static boolean isChinese() {
		return OverlayUtil.tr("mtrctrl.lang.code").startsWith("zh");
	}

	/**
	 * MTR 的名称形如「中環|Central」。按界面语言挑选一种；
	 * 中文界面优先取含汉字的部分，否则优先取不含汉字的部分。
	 */
	public static String pick(String raw) {
		if (raw == null || raw.isBlank()) {
			return "-";
		}
		final String[] parts = raw.split("\\|");
		final boolean wantCjk = isChinese();
		for (final String part : parts) {
			final String p = part.trim();
			if (!p.isEmpty() && hasCjk(p) == wantCjk) {
				return p;
			}
		}
		for (final String part : parts) {
			if (!part.isBlank()) {
				return part.trim();
			}
		}
		return "-";
	}

	public static boolean hasCjk(String s) {
		for (int i = 0; i < s.length(); i++) {
			final char c = s.charAt(i);
			if ((c >= 0x4E00 && c <= 0x9FFF) || (c >= 0x3400 && c <= 0x4DBF)) {
				return true;
			}
		}
		return false;
	}
}
