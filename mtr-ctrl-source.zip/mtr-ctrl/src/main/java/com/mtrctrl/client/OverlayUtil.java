package com.mtrctrl.client;

import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Text;

/**
 * 覆盖层绘制的小工具：取本地化文本、画文字、画半透明面板。
 */
public final class OverlayUtil {

	private OverlayUtil() {
	}

	/** 取本地化字符串。 */
	public static String tr(String key) {
		return Text.translatable(key).getString();
	}

	/** 带阴影画一行文字。 */
	public static void text(DrawContext context, TextRenderer font, String string, int x, int y, int color) {
		context.drawText(font, string, x, y, color, true);
	}

	/** 画半透明背景面板。 */
	public static void panel(DrawContext context, int x, int y, int width, int height, int background) {
		context.fill(x, y, x + width, y + height, background);
	}

	/** 用文字宽度测量来画一个右对齐的进度条文本（简化：直接把字符串画出来）。 */
	public static void progressBar(DrawContext context, int x, int y, int width, int height, double fraction, int fillColor, int trackColor) {
		final double clamped = Math.max(0, Math.min(1, fraction));
		panel(context, x, y, width, height, trackColor);
		panel(context, x, y, (int) (width * clamped), height, fillColor);
	}
}
