package com.mtrctrl.client;

import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Text;

/**
 * 界面绘制小工具：取本地化文本、用宋体画字 / 量宽度。
 */
public final class OverlayUtil {

	private OverlayUtil() {
	}

	/** 取本地化字符串。 */
	public static String tr(String key) {
		return Text.translatable(key).getString();
	}

	/** 用宋体、带阴影画一行文字。 */
	public static void text(DrawContext context, TextRenderer font, String string, int x, int y, int color) {
		context.drawTextWithShadow(font, Fonts.song(string), x, y, color);
	}

	/** 宋体下的文字宽度。 */
	public static int width(TextRenderer font, String string) {
		return font.getWidth(Fonts.song(string));
	}

	/** 把文字裁到不超过 maxWidth，超出部分用「…」代替。 */
	public static String fit(TextRenderer font, String string, int maxWidth) {
		if (width(font, string) <= maxWidth) {
			return string;
		}
		String s = string;
		while (s.length() > 1 && width(font, s + "…") > maxWidth) {
			s = s.substring(0, s.length() - 1);
		}
		return s + "…";
	}

	/** 画实心矩形面板。 */
	public static void panel(DrawContext context, int x, int y, int width, int height, int background) {
		context.fill(x, y, x + width, y + height, background);
	}
}
