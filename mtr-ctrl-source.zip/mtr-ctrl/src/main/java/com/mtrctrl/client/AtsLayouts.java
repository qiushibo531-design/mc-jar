package com.mtrctrl.client;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.mtrctrl.client.NetworkSnapshot.Line;
import com.mtrctrl.client.NetworkSnapshot.Train;

/**
 * ATS（自动列车监控系统）运行监视画面——操作台用，盯某一条线、某一列车：
 * <ul>
 *   <li>白色线 = 轨道（含弯道与道岔分岔）；被列车占用的区段点亮（更亮更粗）。</li>
 *   <li>红色 = 列车，压在白色轨道上，实时跟着车走。</li>
 *   <li>绿色长方形 = 车站 / 站台，旁边写站名。</li>
 *   <li>小圆点 = 信号机（红 / 黄 / 绿）；小方环 = 道岔。</li>
 * </ul>
 */
public final class AtsLayouts {

	private static final int BG = 0xFF020406;
	private static final int FRAME = 0xFF2B3A4A;
	private static final int TRACK = 0xFFE4EAF2;
	private static final int LIT = 0xFFFFFFFF;
	private static final int TRAIN = 0xFFFF2020;
	private static final int TRAIN_DIM = 0xFF7A2424;
	private static final int STATION = 0xFF22B14C;
	private static final int STATION_EDGE = 0xFF7BE29A;
	private static final int SIG_GREEN = 0xFF2ECC71;
	private static final int SIG_YELLOW = 0xFFFFD23F;
	private static final int SIG_RED = 0xFFFF3B30;

	private AtsLayouts() {
	}

	/** 找出离某个世界坐标最近的列车所在的线路；没有列车时返回 null（显示全网）。 */
	public static Line nearestLine(NetworkSnapshot s, double x, double z) {
		Line best = null;
		double bestDist = Double.MAX_VALUE;
		for (final Line line : s.lines) {
			for (final Train t : line.trains) {
				if (Double.isNaN(t.headX)) {
					continue;
				}
				final double d = (t.headX - x) * (t.headX - x) + (t.headZ - z) * (t.headZ - z);
				if (d < bestDist) {
					bestDist = d;
					best = line;
				}
			}
		}
		return best;
	}

	/**
	 * 在 (x, y, w, h) 这块矩形里画 ATS 画面。line 为 null 表示全网；detail 为 true 时（界面里）画更多文字。
	 */
	public static void draw(Canvas c, NetworkSnapshot s, MapData m, float x, float y, float w, float h, Line line, boolean detail) {
		c.rect(x, y, w, h, FRAME, 0);
		c.rect(x + 1, y + 1, w - 2, h - 2, BG, 0);

		final float ix = x + 3;
		final float iy = y + 3 + (detail ? 10 : 7);
		final float iw = w - 6;
		final float ih = h - 6 - (detail ? 10 : 7);

		if (m.isEmpty()) {
			c.text(OverlayUtil.tr("mtrctrl.board.no_rail"), x + w / 2, y + h / 2 - 4, detail ? 9 : 6, 0xFF7FD6FF, 1);
			return;
		}

		// 本线的车站
		final Set<String> names = new HashSet<>();
		if (line != null) {
			names.addAll(line.axis);
		}
		final List<MapData.Station> stations = new ArrayList<>();
		for (final MapData.Station st : m.stations) {
			if (line == null || names.contains(Fonts.pick(st.name))) {
				stations.add(st);
			}
		}

		// 视野：本线所有车站（含余量）；取不到就退回全网
		double minX = Double.MAX_VALUE;
		double maxX = -Double.MAX_VALUE;
		double minZ = Double.MAX_VALUE;
		double maxZ = -Double.MAX_VALUE;
		if (line != null && !stations.isEmpty()) {
			for (final MapData.Station st : stations) {
				minX = Math.min(minX, st.minX);
				maxX = Math.max(maxX, st.maxX);
				minZ = Math.min(minZ, st.minZ);
				maxZ = Math.max(maxZ, st.maxZ);
			}
		} else {
			minX = m.minX;
			maxX = m.maxX;
			minZ = m.minZ;
			maxZ = m.maxZ;
		}
		final double pad = Math.max(24, Math.max(maxX - minX, maxZ - minZ) * 0.1);
		minX -= pad;
		maxX += pad;
		minZ -= pad;
		maxZ += pad;
		final double ex = Math.max(maxX - minX, 30);
		final double ez = Math.max(maxZ - minZ, 30);
		final float scale = (float) Math.min(iw / ex, ih / ez);
		final float px = ix + iw / 2;
		final float py = iy + ih / 2;
		final double cx = (minX + maxX) / 2;
		final double cz = (minZ + maxZ) / 2;
		final float l = ix;
		final float t = iy;
		final float r = ix + iw;
		final float b = iy + ih;

		final float trackW = detail ? 1.6F : 1.1F;

		// 轨道（白）与被占用区段（点亮）
		for (final MapData.RailLine rail : m.rails) {
			final float bx0 = sx(rail.minX, cx, px, scale);
			final float bx1 = sx(rail.maxX, cx, px, scale);
			final float by0 = sy(rail.minZ, cz, py, scale);
			final float by1 = sy(rail.maxZ, cz, py, scale);
			if (bx1 < l || bx0 > r || by1 < t || by0 > b) {
				continue;
			}
			final boolean lit = s.isBlocked(rail.hexId);
			for (int i = 0; i + 1 < rail.xs.length; i++) {
				final float[] seg = clip(sx(rail.xs[i], cx, px, scale), sy(rail.zs[i], cz, py, scale),
						sx(rail.xs[i + 1], cx, px, scale), sy(rail.zs[i + 1], cz, py, scale), l, t, r, b);
				if (seg != null) {
					c.line(seg[0], seg[1], seg[2], seg[3], lit ? trackW * 2.2F : trackW, lit ? LIT : TRACK, lit ? 2 : 1);
				}
			}
		}

		// 车站：绿色长方形 + 站名
		final List<float[]> taken = new ArrayList<>();
		final float nameSize = detail ? 7 : 5;
		for (final MapData.Station st : stations) {
			final float x0 = sx(st.minX, cx, px, scale);
			final float x1 = sx(st.maxX, cx, px, scale);
			final float y0 = sy(st.minZ, cz, py, scale);
			final float y1 = sy(st.maxZ, cz, py, scale);
			final float mx = (x0 + x1) / 2;
			final float my = (y0 + y1) / 2;
			final float rw = Math.max(x1 - x0, detail ? 10 : 6);
			final float rh = Math.max(y1 - y0, detail ? 5 : 3);
			final float rx = mx - rw / 2;
			final float ry = my - rh / 2;
			if (rx < l || rx + rw > r || ry < t || ry + rh > b) {
				continue;
			}
			c.rect(rx - 0.8F, ry - 0.8F, rw + 1.6F, rh + 1.6F, STATION_EDGE, 3);
			c.rect(rx, ry, rw, rh, STATION, 3);
			final String name = Fonts.pick(st.name);
			final float tw = c.width(name, nameSize);
			final float tx = mx - tw / 2;
			float ty = ry - nameSize - 1;
			if (ty < t) {
				ty = ry + rh + 1;
			}
			final float[] box = {tx - 1, ty - 1, tx + tw + 1, ty + nameSize + 1};
			if (box[0] >= l && box[2] <= r && box[3] <= b && !overlaps(taken, box)) {
				taken.add(box);
				c.text(name, tx, ty, nameSize, 0xFFFFFFFF, 0);
			}
		}

		// 道岔
		final float swSize = detail ? 4.4F : 3.2F;
		for (final double[] j : m.junctions) {
			final float jx = sx(j[0], cx, px, scale);
			final float jy = sy(j[1], cz, py, scale);
			if (jx < l || jx > r || jy < t || jy > b) {
				continue;
			}
			c.rect(jx - swSize / 2, jy - swSize / 2, swSize, swSize, 0xFFFFFFFF, 4);
			c.rect(jx - swSize / 2 + 0.9F, jy - swSize / 2 + 0.9F, swSize - 1.8F, swSize - 1.8F, BG, 4);
		}

		// 信号机：红 = 前方区段占用，黄 = 有车接近，绿 = 通畅
		final float sigSize = detail ? 3.6F : 2.4F;
		for (final MapData.RailLine rail : m.rails) {
			if (!rail.signal) {
				continue;
			}
			final float sxp = sx(rail.xs[0], cx, px, scale);
			final float syp = sy(rail.zs[0], cz, py, scale);
			if (sxp < l || sxp > r || syp < t || syp > b) {
				continue;
			}
			int color = SIG_GREEN;
			if (s.isBlocked(rail.hexId)) {
				color = SIG_RED;
			} else if (trainNear(s, rail.xs[0], rail.zs[0], 40)) {
				color = SIG_YELLOW;
			}
			c.rect(sxp - sigSize / 2, syp - sigSize / 2, sigSize, sigSize, color, 4);
		}

		// 列车：红色，压在轨道上
		final float body = detail ? 3.6F : 2.6F;
		for (final Line other : s.lines) {
			final boolean mine = line == null || other == line;
			for (final Train train : other.trains) {
				for (final double[] car : train.cars) {
					final float[] seg = clip(sx(car[0], cx, px, scale), sy(car[1], cz, py, scale),
							sx(car[2], cx, px, scale), sy(car[3], cz, py, scale), l, t, r, b);
					if (seg != null) {
						c.line(seg[0], seg[1], seg[2], seg[3], body, mine ? TRAIN : TRAIN_DIM, 5);
					}
				}
				if (detail && mine && !Double.isNaN(train.headX)) {
					final float hx = sx(train.headX, cx, px, scale);
					final float hy = sy(train.headZ, cz, py, scale);
					if (hx > l && hx < r && hy > t + 8 && hy < b) {
						c.text(train.lineShown + " " + train.destShown, hx + 4, hy - 9, 6, 0xFFFFC9C9, 0);
					}
				}
			}
		}

		// 标题
		final String title = "ATS  " + (line == null ? OverlayUtil.tr("mtrctrl.ats.all") : line.name);
		c.text(title, x + 5, y + 3, detail ? 8 : 5, 0xFFE8D9A8, 0);
	}

	private static boolean trainNear(NetworkSnapshot s, double x, double z, double radius) {
		for (final Train t : s.trains) {
			if (!Double.isNaN(t.headX) && Math.abs(t.headX - x) < radius && Math.abs(t.headZ - z) < radius) {
				return true;
			}
		}
		return false;
	}

	private static float sx(double x, double cx, float px, float scale) {
		return px + (float) ((x - cx) * scale);
	}

	private static float sy(double z, double cz, float py, float scale) {
		return py + (float) ((z - cz) * scale);
	}

	private static boolean overlaps(List<float[]> boxes, float[] box) {
		for (final float[] o : boxes) {
			if (box[0] < o[2] && box[2] > o[0] && box[1] < o[3] && box[3] > o[1]) {
				return true;
			}
		}
		return false;
	}

	/** Liang–Barsky 线段裁剪；完全在外面返回 null。 */
	private static float[] clip(float x1, float y1, float x2, float y2, float l, float t, float r, float b) {
		final float dx = x2 - x1;
		final float dy = y2 - y1;
		float t0 = 0;
		float t1 = 1;
		final float[] p = {-dx, dx, -dy, dy};
		final float[] q = {x1 - l, r - x1, y1 - t, b - y1};
		for (int i = 0; i < 4; i++) {
			if (p[i] == 0) {
				if (q[i] < 0) {
					return null;
				}
			} else {
				final float u = q[i] / p[i];
				if (p[i] < 0) {
					if (u > t1) {
						return null;
					}
					if (u > t0) {
						t0 = u;
					}
				} else {
					if (u < t0) {
						return null;
					}
					if (u < t1) {
						t1 = u;
					}
				}
			}
		}
		return new float[] {x1 + t0 * dx, y1 + t0 * dy, x1 + t1 * dx, y1 + t1 * dy};
	}
}
