package com.mtrctrl.client;

import java.util.ArrayList;
import java.util.List;

import org.joml.Matrix4f;

import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

/**
 * 大屏画笔。布局代码在「整面墙」的设计坐标（单位：像素，一格方块 = 64 像素）里画矩形 / 线 / 文字，
 * 画笔只保留落在当前这一块方块范围内的部分，所以拼成墙的每一块各画自己的那一份。
 *
 * <p>所有图元先缓存，最后 {@link #flush()} 一次性提交：先画全部色块，再画全部文字，
 * 这样不会因为反复切换渲染层而造成大量绘制调用。</p>
 */
public final class WallPainter {

	/** 一格方块的像素数。 */
	public static final int TILE = 64;

	/** 层次：数值越大越靠前，避免共面图元闪烁（单位：像素，约 1/64 格）。 */
	public static final float Z_BG = 0.0F;
	public static final float Z_PANEL = 0.5F;
	public static final float Z_LINE = 1.0F;
	public static final float Z_MARK = 1.5F;
	public static final float Z_TEXT = 2.5F;

	private static final Identifier WHITE = new Identifier("mtrctrl", "textures/misc/white.png");
	private static final int FULL_BRIGHT = 0xF000F0;

	private record Quad(float x0, float y0, float x1, float y1, float x2, float y2, float x3, float y3, float z, int argb) {
	}

	private record Label(Text text, float x, float y, float scale, int argb) {
	}

	private final MatrixStack matrices;
	private final VertexConsumerProvider consumers;
	private final TextRenderer font;
	private final float winX0;
	private final float winY0;
	private final float winX1;
	private final float winY1;
	private final List<Quad> quads = new ArrayList<>();
	private final List<Label> labels = new ArrayList<>();

	public WallPainter(MatrixStack matrices, VertexConsumerProvider consumers, TextRenderer font, float winX0, float winY0, float winX1, float winY1) {
		this.matrices = matrices;
		this.consumers = consumers;
		this.font = font;
		this.winX0 = winX0;
		this.winY0 = winY0;
		this.winX1 = winX1;
		this.winY1 = winY1;
	}

	// ---------------------------------------------------------------- 图元

	/** 实心矩形（会被裁到当前这一块方块的范围内）。 */
	public void rect(float x, float y, float w, float h, int argb, float z) {
		final float x0 = Math.max(x, winX0);
		final float y0 = Math.max(y, winY0);
		final float x1 = Math.min(x + w, winX1);
		final float y1 = Math.min(y + h, winY1);
		if (x1 <= x0 || y1 <= y0) {
			return;
		}
		quads.add(new Quad(x0, y0, x1, y0, x1, y1, x0, y1, z, argb));
	}

	/** 设计坐标里的这块矩形是否和当前方块的范围有交集（用来提前跳过不可见的内容）。 */
	public boolean visible(float x0, float y0, float x1, float y1) {
		return x1 >= winX0 && x0 <= winX1 && y1 >= winY0 && y0 <= winY1;
	}

	/** 任意方向的线段（有粗细）。 */
	public void line(float x1, float y1, float x2, float y2, float thickness, int argb, float z) {
		final float minX = Math.min(x1, x2) - thickness;
		final float maxX = Math.max(x1, x2) + thickness;
		final float minY = Math.min(y1, y2) - thickness;
		final float maxY = Math.max(y1, y2) + thickness;
		if (maxX < winX0 || minX > winX1 || maxY < winY0 || minY > winY1) {
			return;
		}
		final float dx = x2 - x1;
		final float dy = y2 - y1;
		final float len = (float) Math.sqrt(dx * dx + dy * dy);
		if (len < 0.001F) {
			return;
		}
		final float nx = -dy / len * thickness / 2;
		final float ny = dx / len * thickness / 2;
		quads.add(new Quad(x1 + nx, y1 + ny, x2 + nx, y2 + ny, x2 - nx, y2 - ny, x1 - nx, y1 - ny, z, argb));
	}

	/** 画一行文字。size 为大致的字高（像素）；align：0 左 / 1 中 / 2 右。 */
	public void text(String string, float x, float y, float size, int argb, int align) {
		if (string == null || string.isEmpty()) {
			return;
		}
		final float scale = size / 8.0F;
		final Text text = Fonts.song(string);
		final float width = font.getWidth(text) * scale;
		final float left = align == 1 ? x - width / 2 : align == 2 ? x - width : x;
		if (left + width < winX0 - 1 || left > winX1 + 1 || y + size < winY0 - 1 || y > winY1 + 1) {
			return;
		}
		labels.add(new Label(text, left, y, scale, argb));
	}

	public float width(String string, float size) {
		return font.getWidth(Fonts.song(string)) * size / 8.0F;
	}

	/** 把文字裁到不超过 maxWidth（像素），超出部分用「…」代替。 */
	public String fit(String string, float size, float maxWidth) {
		if (width(string, size) <= maxWidth) {
			return string;
		}
		String s = string;
		while (s.length() > 1 && width(s + "…", size) > maxWidth) {
			s = s.substring(0, s.length() - 1);
		}
		return s + "…";
	}

	// ---------------------------------------------------------------- 提交

	public void flush() {
		if (!quads.isEmpty()) {
			final Matrix4f matrix = matrices.peek().getPositionMatrix();
			final VertexConsumer buffer = consumers.getBuffer(RenderLayer.getText(WHITE));
			for (final Quad q : quads) {
				final int a = q.argb >>> 24 & 0xFF;
				final int r = q.argb >> 16 & 0xFF;
				final int g = q.argb >> 8 & 0xFF;
				final int b = q.argb & 0xFF;
				// 正反两个绕向各画一次，保证无论渲染层是否剔除背面都能看见。
				vertex(buffer, matrix, q.x0, q.y0, q.z, r, g, b, a);
				vertex(buffer, matrix, q.x1, q.y1, q.z, r, g, b, a);
				vertex(buffer, matrix, q.x2, q.y2, q.z, r, g, b, a);
				vertex(buffer, matrix, q.x3, q.y3, q.z, r, g, b, a);

				vertex(buffer, matrix, q.x3, q.y3, q.z, r, g, b, a);
				vertex(buffer, matrix, q.x2, q.y2, q.z, r, g, b, a);
				vertex(buffer, matrix, q.x1, q.y1, q.z, r, g, b, a);
				vertex(buffer, matrix, q.x0, q.y0, q.z, r, g, b, a);
			}
		}
		for (final Label label : labels) {
			matrices.push();
			matrices.translate(label.x, label.y, Z_TEXT);
			matrices.scale(label.scale, label.scale, 1.0F);
			font.draw(label.text, 0.0F, 0.0F, label.argb, false, matrices.peek().getPositionMatrix(), consumers,
					TextRenderer.TextLayerType.NORMAL, 0x00000000, FULL_BRIGHT);
			matrices.pop();
		}
		quads.clear();
		labels.clear();
	}

	private static void vertex(VertexConsumer buffer, Matrix4f matrix, float x, float y, float z, int r, int g, int b, int a) {
		buffer.vertex(matrix, x, y, z).color(r, g, b, a).texture(0.5F, 0.5F).light(FULL_BRIGHT).next();
	}
}
