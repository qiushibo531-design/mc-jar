package com.mtrctrl.client;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import org.mtr.core.data.Rail;
import org.mtr.mod.client.MinecraftClientData;
import org.mtr.mod.data.VehicleExtension;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

/**
 * 调度控制面板：轨道「拦停/放行」、列车远程控制（扣车/放行）、改路线、全部放行。
 */
public final class ControlScreen extends Screen {

	private static final int ROW_HEIGHT = 18;
	private static final int BG = 0xE6222222;

	private final List<Rail> rails = new ArrayList<>();
	private final List<VehicleExtension> vehicles = new ArrayList<>();
	private final List<Zone> zones = new ArrayList<>();

	private int scroll = 0;
	private int contentHeight = 0;

	private int routeEditX;
	private int routeEditY;
	private int routeEditW;
	private int routeEditH;
	private int releaseAllX;
	private int releaseAllY;
	private int releaseAllW;
	private int releaseAllH;

	public ControlScreen() {
		super(Text.translatable("mtrctrl.control.title"));
	}

	@Override
	public boolean shouldPause() {
		return false;
	}

	private void rebuild() {
		rails.clear();
		vehicles.clear();

		final MinecraftClient client = MinecraftClient.getInstance();
		if (!ClientDataUtil.isInWorld(client)) {
			return;
		}
		final MinecraftClientData data = MinecraftClientData.getInstance();
		final PlayerEntity player = client.player;

		for (final Rail rail : data.rails) {
			if (railDistance(rail) <= 48) {
				rails.add(rail);
			}
		}
		rails.sort(Comparator.comparingDouble(this::railDistance));

		for (final VehicleExtension vehicle : data.vehicles) {
			vehicles.add(vehicle);
		}
	}

	private double railDistance(Rail rail) {
		final MinecraftClient client = MinecraftClient.getInstance();
		final PlayerEntity player = client.player;
		final double cx = (rail.railMath.minX + rail.railMath.maxX) / 2;
		final double cy = (rail.railMath.minY + rail.railMath.maxY) / 2;
		final double cz = (rail.railMath.minZ + rail.railMath.maxZ) / 2;
		final double dx = cx - player.getX();
		final double dy = cy - player.getY();
		final double dz = cz - player.getZ();
		return Math.sqrt(dx * dx + dy * dy + dz * dz);
	}

	@Override
	public void render(DrawContext context, int mouseX, int mouseY, float delta) {
		rebuild();
		zones.clear();
		context.fill(0, 0, width, height, BG);

		int y = 8;
		context.drawTextWithShadow(textRenderer, Text.translatable("mtrctrl.control.title"), 8, y, 0xFFFFC94D);

		// 右上角「改路线」按钮
		final String routeEditLabel = OverlayUtil.tr("mtrctrl.control.route_edit");
		routeEditW = textRenderer.getWidth(routeEditLabel) + 12;
		routeEditH = textRenderer.fontHeight + 8;
		routeEditX = width - routeEditW - 10;
		routeEditY = 6;
		context.fill(routeEditX, routeEditY, routeEditX + routeEditW, routeEditY + routeEditH, 0xFF2E4E6E);
		context.drawTextWithShadow(textRenderer, routeEditLabel, routeEditX + 6, routeEditY + 4, 0xFFFFFFFF);

		// 「全部放行」按钮
		final String releaseAllLabel = OverlayUtil.tr("mtrctrl.control.release_all");
		releaseAllW = textRenderer.getWidth(releaseAllLabel) + 12;
		releaseAllH = textRenderer.fontHeight + 8;
		releaseAllX = routeEditX - releaseAllW - 8;
		releaseAllY = 6;
		context.fill(releaseAllX, releaseAllY, releaseAllX + releaseAllW, releaseAllY + releaseAllH, 0xFF2E6E3E);
		context.drawTextWithShadow(textRenderer, releaseAllLabel, releaseAllX + 6, releaseAllY + 4, 0xFFFFFFFF);

		y += textRenderer.fontHeight + 6;
		context.drawTextWithShadow(textRenderer, Formatting.GRAY + OverlayUtil.tr("mtrctrl.control.rails") + "（" + rails.size() + "）", 8, y - scroll, 0xFFFFFFFF);
		y += textRenderer.fontHeight + 2;

		final MinecraftClient client = MinecraftClient.getInstance();
		final MinecraftClientData data = ClientDataUtil.data(client);

		if (rails.isEmpty()) {
			context.drawTextWithShadow(textRenderer, OverlayUtil.tr("mtrctrl.control.no_rail"), 8, y - scroll, 0xFF9ADBFF);
			y += ROW_HEIGHT;
		} else {
			for (final Rail rail : rails) {
				final int rowY = y - scroll;
				if (rowY > -ROW_HEIGHT && rowY < height) {
					drawRailRow(context, data, rail, rowY);
				}
				y += ROW_HEIGHT;
			}
		}

		y += 6;
		context.drawTextWithShadow(textRenderer, Formatting.GRAY + OverlayUtil.tr("mtrctrl.control.vehicles") + "（" + vehicles.size() + "）", 8, y - scroll, 0xFFFFFFFF);
		y += textRenderer.fontHeight + 2;

		if (vehicles.isEmpty()) {
			context.drawTextWithShadow(textRenderer, OverlayUtil.tr("mtrctrl.control.no_vehicle"), 8, y - scroll, 0xFF9ADBFF);
			y += ROW_HEIGHT;
		} else {
			for (final VehicleExtension vehicle : vehicles) {
				final int rowY = y - scroll;
				if (rowY > -ROW_HEIGHT && rowY < height) {
					drawVehicleRow(context, client, vehicle, rowY);
				}
				y += ROW_HEIGHT;
			}
		}

		contentHeight = y;
	}

	private void drawRailRow(DrawContext context, MinecraftClientData data, Rail rail, int y) {
		final String hexId = rail.getHexId();
		final String shortId = hexId.length() > 6 ? hexId.substring(0, 6) : hexId;
		final boolean held = RailBlockManager.isHeld(hexId);
		final boolean blocked = data.blockedRailIds.contains(hexId);

		final String status = held ? OverlayUtil.tr("mtrctrl.control.blocked") : blocked ? OverlayUtil.tr("mtrctrl.control.blocked") : OverlayUtil.tr("mtrctrl.control.free");
		final int statusColor = held ? 0xFFFF5A5A : blocked ? 0xFFFFC94D : 0xFF3ECB6B;

		context.drawTextWithShadow(textRenderer, shortId, 8, y, 0xFFFFFFFF);
		context.drawTextWithShadow(textRenderer, status, 70, y, statusColor);
		context.drawTextWithShadow(textRenderer, OverlayUtil.tr("mtrctrl.control.distance") + " " + round1(railDistance(rail)) + "m", 130, y, 0xFFAAAAAA);

		final String label = held ? OverlayUtil.tr("mtrctrl.control.release") : OverlayUtil.tr("mtrctrl.control.hold");
		final int btnW = textRenderer.getWidth(label) + 12;
		final int btnX = width - btnW - 10;
		final int btnColor = held ? 0xFF8A2E2E : 0xFF2E6E3E;
		context.fill(btnX, y, btnX + btnW, y + ROW_HEIGHT - 2, btnColor);
		context.drawTextWithShadow(textRenderer, label, btnX + 6, y + 5, 0xFFFFFFFF);
		zones.add(new Zone(Zone.Kind.RAIL, hexId, btnX, y, btnW, ROW_HEIGHT - 2));
	}

	private void drawVehicleRow(DrawContext context, MinecraftClient client, VehicleExtension vehicle, int y) {
		final String route = nz(vehicle.vehicleExtraData.getThisRouteName());
		final String speed = round1(ClientDataUtil.speedKmh(vehicle)) + " km/h";
		final String next = nz(vehicle.vehicleExtraData.getNextStationName());
		context.drawTextWithShadow(textRenderer, route, 8, y, 0xFF9ADBFF);
		context.drawTextWithShadow(textRenderer, speed, 130, y, 0xFFFFFFFF);
		context.drawTextWithShadow(textRenderer, Formatting.GRAY + OverlayUtil.tr("mtrctrl.control.next_station") + " " + next, 230, y, 0xFFAAAAAA);

		final String headRail = ClientDataUtil.railHexIdAtHead(client, vehicle);
		if (headRail != null) {
			final boolean held = RailBlockManager.isHeld(headRail);
			final String label = held ? OverlayUtil.tr("mtrctrl.control.release") : OverlayUtil.tr("mtrctrl.control.hold");
			final int btnW = textRenderer.getWidth(label) + 12;
			final int btnX = width - btnW - 10;
			final int btnColor = held ? 0xFF8A2E2E : 0xFF2E6E3E;
			context.fill(btnX, y, btnX + btnW, y + ROW_HEIGHT - 2, btnColor);
			context.drawTextWithShadow(textRenderer, label, btnX + 6, y + 5, 0xFFFFFFFF);
			zones.add(new Zone(Zone.Kind.RAIL, headRail, btnX, y, btnW, ROW_HEIGHT - 2));
		}
	}

	@Override
	public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
		scroll -= (int) (verticalAmount * ROW_HEIGHT * 2);
		final int maxScroll = Math.max(0, contentHeight - height + 20);
		if (scroll < 0) {
			scroll = 0;
		}
		if (scroll > maxScroll) {
			scroll = maxScroll;
		}
		return true;
	}

	@Override
	public boolean mouseClicked(double mouseX, double mouseY, int button) {
		if (button != 0) {
			return super.mouseClicked(mouseX, mouseY, button);
		}
		if (hit(mouseX, mouseY, routeEditX, routeEditY, routeEditW, routeEditH)) {
			openRouteEdit();
			return true;
		}
		if (hit(mouseX, mouseY, releaseAllX, releaseAllY, releaseAllW, releaseAllH)) {
			RailBlockManager.clear();
			return true;
		}
		for (final Zone zone : zones) {
			if (hit(mouseX, mouseY, zone.x, zone.y, zone.w, zone.h)) {
				RailBlockManager.toggle(zone.railHexId);
				return true;
			}
		}
		return super.mouseClicked(mouseX, mouseY, button);
	}

	private void openRouteEdit() {
		final MinecraftClient client = MinecraftClient.getInstance();
		final VehicleExtension vehicle = ClientDataUtil.ridingVehicle(client) != null
				? ClientDataUtil.ridingVehicle(client)
				: ClientDataUtil.nearestVehicle(client, 256);
		if (vehicle == null) {
			return;
		}
		final long routeId = vehicle.vehicleExtraData.getThisRouteId();
		if (routeId != 0) {
			client.setScreen(new RouteEditScreen(routeId));
		}
	}

	private static boolean hit(double mouseX, double mouseY, int x, int y, int w, int h) {
		return mouseX >= x && mouseX <= x + w && mouseY >= y && mouseY <= y + h;
	}

	private static String nz(String value) {
		return value == null || value.isEmpty() ? "-" : value;
	}

	private static String round1(double value) {
		return String.format("%.1f", value);
	}

	private static final class Zone {
		enum Kind { RAIL }

		final Kind kind;
		final String railHexId;
		final int x;
		final int y;
		final int w;
		final int h;

		Zone(Kind kind, String railHexId, int x, int y, int w, int h) {
			this.kind = kind;
			this.railHexId = railHexId;
			this.x = x;
			this.y = y;
			this.w = w;
			this.h = h;
		}
	}
}
