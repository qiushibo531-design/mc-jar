package com.mtrctrl.client;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.mtr.core.data.Rail;
import org.mtr.mod.client.MinecraftClientData;

import com.mtrctrl.client.NetworkSnapshot.Line;
import com.mtrctrl.client.NetworkSnapshot.Train;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;

/**
 * 调度控制面板（仿控制中心操作员终端）：
 * 「线路」页看每条线的运行状态，「列车」页监控并扣车 / 放行每一辆车，「轨道」页拦停附近轨道。
 */
public final class ControlScreen extends Screen {

	private static final int ROW_HEIGHT = 18;
	private static final int BG = 0xF0060A10;
	private static final int HEADER_BG = 0xFF0B1620;
	private static final int ACCENT = 0xFFE8D9A8;
	private static final int CYAN = 0xFF7FD6FF;
	private static final int GREEN = 0xFF2ECC71;
	private static final int RED = 0xFFFF4B3E;
	private static final int YELLOW = 0xFFFFD23F;
	private static final int DIM = 0xFF8FA3B5;
	private static final int TEAL = 0xFF1FB8B0;
	private static final DateTimeFormatter CLOCK = DateTimeFormatter.ofPattern("HH:mm:ss");

	private static final int TAB_LINES = 0;
	private static final int TAB_TRAINS = 1;
	private static final int TAB_RAILS = 2;

	private final List<Rail> rails = new ArrayList<>();
	private final List<Zone> zones = new ArrayList<>();
	private final Map<Long, String> headRailCache = new HashMap<>();
	private long headRailCacheMs;
	private long railsMs;

	private int tab = TAB_TRAINS;
	private int scroll = 0;
	private int contentHeight = 0;
	private int listTop = 0;
	private boolean listMode = false;

	public ControlScreen() {
		super(Text.translatable("mtrctrl.control.title"));
	}

	@Override
	public boolean shouldPause() {
		return false;
	}

	// ------------------------------------------------------------------ 数据

	private void refreshRails() {
		final long now = System.currentTimeMillis();
		if (now - railsMs < 500 && !rails.isEmpty()) {
			return;
		}
		railsMs = now;
		rails.clear();
		final MinecraftClient client = MinecraftClient.getInstance();
		if (!ClientDataUtil.isInWorld(client)) {
			return;
		}
		final MinecraftClientData data = MinecraftClientData.getInstance();
		for (final Rail rail : data.rails) {
			if (railDistance(rail) <= 48) {
				rails.add(rail);
			}
		}
		rails.sort(Comparator.comparingDouble(this::railDistance));
	}

	private double railDistance(Rail rail) {
		final PlayerEntity player = MinecraftClient.getInstance().player;
		final double cx = (rail.railMath.minX + rail.railMath.maxX) / 2;
		final double cy = (rail.railMath.minY + rail.railMath.maxY) / 2;
		final double cz = (rail.railMath.minZ + rail.railMath.maxZ) / 2;
		final double dx = cx - player.getX();
		final double dy = cy - player.getY();
		final double dz = cz - player.getZ();
		return Math.sqrt(dx * dx + dy * dy + dz * dz);
	}

	private String headRail(MinecraftClient client, Train train) {
		final long now = System.currentTimeMillis();
		if (now - headRailCacheMs > 1000) {
			headRailCache.clear();
			headRailCacheMs = now;
		}
		if (!headRailCache.containsKey(train.id)) {
			headRailCache.put(train.id, ClientDataUtil.railHexIdAtHead(client, train.vehicle));
		}
		return headRailCache.get(train.id);
	}

	// ------------------------------------------------------------------ 绘制

	@Override
	public void render(DrawContext context, int mouseX, int mouseY, float delta) {
		zones.clear();
		final MinecraftClient client = MinecraftClient.getInstance();
		if (!ClientDataUtil.isInWorld(client)) {
			return;
		}
		final NetworkSnapshot snap = NetworkSnapshot.get(client);
		context.fill(0, 0, width, height, BG);

		// 页眉
		context.fill(0, 0, width, 22, HEADER_BG);
		context.fill(0, 21, width, 22, 0xFF35506B);
		drawText(context, OverlayUtil.tr("mtrctrl.control.title"), 8, 7, ACCENT);
		drawText(context, LocalTime.now().format(CLOCK), width / 2 - OverlayUtil.width(textRenderer, "00:00:00") / 2, 7, 0xFFFFFFFF);

		int rightX = width - 8;
		rightX = button(context, OverlayUtil.tr("mtrctrl.control.release_all"), rightX, 3, 16, 0xFF2E6E3E, RailBlockManager::clear) - 6;
		final String stats = OverlayUtil.tr("mtrctrl.board.trains") + " " + snap.trains.size()
				+ "   " + OverlayUtil.tr("mtrctrl.board.held") + " " + snap.heldRails;
		drawText(context, stats, rightX - OverlayUtil.width(textRenderer, stats), 7, CYAN);

		// 标签页
		int tabX = 8;
		final String[] names = {OverlayUtil.tr("mtrctrl.control.tab_lines"), OverlayUtil.tr("mtrctrl.control.tab_trains"), OverlayUtil.tr("mtrctrl.control.tab_rails")};
		for (int i = 0; i < names.length; i++) {
			final int index = i;
			final int w = OverlayUtil.width(textRenderer, names[i]) + 20;
			context.fill(tabX, 26, tabX + w, 42, tab == i ? 0xFF1F3C57 : 0xFF111C27);
			if (tab == i) {
				context.fill(tabX, 41, tabX + w, 43, ACCENT);
			}
			drawText(context, names[i], tabX + 10, 30, tab == i ? 0xFFFFFFFF : DIM);
			zones.add(new Zone(tabX, 26, w, 16, () -> {
				tab = index;
				scroll = 0;
			}, false));
			tabX += w + 4;
		}

		// 列表区（裁剪，避免滚动时盖住页眉）
		listTop = 48;
		listMode = true;
		context.enableScissor(0, listTop, width, height);
		int y = listTop + 2;
		switch (tab) {
			case TAB_LINES -> y = renderLines(context, snap, y);
			case TAB_RAILS -> y = renderRails(context, client, y);
			default -> y = renderTrains(context, client, snap, y);
		}
		context.disableScissor();
		listMode = false;
		contentHeight = y + scroll;
	}

	private int renderLines(DrawContext context, NetworkSnapshot snap, int startY) {
		int y = startY - scroll;
		if (snap.lines.isEmpty()) {
			drawText(context, OverlayUtil.tr("mtrctrl.control.no_vehicle"), 8, y + 4, CYAN);
			return y + ROW_HEIGHT;
		}
		for (final Line line : snap.lines) {
			final int rowH = 36;
			if (y + rowH > listTop && y < height) {
				context.fill(8, y, width - 8, y + rowH - 2, 0xFF0C1620);
				context.fill(8, y, 12, y + rowH - 2, line.color);
				drawText(context, OverlayUtil.fit(textRenderer, line.name, 150), 18, y + 4, 0xFFFFFFFF);

				double sum = 0;
				int waiting = 0;
				for (final Train t : line.trains) {
					sum += t.kmh;
					if (t.waiting) {
						waiting++;
					}
				}
				final String info = line.trains.size() + " " + OverlayUtil.tr("mtrctrl.control.unit_trains")
						+ "   " + OverlayUtil.tr("mtrctrl.control.avg_speed") + " " + String.format("%.0f", sum / Math.max(1, line.trains.size())) + " km/h"
						+ (waiting > 0 ? "   " + waiting + " " + OverlayUtil.tr("mtrctrl.control.waiting") : "");
				drawText(context, info, 18, y + 15, waiting > 0 ? YELLOW : CYAN);

				// 站点方格：青色=通畅，黄=有车将进站，红=有车停在站外
				final int n = line.axis.size();
				final int sq = 5;
				final int stripX = Math.max(190, width / 2);
				final int perRow = Math.max(1, (width - stripX - 16) / (sq + 1));
				for (int i = 0; i < n && i < perRow * 2; i++) {
					int color = TEAL;
					for (final Train t : line.trains) {
						if (t.nextAxis == i) {
							color = t.waiting ? RED : YELLOW;
							break;
						}
					}
					context.fill(stripX + (i % perRow) * (sq + 1), y + 6 + (i / perRow) * (sq + 1),
							stripX + (i % perRow) * (sq + 1) + sq, y + 6 + (i / perRow) * (sq + 1) + sq, color);
				}
			}
			y += rowH;
		}
		return y;
	}

	private int renderTrains(DrawContext context, MinecraftClient client, NetworkSnapshot snap, int startY) {
		int y = startY - scroll;
		if (snap.trains.isEmpty()) {
			drawText(context, OverlayUtil.tr("mtrctrl.control.no_vehicle"), 8, y + 4, CYAN);
			return y + ROW_HEIGHT;
		}
		// 窄屏时适当压缩列宽
		final int colLine = 8;
		final int colDest = Math.min(width / 6, 90) + colLine + 8;
		final int colNext = colDest + Math.min(width / 6, 90) + 6;
		final int colSpeed = colNext + Math.min(width / 6, 90) + 6;
		final int colDist = colSpeed + 62;

		drawText(context, OverlayUtil.tr("mtrctrl.board.col_line"), colLine + 8, y, DIM);
		drawText(context, OverlayUtil.tr("mtrctrl.board.col_dest"), colDest, y, DIM);
		drawText(context, OverlayUtil.tr("mtrctrl.board.col_next"), colNext, y, DIM);
		drawText(context, OverlayUtil.tr("mtrctrl.board.col_speed"), colSpeed, y, DIM);
		drawText(context, OverlayUtil.tr("mtrctrl.board.col_dist"), colDist, y, DIM);
		y += 12;

		for (final Train t : snap.trains) {
			if (y + ROW_HEIGHT > listTop && y < height) {
				final int lineColor = LineColors.of(t.lineKey);
				context.fill(colLine, y, colLine + 4, y + ROW_HEIGHT - 3, lineColor);
				final int textColor = t.moving ? CYAN : YELLOW;
				drawText(context, OverlayUtil.fit(textRenderer, t.lineShown, colDest - colLine - 14), colLine + 8, y + 4, 0xFFFFFFFF);
				drawText(context, OverlayUtil.fit(textRenderer, t.destShown, colNext - colDest - 6), colDest, y + 4, textColor);
				drawText(context, OverlayUtil.fit(textRenderer, t.nextShown, colSpeed - colNext - 6), colNext, y + 4, textColor);
				drawText(context, String.format("%.1f km/h", t.kmh), colSpeed, y + 4, 0xFFFFFFFF);
				drawText(context, t.distance == null ? "-" : String.format("%.0f m", t.distance), colDist, y + 4, DIM);

				int bx = width - 8;
				final String headRail = headRail(client, t);
				if (t.routeId != 0) {
					final long routeId = t.routeId;
					bx = button(context, OverlayUtil.tr("mtrctrl.control.route_edit"), bx, y, ROW_HEIGHT - 2, 0xFF2E4E6E,
							() -> client.setScreen(new RouteEditScreen(routeId))) - 4;
				}
				if (headRail != null) {
					final boolean held = RailBlockManager.isHeld(headRail);
					button(context, OverlayUtil.tr(held ? "mtrctrl.control.release" : "mtrctrl.control.hold"), bx, y, ROW_HEIGHT - 2,
							held ? 0xFF8A2E2E : 0xFF2E6E3E, () -> RailBlockManager.toggle(headRail));
				}
			}
			y += ROW_HEIGHT;
		}
		return y;
	}

	private int renderRails(DrawContext context, MinecraftClient client, int startY) {
		refreshRails();
		final MinecraftClientData data = ClientDataUtil.data(client);
		int y = startY - scroll;
		drawText(context, OverlayUtil.tr("mtrctrl.control.rails") + "（" + rails.size() + "）", 8, y, DIM);
		y += 12;
		if (rails.isEmpty() || data == null) {
			drawText(context, OverlayUtil.tr("mtrctrl.control.no_rail"), 8, y + 4, CYAN);
			return y + ROW_HEIGHT;
		}
		for (final Rail rail : rails) {
			if (y + ROW_HEIGHT > listTop && y < height) {
				final String hexId = rail.getHexId();
				final String shortId = hexId.length() > 6 ? hexId.substring(0, 6) : hexId;
				final boolean held = RailBlockManager.isHeld(hexId);
				final boolean blocked = data.blockedRailIds.contains(hexId);
				final String status = OverlayUtil.tr(held || blocked ? "mtrctrl.control.blocked" : "mtrctrl.control.free");
				final int statusColor = held ? RED : blocked ? YELLOW : GREEN;

				drawText(context, shortId, 8, y + 4, 0xFFFFFFFF);
				drawText(context, status, 70, y + 4, statusColor);
				drawText(context, OverlayUtil.tr("mtrctrl.control.distance") + " " + String.format("%.1f", railDistance(rail)) + "m", 130, y + 4, DIM);
				button(context, OverlayUtil.tr(held ? "mtrctrl.control.release" : "mtrctrl.control.hold"), width - 8, y, ROW_HEIGHT - 2,
						held ? 0xFF8A2E2E : 0xFF2E6E3E, () -> RailBlockManager.toggle(hexId));
			}
			y += ROW_HEIGHT;
		}
		return y;
	}

	// ------------------------------------------------------------------ 小工具

	private void drawText(DrawContext context, String text, int x, int y, int color) {
		context.drawTextWithShadow(textRenderer, Fonts.song(text), x, y, color);
	}

	/** 画一个按钮，右边缘对齐 rightX，返回按钮的左边缘。 */
	private int button(DrawContext context, String label, int rightX, int y, int h, int color, Runnable action) {
		final int w = OverlayUtil.width(textRenderer, label) + 12;
		final int x = rightX - w;
		context.fill(x, y, x + w, y + h, color);
		drawText(context, label, x + 6, y + (h - 8) / 2, 0xFFFFFFFF);
		zones.add(new Zone(x, y, w, h, action, listMode));
		return x;
	}

	@Override
	public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
		scroll -= (int) (verticalAmount * ROW_HEIGHT * 2);
		final int maxScroll = Math.max(0, contentHeight - height + 20);
		scroll = Math.max(0, Math.min(scroll, maxScroll));
		return true;
	}

	@Override
	public boolean mouseClicked(double mouseX, double mouseY, int button) {
		if (button == 0) {
			for (final Zone zone : zones) {
				final boolean inList = !zone.list || mouseY >= listTop;
				if (inList && mouseX >= zone.x && mouseX <= zone.x + zone.w && mouseY >= zone.y && mouseY <= zone.y + zone.h) {
					zone.action.run();
					return true;
				}
			}
		}
		return super.mouseClicked(mouseX, mouseY, button);
	}

	private static final class Zone {
		final int x;
		final int y;
		final int w;
		final int h;
		final Runnable action;
		final boolean list;

		Zone(int x, int y, int w, int h, Runnable action, boolean list) {
			this.x = x;
			this.y = y;
			this.w = w;
			this.h = h;
			this.action = action;
			this.list = list;
		}
	}
}
