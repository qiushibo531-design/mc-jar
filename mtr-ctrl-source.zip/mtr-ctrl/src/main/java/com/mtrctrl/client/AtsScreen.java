package com.mtrctrl.client;

import java.util.ArrayList;
import java.util.List;

import org.mtr.core.data.Platform;
import org.mtr.core.data.Rail;
import org.mtr.core.data.Station;
import org.mtr.core.tool.Vector;
import org.mtr.mod.client.MinecraftClientData;
import org.mtr.mod.data.VehicleExtension;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

/**
 * ATS 运行监控画面：把附近轨道（白线）、站台（绿色方块）、列车（红点）投影成平面运行图。
 *
 * <p>投影为俯视（世界 X→屏幕横轴、世界 Z→屏幕纵轴），按轨道包围盒等比例缩放并居中。</p>
 */
public final class AtsScreen extends Screen {

	private static final int BG = 0xFF101418;
	private static final int TRACK_COLOR = 0xFFD8D8D8;
	private static final int PLATFORM_COLOR = 0xFF3ECB6B;
	private static final int TRAIN_COLOR = 0xFFFF4B4B;
	private static final int STATION_TEXT = 0xFF9ADBFF;
	private static final int TITLE = 0xFFFFC94D;

	private final List<Rail> rails = new ArrayList<>();
	private final List<Platform> platforms = new ArrayList<>();
	private final List<Station> stations = new ArrayList<>();
	private final List<VehicleExtension> vehicles = new ArrayList<>();

	private double minX = 0;
	private double maxX = 0;
	private double minZ = 0;
	private double maxZ = 0;

	public AtsScreen() {
		super(Text.translatable("mtrctrl.ats.title"));
	}

	@Override
	public boolean shouldPause() {
		return false;
	}

	@Override
	public void render(DrawContext context, int mouseX, int mouseY, float delta) {
		rebuild();
		context.fill(0, 0, width, height, BG);
		context.drawTextWithShadow(textRenderer, Text.translatable("mtrctrl.ats.title"), 8, 6, TITLE);

		if (rails.isEmpty()) {
			context.drawTextWithShadow(textRenderer, OverlayUtil.tr("mtrctrl.ats.no_data"), 8, 24, STATION_TEXT);
			return;
		}

		final int pad = 12;
		final int mapX = pad;
		final int mapY = 24;
		final int mapW = Math.max(1, width - pad * 2);
		final int mapH = Math.max(1, height - mapY - pad);

		final double spanX = Math.max(1, maxX - minX);
		final double spanZ = Math.max(1, maxZ - minZ);
		final double scale = Math.min(mapW / spanX, mapH / spanZ);
		final double offsetX = mapX + (mapW - spanX * scale) / 2;
		final double offsetY = mapY + (mapH - spanZ * scale) / 2;

		for (final Rail rail : rails) {
			final double x1 = offsetX + (rail.railMath.minX - minX) * scale;
			final double y1 = offsetY + (rail.railMath.minZ - minZ) * scale;
			final double x2 = offsetX + (rail.railMath.maxX - minX) * scale;
			final double y2 = offsetY + (rail.railMath.maxZ - minZ) * scale;
			drawLine(context, x1, y1, x2, y2, TRACK_COLOR, 2);
		}

		for (final Platform platform : platforms) {
			final double cx = offsetX + (platform.getMidPosition().getX() - minX) * scale;
			final double cy = offsetY + (platform.getMidPosition().getZ() - minZ) * scale;
			final int s = 10;
			context.fill((int) (cx - s / 2.0), (int) (cy - s / 2.0), (int) (cx + s / 2.0), (int) (cy + s / 2.0), PLATFORM_COLOR);
		}

		for (final VehicleExtension vehicle : vehicles) {
			final Vector head = ClientDataUtil.headPosition(vehicle);
			if (head == null) {
				continue;
			}
			final double cx = offsetX + (head.x - minX) * scale;
			final double cy = offsetY + (head.z - minZ) * scale;
			final int s = 7;
			context.fill((int) (cx - s / 2.0), (int) (cy - s / 2.0), (int) (cx + s / 2.0), (int) (cy + s / 2.0), TRAIN_COLOR);
		}

		for (final Station station : stations) {
			final double cx = offsetX + ((station.getMinX() + station.getMaxX()) / 2.0 - minX) * scale;
			final double cy = offsetY + ((station.getMinZ() + station.getMaxZ()) / 2.0 - minZ) * scale;
			context.drawTextWithShadow(textRenderer, nz(station.getName()), (int) cx + 8, (int) cy - 4, STATION_TEXT);
		}
	}

	private void rebuild() {
		rails.clear();
		platforms.clear();
		stations.clear();
		vehicles.clear();

		final MinecraftClient client = MinecraftClient.getInstance();
		final MinecraftClientData data = ClientDataUtil.data(client);
		if (data == null) {
			return;
		}

		minX = Double.MAX_VALUE;
		maxX = -Double.MAX_VALUE;
		minZ = Double.MAX_VALUE;
		maxZ = -Double.MAX_VALUE;

		for (final Rail rail : data.rails) {
			rails.add(rail);
			minX = Math.min(minX, rail.railMath.minX);
			maxX = Math.max(maxX, rail.railMath.maxX);
			minZ = Math.min(minZ, rail.railMath.minZ);
			maxZ = Math.max(maxZ, rail.railMath.maxZ);
		}
		for (final Platform platform : data.platforms) {
			platforms.add(platform);
		}
		for (final Station station : data.stations) {
			stations.add(station);
			minX = Math.min(minX, station.getMinX());
			maxX = Math.max(maxX, station.getMaxX());
			minZ = Math.min(minZ, station.getMinZ());
			maxZ = Math.max(maxZ, station.getMaxZ());
		}
		for (final VehicleExtension vehicle : data.vehicles) {
			vehicles.add(vehicle);
		}

		if (minX > maxX) {
			minX = 0;
			maxX = 0;
		}
		if (minZ > maxZ) {
			minZ = 0;
			maxZ = 0;
		}
	}

	private static void drawLine(DrawContext context, double x1, double y1, double x2, double y2, int color, int thickness) {
		final double dx = x2 - x1;
		final double dy = y2 - y1;
		final double len = Math.max(1, Math.sqrt(dx * dx + dy * dy));
		final int steps = (int) Math.ceil(len);
		for (int i = 0; i <= steps; i++) {
			final double t = i / (double) steps;
			final int cx = (int) (x1 + dx * t);
			final int cy = (int) (y1 + dy * t);
			context.fill(cx, cy, cx + thickness, cy + thickness, color);
		}
	}

	private static String nz(String value) {
		return value == null || value.isEmpty() ? "-" : value;
	}
}
