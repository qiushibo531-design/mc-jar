package com.mtrctrl.client;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import com.mtrctrl.client.NetworkSnapshot.Line;
import com.mtrctrl.client.NetworkSnapshot.Train;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

/**
 * ATS 运行监视画面（操作台右键打开）：选一条线，盯着这条线的轨道、车站、信号、道岔和每一列车。
 * 白 = 轨道，红 = 列车，绿色长方形 = 车站。
 */
public final class AtsScreen extends Screen {

	private static final DateTimeFormatter CLOCK = DateTimeFormatter.ofPattern("HH:mm:ss");
	private static final int LIST_W = 170;

	/** 记住上次看的线路（空 = 全网）。 */
	private static String selectedKey = "";

	private final List<Zone> zones = new ArrayList<>();

	public AtsScreen() {
		super(Text.translatable("mtrctrl.ats.title"));
	}

	@Override
	public boolean shouldPause() {
		return false;
	}

	private void drawText(DrawContext context, String text, int x, int y, int color) {
		context.drawTextWithShadow(textRenderer, Fonts.song(text), x, y, color);
	}

	@Override
	public void render(DrawContext context, int mouseX, int mouseY, float delta) {
		zones.clear();
		final MinecraftClient client = MinecraftClient.getInstance();
		if (!ClientDataUtil.isInWorld(client)) {
			return;
		}
		final NetworkSnapshot snap = NetworkSnapshot.get(client);
		final MapData map = MapData.get(client);
		context.fill(0, 0, width, height, 0xF0020406);

		// 页眉
		context.fill(0, 0, width, 22, 0xFF0B1620);
		context.fill(0, 21, width, 22, 0xFF35506B);
		drawText(context, OverlayUtil.tr("mtrctrl.ats.title"), 8, 7, 0xFFE8D9A8);
		drawText(context, LocalTime.now().format(CLOCK), width / 2 - OverlayUtil.width(textRenderer, "00:00:00") / 2, 7, 0xFFFFFFFF);
		final String panel = OverlayUtil.tr("mtrctrl.ats.panel");
		final int panelW = OverlayUtil.width(textRenderer, panel) + 12;
		context.fill(width - panelW - 8, 3, width - 8, 19, 0xFF2E4E6E);
		drawText(context, panel, width - panelW - 2, 7, 0xFFFFFFFF);
		zones.add(new Zone(width - panelW - 8, 3, panelW, 16, () -> client.setScreen(new ControlScreen())));

		// 线路标签：全网 + 每条有车的线
		Line selected = null;
		int tx = 8;
		final List<String> keys = new ArrayList<>();
		final List<String> labels = new ArrayList<>();
		keys.add("");
		labels.add(OverlayUtil.tr("mtrctrl.ats.all"));
		for (final Line line : snap.lines) {
			keys.add(line.key);
			labels.add(line.name);
			if (line.key.equals(selectedKey)) {
				selected = line;
			}
		}
		if (selected == null) {
			selectedKey = "";
		}
		for (int i = 0; i < keys.size(); i++) {
			final String key = keys.get(i);
			final int w = OverlayUtil.width(textRenderer, labels.get(i)) + 16;
			if (tx + w > width - 8) {
				break;
			}
			final boolean on = key.equals(selectedKey);
			context.fill(tx, 26, tx + w, 42, on ? 0xFF1F3C57 : 0xFF0F1B27);
			if (on) {
				context.fill(tx, 41, tx + w, 43, 0xFFE8D9A8);
			}
			if (i > 0) {
				context.fill(tx + 3, 29, tx + 6, 39, snap.lines.get(i - 1).color);
			}
			drawText(context, labels.get(i), tx + (i > 0 ? 9 : 8), 30, on ? 0xFFFFFFFF : 0xFF8FA3B5);
			zones.add(new Zone(tx, 26, w, 16, () -> selectedKey = key));
			tx += w + 4;
		}

		// 画面
		final int ax = 6;
		final int ay = 48;
		final int aw = width - LIST_W - 14;
		final int ah = height - ay - 6;
		context.enableScissor(ax, ay, ax + aw, ay + ah);
		AtsLayouts.draw(new GuiCanvas(context, textRenderer), snap, map, ax, ay, aw, ah, selected, true);
		context.disableScissor();

		// 右侧：列车一览（红点 = 列车）
		final int lx = width - LIST_W - 6;
		context.fill(lx, ay, lx + LIST_W, ay + ah, 0xFF070D14);
		drawText(context, OverlayUtil.tr("mtrctrl.ats.trains"), lx + 6, ay + 5, 0xFFE8D9A8);
		int y = ay + 20;
		context.enableScissor(lx, ay, lx + LIST_W, ay + ah);
		for (final Line line : snap.lines) {
			if (selected != null && line != selected) {
				continue;
			}
			for (final Train t : line.trains) {
				if (y + 22 > ay + ah) {
					break;
				}
				context.fill(lx + 6, y + 3, lx + 12, y + 9, 0xFFFF2020);
				drawText(context, OverlayUtil.fit(textRenderer, t.lineShown + " → " + t.destShown, LIST_W - 26), lx + 17, y, 0xFFFFFFFF);
				final String info = OverlayUtil.tr("mtrctrl.board.col_next") + " " + t.nextShown + "  " + String.format("%.0f", t.kmh) + " km/h";
				drawText(context, OverlayUtil.fit(textRenderer, info, LIST_W - 26), lx + 17, y + 10, t.moving ? 0xFF7FD6FF : 0xFFFFD23F);
				y += 24;
			}
		}
		context.disableScissor();
	}

	@Override
	public boolean mouseClicked(double mouseX, double mouseY, int button) {
		if (button == 0) {
			for (final Zone zone : zones) {
				if (mouseX >= zone.x && mouseX <= zone.x + zone.w && mouseY >= zone.y && mouseY <= zone.y + zone.h) {
					zone.action.run();
					return true;
				}
			}
		}
		return super.mouseClicked(mouseX, mouseY, button);
	}

	private static final class Zone {
		final int x;
		final int y;
		final int w;
		final int h;
		final Runnable action;

		Zone(int x, int y, int w, int h, Runnable action) {
			this.x = x;
			this.y = y;
			this.w = w;
			this.h = h;
			this.action = action;
		}
	}
}
