package com.mtrctrl.client;

import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.RotationAxis;

/** 界面（DrawContext）上的画布；按调用顺序叠放，layer 在这里不起作用。 */
public final class GuiCanvas implements Canvas {

	private final DrawContext context;
	private final TextRenderer font;

	public GuiCanvas(DrawContext context, TextRenderer font) {
		this.context = context;
		this.font = font;
	}

	@Override
	public void rect(float x, float y, float w, float h, int argb, int layer) {
		if (w <= 0 || h <= 0) {
			return;
		}
		context.getMatrices().push();
		context.getMatrices().translate(x, y, 0);
		context.getMatrices().scale(w, h, 1);
		context.fill(0, 0, 1, 1, argb);
		context.getMatrices().pop();
	}

	@Override
	public void line(float x1, float y1, float x2, float y2, float thickness, int argb, int layer) {
		final float dx = x2 - x1;
		final float dy = y2 - y1;
		final float length = (float) Math.sqrt(dx * dx + dy * dy);
		if (length < 0.01F) {
			return;
		}
		context.getMatrices().push();
		context.getMatrices().translate(x1, y1, 0);
		context.getMatrices().multiply(RotationAxis.POSITIVE_Z.rotation((float) Math.atan2(dy, dx)));
		context.getMatrices().translate(0, -thickness / 2, 0);
		context.getMatrices().scale(length, thickness, 1);
		context.fill(0, 0, 1, 1, argb);
		context.getMatrices().pop();
	}

	@Override
	public void text(String text, float x, float y, float size, int argb, int align) {
		final float scale = size / 8.0F;
		final float w = width(text, size);
		final float left = align == 1 ? x - w / 2 : align == 2 ? x - w : x;
		context.getMatrices().push();
		context.getMatrices().translate(left, y, 0);
		context.getMatrices().scale(scale, scale, 1);
		context.drawText(font, Fonts.song(text), 0, 0, argb, false);
		context.getMatrices().pop();
	}

	@Override
	public float width(String text, float size) {
		return font.getWidth(Fonts.song(text)) * size / 8.0F;
	}
}
