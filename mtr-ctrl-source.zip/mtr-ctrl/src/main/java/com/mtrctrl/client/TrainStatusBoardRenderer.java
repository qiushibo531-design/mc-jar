package com.mtrctrl.client;

import com.mtrctrl.block.BoardGroup;
import com.mtrctrl.block.TrainStatusBoardBlock;
import com.mtrctrl.block.TrainStatusBoardBlockEntity;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.block.entity.BlockEntityRenderer;
import net.minecraft.client.render.block.entity.BlockEntityRendererFactory;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.RotationAxis;

/**
 * 调度大屏渲染器。每一块大屏只负责画「整面墙」里落在自己这 64×64 像素范围内的那部分，
 * 所以把大屏拼成任意大小的矩形墙，画面都会连成一整幅。
 */
public final class TrainStatusBoardRenderer implements BlockEntityRenderer<TrainStatusBoardBlockEntity> {

	/** 1 像素 = 1/64 格。 */
	private static final float SCALE = 1.0F / WallPainter.TILE;

	private boolean failed;

	public TrainStatusBoardRenderer(BlockEntityRendererFactory.Context context) {
	}

	@Override
	public int getRenderDistance() {
		return 128;
	}

	@Override
	public void render(TrainStatusBoardBlockEntity entity, float tickDelta, MatrixStack matrices, VertexConsumerProvider vertexConsumers, int light, int overlay) {
		if (failed) {
			return;
		}
		final MinecraftClient client = MinecraftClient.getInstance();
		if (!ClientDataUtil.isInWorld(client)) {
			return;
		}
		final BoardGroup group = entity.getGroup();
		if (group == null) {
			return;
		}
		matrices.push();
		try {
			final NetworkSnapshot snapshot = NetworkSnapshot.get(client);
			final Direction facing = entity.getCachedState().get(TrainStatusBoardBlock.FACING);

			final float wallW = group.widthTiles() * WallPainter.TILE;
			final float wallH = group.heightTiles() * WallPainter.TILE;
			final float tileX = group.tileU(entity.getPos()) * WallPainter.TILE;
			final float tileY = group.tileRow(entity.getPos()) * WallPainter.TILE;

			matrices.translate(0.5, 0.5, 0.5);
			matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-facing.asRotation()));
			matrices.translate(0.0, 0.0, 0.505);
			matrices.scale(SCALE, -SCALE, SCALE);
			// 设计坐标 (tileX, tileY) 对应本块方块的左上角（本地坐标 -32, -32）。
			matrices.translate(-WallPainter.TILE / 2.0F - tileX, -WallPainter.TILE / 2.0F - tileY, 0.0F);

			final WallPainter painter = new WallPainter(matrices, vertexConsumers, client.textRenderer,
					tileX, tileY, tileX + WallPainter.TILE, tileY + WallPainter.TILE);
			if (entity.getMode() == 1) {
				BoardLayouts.summary(painter, snapshot, wallW, wallH);
			} else {
				BoardLayouts.diagram(painter, snapshot, wallW, wallH);
			}
			painter.flush();
		} catch (RuntimeException e) {
			// 渲染出错时关掉大屏渲染，避免每帧刷屏或崩溃。
			failed = true;
			e.printStackTrace();
		} finally {
			matrices.pop();
		}
	}
}
