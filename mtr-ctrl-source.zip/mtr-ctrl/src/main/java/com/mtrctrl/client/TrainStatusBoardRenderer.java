package com.mtrctrl.client;

import java.util.ArrayList;
import java.util.List;

import org.mtr.mod.client.MinecraftClientData;
import org.mtr.mod.data.VehicleExtension;

import com.mtrctrl.block.TrainStatusBoardBlock;
import com.mtrctrl.block.TrainStatusBoardBlockEntity;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.block.entity.BlockEntityRenderer;
import net.minecraft.client.render.block.entity.BlockEntityRendererFactory;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.Text;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.RotationAxis;

/**
 * 调度大屏渲染器：在方块正面实时绘制所有列车的速度、距月台距离与下一站。
 */
public final class TrainStatusBoardRenderer implements BlockEntityRenderer<TrainStatusBoardBlockEntity> {

	/** 文本缩放：1/96，使文本坐标约在 [-48, 48] 区间内铺满一个方块面。 */
	private static final float SCALE = 1.0F / 96.0F;
	private static final int LINE_HEIGHT = 8;
	private static final int MAX_TRAINS = 4;

	private static final int TITLE_COLOR = 0xFFFFC94D;
	private static final int ROUTE_COLOR = 0xFFFFFFFF;
	private static final int DETAIL_COLOR = 0xFF9ADBFF;

	public TrainStatusBoardRenderer(BlockEntityRendererFactory.Context context) {
	}

	@Override
	public void render(TrainStatusBoardBlockEntity entity, float tickDelta, MatrixStack matrices, VertexConsumerProvider vertexConsumers, int light, int overlay) {
		final MinecraftClient client = MinecraftClient.getInstance();
		if (client == null || client.player == null) {
			return;
		}
		final MinecraftClientData data = ClientDataUtil.data(client);
		if (data == null) {
			return;
		}

		final Direction facing = entity.getCachedState().get(TrainStatusBoardBlock.FACING);

		matrices.push();
		matrices.translate(0.5, 0.5, 0.5);
		matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-facing.asRotation()));
		matrices.translate(0.0, 0.0, 0.51);
		matrices.scale(SCALE, -SCALE, SCALE);

		final TextRenderer font = client.textRenderer;
		int y = -44;
		draw(font, OverlayUtil.tr("mtrctrl.board.title"), -46, y, TITLE_COLOR, matrices, vertexConsumers, light);
		y += LINE_HEIGHT + 2;

		final List<VehicleExtension> vehicles = new ArrayList<>();
		for (final VehicleExtension vehicle : data.vehicles) {
			vehicles.add(vehicle);
		}

		if (vehicles.isEmpty()) {
			draw(font, OverlayUtil.tr("mtrctrl.board.no_train"), -46, y, DETAIL_COLOR, matrices, vertexConsumers, light);
		}

		int count = 0;
		for (final VehicleExtension vehicle : vehicles) {
			if (count++ >= MAX_TRAINS) {
				break;
			}
			final String route = nz(vehicle.vehicleExtraData.getThisRouteName());
			final double kmh = ClientDataUtil.speedKmh(vehicle);
			final String speed = round1(kmh) + " km/h";

			draw(font, route + "   " + speed, -46, y, ROUTE_COLOR, matrices, vertexConsumers, light);
			y += LINE_HEIGHT;

			final Double distance = ClientDataUtil.distanceToPlatform(vehicle);
			final String next = nz(vehicle.vehicleExtraData.getNextStationName());
			final String dist = distance == null ? "-" : round1(distance) + " m";
			draw(font, OverlayUtil.tr("mtrctrl.board.to_platform") + dist + "   " + OverlayUtil.tr("mtrctrl.board.next") + next, -40, y, DETAIL_COLOR, matrices, vertexConsumers, light);
			y += LINE_HEIGHT + 2;
		}

		matrices.pop();
	}

	private static void draw(TextRenderer font, String text, float x, float y, int color, MatrixStack matrices, VertexConsumerProvider vertexConsumers, int light) {
		font.draw(Text.literal(text), x, y, color, false, matrices.peek().getPositionMatrix(), vertexConsumers, TextRenderer.TextLayerType.NORMAL, 0x00000000, light);
	}

	private static String nz(String value) {
		return value == null || value.isEmpty() ? "-" : value;
	}

	private static String round1(double value) {
		return String.format("%.1f", value);
	}
}
