package com.mtrctrl.block;

import com.mtrctrl.client.ControlScreen;

import net.fabricmc.api.EnvExecutor;
import net.fabricmc.api.EnvType;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

/**
 * 调度控制台：右键打开轨道 / 信号控制面板。
 */
public final class ControlConsoleBlock extends Block {

	public ControlConsoleBlock(Settings settings) {
		super(settings);
	}

	@Override
	public ActionResult onUse(BlockState state, World world, BlockPos pos, PlayerEntity player, Hand hand, BlockHitResult hit) {
		EnvExecutor.runWhenOn(EnvType.CLIENT, () -> () -> MinecraftClient.getInstance().setScreen(new ControlScreen()));
		return ActionResult.SUCCESS;
	}
}
