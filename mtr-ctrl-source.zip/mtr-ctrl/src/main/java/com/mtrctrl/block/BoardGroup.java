package com.mtrctrl.block;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.mtrctrl.ModBlocks;

import net.minecraft.block.BlockState;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.World;

/**
 * 一整面由大屏方块拼成的「墙」：同朝向、在同一平面内相邻的所有大屏。
 * 服务端用它来同步切换显示模式，客户端用它来算每一块在整面墙里的位置。
 */
public final class BoardGroup {

	private static final int MAX_TILES = 1024;

	public final List<BlockPos> tiles = new ArrayList<>();
	public final Direction facing;
	public final int minU;
	public final int maxU;
	public final int minY;
	public final int maxY;

	private BoardGroup(Direction facing, List<BlockPos> tiles, int minU, int maxU, int minY, int maxY) {
		this.facing = facing;
		this.tiles.addAll(tiles);
		this.minU = minU;
		this.maxU = maxU;
		this.minY = minY;
		this.maxY = maxY;
	}

	/** 从观看者（站在屏幕正面）视角看，向右为 u 增大的方向。 */
	public static int u(Direction facing, BlockPos pos) {
		final Direction right = facing.rotateYCounterclockwise();
		return pos.getX() * right.getOffsetX() + pos.getZ() * right.getOffsetZ();
	}

	public int tileU(BlockPos pos) {
		return u(facing, pos) - minU;
	}

	public int tileRow(BlockPos pos) {
		return maxY - pos.getY();
	}

	public int widthTiles() {
		return maxU - minU + 1;
	}

	public int heightTiles() {
		return maxY - minY + 1;
	}

	public static BoardGroup find(World world, BlockPos origin, Direction facing) {
		final Direction right = facing.rotateYCounterclockwise();
		final Set<BlockPos> seen = new HashSet<>();
		final ArrayDeque<BlockPos> queue = new ArrayDeque<>();
		final List<BlockPos> tiles = new ArrayList<>();
		seen.add(origin);
		queue.add(origin);
		int minU = Integer.MAX_VALUE;
		int maxU = Integer.MIN_VALUE;
		int minY = Integer.MAX_VALUE;
		int maxY = Integer.MIN_VALUE;
		while (!queue.isEmpty() && tiles.size() < MAX_TILES) {
			final BlockPos pos = queue.poll();
			tiles.add(pos);
			final int u = u(facing, pos);
			minU = Math.min(minU, u);
			maxU = Math.max(maxU, u);
			minY = Math.min(minY, pos.getY());
			maxY = Math.max(maxY, pos.getY());
			final BlockPos[] neighbours = {pos.offset(right), pos.offset(right.getOpposite()), pos.up(), pos.down()};
			for (final BlockPos next : neighbours) {
				if (seen.contains(next)) {
					continue;
				}
				seen.add(next);
				final BlockState state = world.getBlockState(next);
				if (state.isOf(ModBlocks.TRAIN_STATUS_BOARD) && state.get(TrainStatusBoardBlock.FACING) == facing) {
					queue.add(next);
				}
			}
		}
		return new BoardGroup(facing, tiles, minU, maxU, minY, maxY);
	}
}
