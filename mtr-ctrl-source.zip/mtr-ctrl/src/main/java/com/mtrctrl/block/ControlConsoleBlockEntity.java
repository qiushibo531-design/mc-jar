package com.mtrctrl.block;

import com.mtrctrl.ModBlocks;

import net.minecraft.block.BlockState;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.util.math.BlockPos;

/**
 * 调度控制台的方块实体：只用来挂载客户端渲染器，让上方大屏实时显示 ATS 运行监视画面。
 */
public final class ControlConsoleBlockEntity extends BlockEntity {

	public ControlConsoleBlockEntity(BlockPos pos, BlockState state) {
		super(ModBlocks.CONTROL_CONSOLE_ENTITY, pos, state);
	}
}
