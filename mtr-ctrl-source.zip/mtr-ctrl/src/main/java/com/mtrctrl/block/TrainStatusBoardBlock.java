package com.mtrctrl.block;

import com.mojang.serialization.MapCodec;

import net.minecraft.block.Block;
import net.minecraft.block.BlockRenderType;
import net.minecraft.block.BlockState;
import net.minecraft.block.BlockWithEntity;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.DirectionProperty;
import net.minecraft.state.property.Properties;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.BlockMirror;
import net.minecraft.util.BlockRotation;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.World;

import org.jetbrains.annotations.Nullable;

/**
 * 调度大屏：带朝向的方块，多块相邻拼成一整面墙；正面由客户端渲染器实时绘制线路图 / 总览。
 * 右键切换显示模式（整面墙一起切换）。
 */
public final class TrainStatusBoardBlock extends BlockWithEntity {

	public static final MapCodec<TrainStatusBoardBlock> CODEC = createCodec(TrainStatusBoardBlock::new);

	public static final DirectionProperty FACING = Properties.HORIZONTAL_FACING;

	public TrainStatusBoardBlock(Settings settings) {
		super(settings);
		setDefaultState(getStateManager().getDefaultState().with(FACING, Direction.NORTH));
	}

	@Override
	protected MapCodec<? extends BlockWithEntity> getCodec() {
		return CODEC;
	}

	@Override
	protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
		builder.add(FACING);
	}

	@Override
	public BlockState getPlacementState(ItemPlacementContext context) {
		return getDefaultState().with(FACING, context.getHorizontalPlayerFacing().getOpposite());
	}

	@Override
	public BlockState rotate(BlockState state, BlockRotation rotation) {
		return state.with(FACING, rotation.rotate(state.get(FACING)));
	}

	@Override
	public BlockState mirror(BlockState state, BlockMirror mirror) {
		return state.rotate(mirror.getRotation(state.get(FACING)));
	}

	@Override
	public ActionResult onUse(BlockState state, World world, BlockPos pos, PlayerEntity player, Hand hand, BlockHitResult hit) {
		if (!world.isClient) {
			final BlockEntity self = world.getBlockEntity(pos);
			if (self instanceof TrainStatusBoardBlockEntity board) {
				final int next = (board.getMode() + 1) % TrainStatusBoardBlockEntity.MODES;
				final BoardGroup group = BoardGroup.find(world, pos, state.get(FACING));
				for (final BlockPos tile : group.tiles) {
					final BlockEntity other = world.getBlockEntity(tile);
					if (other instanceof TrainStatusBoardBlockEntity otherBoard) {
						otherBoard.setMode(next);
					}
				}
				player.sendMessage(Text.translatable("mtrctrl.board.mode." + next), true);
			}
		}
		return ActionResult.SUCCESS;
	}

	@Nullable
	@Override
	public BlockEntity createBlockEntity(BlockPos pos, BlockState state) {
		return new TrainStatusBoardBlockEntity(pos, state);
	}

	@Override
	public BlockRenderType getRenderType(BlockState state) {
		return BlockRenderType.MODEL;
	}
}
