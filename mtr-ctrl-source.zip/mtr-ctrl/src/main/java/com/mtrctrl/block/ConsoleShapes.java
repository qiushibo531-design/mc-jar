package com.mtrctrl.block;

import net.minecraft.block.Block;
import net.minecraft.util.math.Direction;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.util.shape.VoxelShapes;

/**
 * 控制台 / 控制台桌的碰撞箱：按朝向把「朝北」的长方体组旋转 0/90/180/270 度。
 */
final class ConsoleShapes {

	private ConsoleShapes() {
	}

	/** boxes 每项为 {x1, y1, z1, x2, y2, z2}（0~16，朝北时的坐标）。 */
	static VoxelShape[] build(double[][] boxes) {
		final VoxelShape[] result = new VoxelShape[4];
		for (int turns = 0; turns < 4; turns++) {
			VoxelShape shape = VoxelShapes.empty();
			for (final double[] b : boxes) {
				double x1 = b[0];
				double z1 = b[2];
				double x2 = b[3];
				double z2 = b[5];
				for (int i = 0; i < turns; i++) {
					final double nx1 = 16 - z2;
					final double nx2 = 16 - z1;
					final double nz1 = x1;
					final double nz2 = x2;
					x1 = nx1;
					x2 = nx2;
					z1 = nz1;
					z2 = nz2;
				}
				shape = VoxelShapes.union(shape, Block.createCuboidShape(x1, b[1], z1, x2, b[4], z2));
			}
			result[turns] = shape;
		}
		return result;
	}

	static VoxelShape pick(VoxelShape[] shapes, Direction facing) {
		switch (facing) {
			case EAST:
				return shapes[1];
			case SOUTH:
				return shapes[2];
			case WEST:
				return shapes[3];
			default:
				return shapes[0];
		}
	}
}
