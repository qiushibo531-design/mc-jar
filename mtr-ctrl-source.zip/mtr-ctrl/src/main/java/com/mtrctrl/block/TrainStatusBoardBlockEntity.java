package com.mtrctrl.block;

import com.mtrctrl.ModBlocks;

import net.minecraft.block.BlockState;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.network.listener.ClientPlayPacketListener;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.s2c.play.BlockEntityUpdateS2CPacket;
import net.minecraft.util.math.BlockPos;

/**
 * 调度大屏的方块实体：只保存显示模式（线路图 / 总览），列车数据由渲染器在客户端实时读取。
 */
public final class TrainStatusBoardBlockEntity extends BlockEntity {

	public static final int MODES = 3;

	private int mode = 0;

	/** 客户端缓存：本块所在的整面墙，每秒左右刷新一次。 */
	private BoardGroup cachedGroup;
	private long cachedGroupTime = Long.MIN_VALUE;

	public TrainStatusBoardBlockEntity(BlockPos pos, BlockState state) {
		super(ModBlocks.TRAIN_STATUS_BOARD_ENTITY, pos, state);
	}

	public int getMode() {
		return mode;
	}

	public void setMode(int mode) {
		this.mode = Math.floorMod(mode, MODES);
		markDirty();
		if (world != null) {
			world.updateListeners(pos, getCachedState(), getCachedState(), 3);
		}
	}

	/** 客户端调用：取（并按需刷新）本块所在的整面墙。 */
	public BoardGroup getGroup() {
		if (world == null) {
			return null;
		}
		final long now = world.getTime();
		if (cachedGroup == null || now - cachedGroupTime >= 20 || now < cachedGroupTime) {
			cachedGroup = BoardGroup.find(world, pos, getCachedState().get(TrainStatusBoardBlock.FACING));
			cachedGroupTime = now;
		}
		return cachedGroup;
	}

	@Override
	protected void writeNbt(NbtCompound nbt) {
		super.writeNbt(nbt);
		nbt.putInt("Mode", mode);
	}

	@Override
	public void readNbt(NbtCompound nbt) {
		super.readNbt(nbt);
		mode = Math.floorMod(nbt.getInt("Mode"), MODES);
	}

	@Override
	public Packet<ClientPlayPacketListener> toUpdatePacket() {
		return BlockEntityUpdateS2CPacket.create(this);
	}

	@Override
	public NbtCompound toInitialChunkDataNbt() {
		return createNbt();
	}
}
