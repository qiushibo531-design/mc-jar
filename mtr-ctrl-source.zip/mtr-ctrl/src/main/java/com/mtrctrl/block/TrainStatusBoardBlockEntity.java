package com.mtrctrl.block;

import com.mtrctrl.ModBlocks;

import net.minecraft.block.BlockState;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.util.math.BlockPos;

/**
 * 调度大屏的方块实体。本身不存储业务数据，列车状态由渲染器在客户端实时读取。
 */
public final class TrainStatusBoardBlockEntity extends BlockEntity {

	public TrainStatusBoardBlockEntity(BlockPos pos, BlockState state) {
		super(ModBlocks.TRAIN_STATUS_BOARD_ENTITY, pos, state);
	}
}
