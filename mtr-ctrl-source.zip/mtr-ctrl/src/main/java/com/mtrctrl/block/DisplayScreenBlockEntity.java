package com.mtrctrl.block;

import com.mtrctrl.ModBlocks;

import net.minecraft.block.BlockState;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.util.math.BlockPos;

/**
 * 显示屏的方块实体。本身不存业务数据，内容由主屏渲染器在客户端实时读取。
 */
public final class DisplayScreenBlockEntity extends BlockEntity {

	public DisplayScreenBlockEntity(BlockPos pos, BlockState state) {
		super(ModBlocks.DISPLAY_SCREEN_ENTITY, pos, state);
	}
}
