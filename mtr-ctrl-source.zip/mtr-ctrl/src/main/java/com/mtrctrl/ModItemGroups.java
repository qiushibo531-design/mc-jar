package com.mtrctrl;

import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

/**
 * 创造模式物品栏（背包）里的「MTR 调度中心」独立分页。
 */
public final class ModItemGroups {

	public static final ItemGroup MAIN = FabricItemGroup.builder()
			.icon(() -> new ItemStack(ModBlocks.TRAIN_STATUS_BOARD_ITEM))
			.displayName(Text.translatable("itemGroup.mtrctrl.main"))
			.entries((context, entries) -> {
				entries.add(ModBlocks.TRAIN_STATUS_BOARD_ITEM);
				entries.add(ModBlocks.CONTROL_CONSOLE_ITEM);
				entries.add(ModBlocks.CONTROL_DESK_ITEM);
			})
			.build();

	private ModItemGroups() {
	}

	public static void register() {
		Registry.register(Registries.ITEM_GROUP, new Identifier(MTRCtrl.MOD_ID, "main"), MAIN);
	}
}
