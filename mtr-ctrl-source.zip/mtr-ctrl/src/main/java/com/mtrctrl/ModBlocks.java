package com.mtrctrl;

import com.mtrctrl.block.ControlConsoleBlock;
import com.mtrctrl.block.TrainStatusBoardBlock;
import com.mtrctrl.block.TrainStatusBoardBlockEntity;

import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.MapColor;
import net.minecraft.block.entity.BlockEntityType;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

/**
 * 本模组的方块、物品与方块实体注册。
 */
public final class ModBlocks {

	public static final Block TRAIN_STATUS_BOARD = new TrainStatusBoardBlock(AbstractBlock.Settings.create().mapColor(MapColor.BLACK).strength(2.0F));
	public static final Block CONTROL_CONSOLE = new ControlConsoleBlock(AbstractBlock.Settings.create().mapColor(MapColor.IRON_GRAY).strength(2.0F));

	public static final BlockItem TRAIN_STATUS_BOARD_ITEM = new BlockItem(TRAIN_STATUS_BOARD, new Item.Settings());
	public static final BlockItem CONTROL_CONSOLE_ITEM = new BlockItem(CONTROL_CONSOLE, new Item.Settings());

	public static final BlockEntityType<TrainStatusBoardBlockEntity> TRAIN_STATUS_BOARD_ENTITY =
			BlockEntityType.Builder.create(TrainStatusBoardBlockEntity::new, TRAIN_STATUS_BOARD).build(null);

	private ModBlocks() {
	}

	public static void register() {
		Registry.register(Registries.BLOCK, id("train_status_board"), TRAIN_STATUS_BOARD);
		Registry.register(Registries.ITEM, id("train_status_board"), TRAIN_STATUS_BOARD_ITEM);
		Registry.register(Registries.BLOCK_ENTITY_TYPE, id("train_status_board"), TRAIN_STATUS_BOARD_ENTITY);

		Registry.register(Registries.BLOCK, id("control_console"), CONTROL_CONSOLE);
		Registry.register(Registries.ITEM, id("control_console"), CONTROL_CONSOLE_ITEM);
	}

	private static Identifier id(String path) {
		return new Identifier(MTRCtrl.MOD_ID, path);
	}
}
