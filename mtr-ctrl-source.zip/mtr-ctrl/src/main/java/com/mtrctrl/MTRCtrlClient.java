package com.mtrctrl;

import com.mtrctrl.client.ConsoleRenderer;
import com.mtrctrl.client.RailBlockManager;
import com.mtrctrl.client.TrainStatusBoardRenderer;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.BlockEntityRendererRegistry;

/**
 * 客户端入口：注册大屏渲染器，并驱动「持续拦停」的周期重发。
 */
public final class MTRCtrlClient implements ClientModInitializer {

	@Override
	public void onInitializeClient() {
		BlockEntityRendererRegistry.register(ModBlocks.TRAIN_STATUS_BOARD_ENTITY, TrainStatusBoardRenderer::new);
		BlockEntityRendererRegistry.register(ModBlocks.CONTROL_CONSOLE_ENTITY, ConsoleRenderer::new);
		ClientTickEvents.END_CLIENT_TICK.register(RailBlockManager::tick);
	}
}
