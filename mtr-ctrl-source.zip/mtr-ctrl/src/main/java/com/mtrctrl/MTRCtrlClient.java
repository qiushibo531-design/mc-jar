package com.mtrctrl;

import com.mtrctrl.client.TrainStatusBoardRenderer;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.BlockEntityRendererRegistry;

/**
 * 客户端入口：注册方块实体渲染器。
 */
public final class MTRCtrlClient implements ClientModInitializer {

	@Override
	public void onInitializeClient() {
		BlockEntityRendererRegistry.register(ModBlocks.TRAIN_STATUS_BOARD_ENTITY, TrainStatusBoardRenderer::new);
	}
}
