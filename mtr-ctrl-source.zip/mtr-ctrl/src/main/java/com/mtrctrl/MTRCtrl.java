package com.mtrctrl;

import net.fabricmc.api.ModInitializer;

/**
 * 公共入口：注册方块、物品、方块实体与创造模式物品栏分页。
 */
public final class MTRCtrl implements ModInitializer {

	public static final String MOD_ID = "mtrctrl";

	@Override
	public void onInitialize() {
		ModBlocks.register();
		ModItemGroups.register();
	}
}
