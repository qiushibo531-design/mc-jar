package com.mtrctrl;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

/**
 * 公共入口：注册方块、物品与方块实体，并创建本模组专属的创造模式物品栏分页。
 */
public final class MTRCtrl implements ModInitializer {

	public static final String MOD_ID = "mtrctrl";

	public static final RegistryKey<ItemGroup> ITEM_GROUP_KEY = RegistryKey.of(RegistryKeys.ITEM_GROUP, id("mtrctrl"));
	public static final ItemGroup ITEM_GROUP = FabricItemGroup.builder()
			.icon(() -> new ItemStack(ModBlocks.ATS_CONSOLE_ITEM))
			.displayName(Text.translatable("itemGroup.mtrctrl"))
			.build();

	@Override
	public void onInitialize() {
		ModBlocks.register();

		Registry.register(Registries.ITEM_GROUP, ITEM_GROUP_KEY, ITEM_GROUP);
		ItemGroupEvents.modifyEntriesEvent(ITEM_GROUP_KEY).register(entries -> {
			entries.add(ModBlocks.TRAIN_STATUS_BOARD_ITEM);
			entries.add(ModBlocks.DISPLAY_SCREEN_ITEM);
			entries.add(ModBlocks.ATS_CONSOLE_ITEM);
			entries.add(ModBlocks.CONTROL_CONSOLE_ITEM);
		});
	}

	private static Identifier id(String path) {
		return new Identifier(MOD_ID, path);
	}
}
