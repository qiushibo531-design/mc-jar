package com.mtrctrl;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.item.ItemGroups;

/**
 * 公共入口：注册方块、物品与方块实体，并把物品加入创造模式物品栏。
 */
public final class MTRCtrl implements ModInitializer {

	public static final String MOD_ID = "mtrctrl";

	@Override
	public void onInitialize() {
		ModBlocks.register();
		ItemGroupEvents.modifyEntriesEvent(ItemGroups.FUNCTIONAL).register(entries -> {
			entries.add(ModBlocks.TRAIN_STATUS_BOARD_ITEM);
			entries.add(ModBlocks.CONTROL_CONSOLE_ITEM);
		});
	}
}
