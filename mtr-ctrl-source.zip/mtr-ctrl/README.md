# MTR Ctrl — MTR 4 附属模组（Fabric 1.20.4）

面向 **Minecraft 1.20.4 + Fabric + MTR 4.0.5** 的附属模组，仿「车站控制指挥中心 / 调度中心」：

- **列车状态大屏**（可放置方块）：在方块正面实时显示所有列车的速度、距月台距离、下一站。
- **调度控制台**（可放置方块）：右键打开调度控制面板，可对轨道「拦停/放行」、对单趟列车「扣车/放行」、改路线/改终点、全部放行。

所有信息都是实时读取 MTR 客户端数据渲染，不需要额外配置。

## 环境

| 项 | 版本 |
|---|---|
| Minecraft | 1.20.4 |
| Fabric Loader | 0.16.x |
| Fabric API | 0.97.1+1.20.4 |
| MTR | 4.0.5（`FABRIC-4.0.5+1.20.4`） |
| Java | 17 |

## 编译

1. 下载 MTR 开发 jar，重命名为 `MTR-fabric-4.0.5+1.20.4-server.jar`，放进本工程 `libs/` 目录（没有就新建）。
   注意：要「server」分类的开发 jar，Modrinth / CurseForge 上的玩家版不行。
2. 用 IntelliJ IDEA（装 Minecraft Development 插件）打开本目录，或用命令行 `gradle build`。
3. 产物 `build/libs/mtr-ctrl-1.0.0.jar`，与 MTR、Fabric API 一起放入 `mods/`。

## 使用

- 在创造模式的「功能方块」物品栏里取「列车状态大屏」和「调度控制台」，放置即可。
- 大屏正面会自动实时刷新列车状态；放置时朝向放置者。
- 右键控制台打开调度控制面板：附近轨道「拦停 / 放行」、单趟列车「扣车 / 放行」、右上角「改路线」、顶部「全部放行」。

## 与 MTR 的对应

- **列车状态数据**：读 MTR 客户端 `MinecraftClientData.vehicles`，速度按 `speed × 3600` 换算 km/h，
  距月台距离取自 `VehicleExtension.getPlatformStoppingDetails()`。
- **信号放行 / 拦停**：复用 MTR 核心 `BlockRails` 操作（`OperationProcessor.BLOCK_RAILS`），
  手动拦停只持续约 1 秒，故由 `RailBlockManager` 周期性重发。
- **改路线 / 改终点**：通过 `UpdateDataRequest`（`OperationProcessor.UPDATE_DATA`）回写线路——移除停靠站或把月台列表截断到所选车站。
- **列车扣车 / 放行**：定位列车头所在轨道，用 `RailBlockManager` 持续对该轨道发送 `BlockRails`。

## 已知限制

- **手动驾驶（加速 / 刹车）未实现**：MTR 4.0.5 后端没有驾驶操作键（`PacketDriveTrain#runServer` 在官方源码里是 TODO）。
- 本工程未在本机实际编译 / 运行验证；若个别 API 签名与 MTR 4.0.5 实际类有差异，按 `org.mtr.core` / `org.mtr.mod` 实际类微调。
- 大屏上的中文需要 CJK 字体（MTR 自带 unifont，装 MTR 后即可正常显示）。

## 目录结构

```
mtr-ctrl/
├── build.gradle / gradle.properties / settings.gradle
├── libs/                            # 编译前放入 MTR 开发 jar
└── src/main/
    ├── java/com/mtrctrl/
    │   ├── MTRCtrl.java             # 公共入口（注册方块/物品/方块实体）
    │   ├── MTRCtrlClient.java       # 客户端入口（注册渲染器）
    │   ├── ModBlocks.java           # 方块/物品/方块实体注册
    │   ├── block/
    │   │   ├── TrainStatusBoardBlock.java       # 大屏方块
    │   │   ├── TrainStatusBoardBlockEntity.java # 大屏方块实体
    │   │   └── ControlConsoleBlock.java         # 控制台方块
    │   └── client/
    │       ├── TrainStatusBoardRenderer.java    # 大屏渲染器（方块表面画文字）
    │       ├── ClientDataUtil.java              # 读取 MTR 客户端数据
    │       ├── ControlScreen.java               # 控制面板 GUI
    │       ├── RailBlockManager.java            # 持续拦停（重发 BlockRails）
    │       ├── RouteEditor.java             # 改路线/改终点（UpdateDataRequest）
    │       ├── RouteEditScreen.java         # 改路线界面（移除站/设终点）
    │       └── OverlayUtil.java                 # 文本绘制工具
    └── resources/
        ├── fabric.mod.json
        └── assets/mtrctrl/
            ├── blockstates/  models/            # 方块模型
            └── lang/ {zh_cn,en_us}.json
```
