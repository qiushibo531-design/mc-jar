# 1.7.4 (Uncle Lion edition, Minecraft 1.20.4 Fabric)

Based on Dango Music 1.7.3 by Sorihiko (GPL-3.0). Additions by 狮子叔叔Uncle Lion:

- **New target:** Minecraft 1.20.4 Fabric (`modern/versions/1.20.4-fabric`, `modern/src/mc1.20.4`).
- **NetEase login:** SMS-code login and phone / e-mail + password login, next to QR login (tabs in the login window).
- **Account-less playlists:** create / rename / delete playlists stored in `config/dangomusic/local_playlists.json`, add songs with the `+` button on any song row, remove with `x`. They appear under every music source.
- **More sources (no login):** Audius, Internet Archive, ccMixter, Deezer (30 s previews), Kuwo, Migu.
- **Public lobby for Listen Together:** hosts can list their room publicly; everyone can browse and join from the Listen Together page. Firebase users must publish the updated `database.rules.json` (new `publicRooms` node). The in-game server transport needs no setup.
- **Interface settings:** interface size, button size and accent colour (Settings → Music & HUD → Interface).
- GitHub Actions workflow `.github/workflows/build.yml` builds the 1.20.4 jar.
