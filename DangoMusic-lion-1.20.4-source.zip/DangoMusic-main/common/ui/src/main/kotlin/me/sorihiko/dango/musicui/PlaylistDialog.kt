package me.sorihiko.dango.musicui

import me.sorihiko.dango.DangoClient
import me.sorihiko.dango.i18n.I18n
import me.sorihiko.dango.music.LocalPlaylists
import me.sorihiko.dango.music.MusicScreen
import me.sorihiko.dango.music.NeteasePlaylist
import me.sorihiko.dango.music.NeteaseTrack
import me.sorihiko.dango.platform.Keys
import me.sorihiko.dango.ui.LayoutBounds
import me.sorihiko.dango.ui.ShapeStyle
import me.sorihiko.dango.ui.Theme
import me.sorihiko.dango.utils.Color

/**
 * Popup for the account-less playlists: create / rename (text input), pick a playlist to add a song to,
 * and confirm deleting. Covers the whole player while open, like [LoginDialog].
 */
internal class PlaylistDialog(private val screen: MusicScreen) {
    private enum class Mode { NONE, NEW, RENAME, PICK, DELETE }

    private val ui = screen.ui
    private val hits = mutableListOf<Hit>()

    companion object {
        private var mode = Mode.NONE
        private var text = ""
        private var target: NeteasePlaylist? = null
        private var pending: NeteaseTrack? = null
        private var pickScroll = 0
        private const val ROWS = 6
    }

    val visible: Boolean get() = mode != Mode.NONE
    /** The name field is active (lets the platform enable the IME). */
    val editing: Boolean get() = mode == Mode.NEW || mode == Mode.RENAME

    /** New playlist; [thenAdd] is added to it right after it is created. */
    fun openNew(thenAdd: NeteaseTrack? = null) { mode = Mode.NEW; text = ""; pending = thenAdd }
    fun openRename(p: NeteasePlaylist) { mode = Mode.RENAME; text = p.name; target = p }
    fun openDelete(p: NeteasePlaylist) { mode = Mode.DELETE; target = p }
    fun openPick(track: NeteaseTrack) { mode = Mode.PICK; pending = track; pickScroll = 0 }
    fun close() { mode = Mode.NONE; pending = null; target = null; text = "" }

    fun scroll(wheel: Int) {
        if (mode != Mode.PICK) return
        val max = (LocalPlaylists.list().size - ROWS).coerceAtLeast(0)
        pickScroll = (pickScroll + if (wheel > 0) -1 else 1).coerceIn(0, max)
    }

    private fun commitText() {
        val name = text.trim()
        if (name.isEmpty()) return
        when (mode) {
            Mode.NEW -> {
                val id = LocalPlaylists.create(name)
                pending?.let { LocalPlaylists.add(id, it) }
                Library.localChanged(id)
                Library.showTemporaryStatus(I18n.text("Playlist created"), 2500)
            }
            Mode.RENAME -> target?.let { LocalPlaylists.rename(it.id, name); Library.localChanged(it.id) }
            else -> {}
        }
        close()
    }

    private fun addTo(p: NeteasePlaylist) {
        val t = pending ?: return
        val added = LocalPlaylists.add(p.id, t)
        Library.localChanged(p.id)
        Library.showTemporaryStatus(I18n.text(if (added) "Added to playlist" else "Already in this playlist"), 2500)
        close()
    }

    fun draw() {
        val ctx = ui.ctx
        hits.clear()
        if (mode == Mode.NONE) return
        ctx.drawShape(LayoutBounds(0f, 0f, ui.lw, ui.lh), ShapeStyle(Color(0f, 0f, 0f, 0.45f)))
        val w = 300f
        val lists = if (mode == Mode.PICK) LocalPlaylists.list() else emptyList()
        val shownRows = lists.size.coerceAtMost(ROWS)
        val h = when (mode) {
            Mode.PICK -> 96f + (shownRows + 1) * 34f
            Mode.DELETE -> 150f
            else -> 156f
        }
        val box = LayoutBounds((ui.lw - w) / 2f, (ui.lh - h) / 2f, w, h)
        ctx.drawGlass(box, Theme.GLASS_WINDOW)
        val title = when (mode) {
            Mode.NEW -> "New playlist"
            Mode.RENAME -> "Rename playlist"
            Mode.PICK -> "Add to playlist"
            else -> "Delete playlist"
        }
        ui.text(I18n.text(title), box.x + 20f, box.y + 20f, 18f, Theme.TEXT_PRIMARY, Theme.FONT_SEMIBOLD)
        val closeB = LayoutBounds(box.right - 38f, box.y + 14f, 24f, 24f)
        ctx.drawShape(closeB, ShapeStyle(if (ui.hover(closeB)) Theme.CARD_HOVER else Theme.CARD, 12f))
        ui.text("x", closeB.x + 8.5f, closeB.y + 7f, 12f, Theme.TEXT_PRIMARY, Theme.FONT_MEDIUM)
        hits += closeB to { close() }
        val fx = box.x + 20f
        val fw = w - 40f

        fun button(r: LayoutBounds, label: String, primary: Boolean, action: () -> Unit) {
            ctx.drawShape(r, ShapeStyle(if (primary) RED else if (ui.hover(r)) Theme.CARD_HOVER else Theme.CARD, 14f))
            val t = I18n.text(label)
            ui.text(t, r.x + (r.width - ui.width(t, 12f, Theme.FONT_MEDIUM)) / 2f, r.y + 9f, 12f, Theme.TEXT_PRIMARY, Theme.FONT_MEDIUM)
            hits += r to action
        }

        when (mode) {
            Mode.NEW, Mode.RENAME -> {
                val field = LayoutBounds(fx, box.y + 62f, fw, 32f)
                ctx.drawShape(field, ShapeStyle(Theme.CARD_HOVER, 10f))
                ctx.drawShape(field, ShapeStyle(Color(0f, 0f, 0f, 0f), 10f, 1f, RED))
                if (text.isEmpty()) ui.text(I18n.text("Playlist name"), field.x + 12f, field.y + 10f, 12f, Theme.TEXT_TERTIARY, Theme.FONT_MEDIUM)
                else ui.text(ui.trim(text, fw - 26f, 13f) + if (caretVisible()) "|" else "", field.x + 12f, field.y + 9f, 13f, Theme.TEXT_PRIMARY, Theme.FONT_MEDIUM)
                if (text.isEmpty()) ui.text(if (caretVisible()) "|" else "", field.x + 11f, field.y + 9f, 13f, Theme.TEXT_PRIMARY, Theme.FONT_MEDIUM)
                button(LayoutBounds(fx, box.y + 108f, fw / 2f - 4f, 30f), "Cancel", false) { close() }
                button(LayoutBounds(fx + fw / 2f + 4f, box.y + 108f, fw / 2f - 4f, 30f), if (mode == Mode.NEW) "Create" else "Save", true) { commitText() }
            }
            Mode.DELETE -> {
                val name = target?.name.orEmpty()
                val lines = ui.wrap2(I18n.format("Delete \"%s\"? Its songs are not deleted from any music service.", name), fw, 12f)
                lines.forEachIndexed { i, l -> ui.text(l, fx, box.y + 62f + i * 15f, 12f, Theme.TEXT_SECONDARY) }
                button(LayoutBounds(fx, box.y + 108f, fw / 2f - 4f, 30f), "Cancel", false) { close() }
                button(LayoutBounds(fx + fw / 2f + 4f, box.y + 108f, fw / 2f - 4f, 30f), "Delete", true) {
                    target?.let {
                        LocalPlaylists.delete(it.id)
                        Library.localChanged(it.id, removed = true)
                        if (ScreenState.opened?.id == it.id) screen.go(Page.HOME)
                    }
                    close()
                }
            }
            Mode.PICK -> {
                var y = box.y + 56f
                val first = pickScroll.coerceIn(0, (lists.size - ROWS).coerceAtLeast(0))
                for (i in first until (first + ROWS).coerceAtMost(lists.size)) {
                    val p = lists[i]
                    val row = LayoutBounds(fx, y, fw, 30f)
                    ctx.drawShape(row, ShapeStyle(if (ui.hover(row)) Theme.CARD_HOVER else Theme.CARD, 10f))
                    ui.text(ui.trim(p.name, fw - 70f, 12f), row.x + 12f, row.y + 9f, 12f, Theme.TEXT_PRIMARY, Theme.FONT_MEDIUM)
                    val count = p.trackCount.toString()
                    ui.text(count, row.right - 12f - ui.width(count, 11f), row.y + 9f, 11f, Theme.TEXT_TERTIARY)
                    hits += row to { addTo(p) }
                    y += 34f
                }
                val add = LayoutBounds(fx, y + 4f, fw, 30f)
                button(add, "+ New playlist", true) { openNew(pending) }
            }
            else -> {}
        }
    }

    fun mouseClicked(mx: Int, my: Int, button: Int) {
        if (button == 0) hits.firstOrNull { it.first.contains(mx, my) }?.second?.invoke()
    }

    fun keyTyped(typedChar: Char, keyCode: Int) {
        when {
            keyCode == Keys.ESCAPE -> close()
            !editing -> {}
            keyCode == Keys.RETURN || keyCode == Keys.NUMPADENTER -> commitText()
            keyCode == Keys.BACK -> text = text.dropLast(1)
            DangoClient.platform.ctrlDown && keyCode == Keys.V -> text = DangoClient.platform.clipboard.trim().filter(Keys::isAllowedChar).take(60)
            Keys.isAllowedChar(typedChar) -> text = (text + typedChar).take(60)
        }
    }
}
