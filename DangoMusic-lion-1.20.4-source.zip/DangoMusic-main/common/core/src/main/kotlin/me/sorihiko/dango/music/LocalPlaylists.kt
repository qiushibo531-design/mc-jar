package me.sorihiko.dango.music

import com.google.gson.JsonArray
import com.google.gson.JsonObject
import com.google.gson.JsonParser
import me.sorihiko.dango.DangoLogger
import me.sorihiko.dango.DangoMusic
import me.sorihiko.dango.lyrics.Lyrics
import me.sorihiko.dango.party.PartyTrackCodec
import java.nio.file.Files
import java.nio.file.StandardCopyOption

/**
 * Account-less playlists (Uncle Lion edition). They live in config/dangomusic/local_playlists.json,
 * can mix songs from every source, and are shown under "MY PLAYLISTS" whichever source is selected.
 */
object LocalPlaylists {
    /** Local playlist ids live in a range no provider uses. */
    const val BASE = 8_000_000_000_000_000_000L
    const val SPAN = 1_000_000_000_000_000L
    fun isLocal(id: Long) = id >= BASE && id < BASE + SPAN

    class Entry(val id: Long, var name: String, val tracks: MutableList<NeteaseTrack> = mutableListOf())

    private val lock = Any()
    private var entries: MutableList<Entry>? = null
    /** Bumped on every change so the UI knows to refresh. */
    @Volatile var version = 0
        private set

    private fun file() = DangoMusic.instance.clientDir.resolve("local_playlists.json")

    private fun all(): MutableList<Entry> {
        entries?.let { return it }
        val list = mutableListOf<Entry>()
        try {
            val f = file()
            if (Files.isRegularFile(f)) {
                val root = JsonParser().parse(String(Files.readAllBytes(f), Charsets.UTF_8)).asJsonObject
                for (p in root.getAsJsonArray("playlists") ?: JsonArray()) {
                    val o = p.asJsonObject
                    val id = o.get("id").asLong
                    if (!isLocal(id)) continue
                    val e = Entry(id, o.get("name")?.asString.orEmpty().take(60))
                    for (t in o.getAsJsonArray("tracks") ?: JsonArray()) {
                        PartyTrackCodec.readLocal(t.asJsonObject)?.let { e.tracks += it }
                    }
                    list += e
                }
            }
        } catch (e: Exception) {
            DangoLogger.warn("Local playlists could not be read: {}", e.toString())
        }
        entries = list
        return list
    }

    private fun save() {
        try {
            val root = JsonObject()
            val arr = JsonArray()
            for (e in all()) arr.add(JsonObject().apply {
                addProperty("id", e.id); addProperty("name", e.name)
                add("tracks", JsonArray().also { a -> e.tracks.forEach { a.add(PartyTrackCodec.writeLocal(it)) } })
            })
            root.add("playlists", arr)
            val f = file()
            Files.createDirectories(f.parent)
            val tmp = f.resolveSibling("local_playlists.json.tmp")
            Files.write(tmp, root.toString().toByteArray(Charsets.UTF_8))
            Files.move(tmp, f, StandardCopyOption.REPLACE_EXISTING)
        } catch (e: Exception) {
            DangoLogger.warn("Local playlists could not be saved: {}", e.toString())
        }
        version++
    }

    fun list(): List<NeteasePlaylist> = synchronized(lock) {
        all().map { NeteasePlaylist(it.id, it.name, it.tracks.size, it.tracks.firstOrNull()?.coverUrl.orEmpty(), true, local = true) }
    }

    fun tracks(id: Long): List<NeteaseTrack> = synchronized(lock) { all().firstOrNull { it.id == id }?.tracks?.toList().orEmpty() }

    fun create(name: String): Long = synchronized(lock) {
        var id = BASE + System.currentTimeMillis()
        while (all().any { it.id == id }) id++
        all() += Entry(id, name.trim().ifEmpty { "New playlist" }.take(60))
        save(); id
    }

    fun rename(id: Long, name: String) = synchronized(lock) {
        all().firstOrNull { it.id == id }?.let { it.name = name.trim().ifEmpty { it.name }.take(60); save() }
    }

    fun delete(id: Long) = synchronized(lock) { if (all().removeAll { it.id == id }) save() }

    /** @return false if the song was already in the playlist. */
    fun add(id: Long, track: NeteaseTrack): Boolean = synchronized(lock) {
        val e = all().firstOrNull { it.id == id } ?: return false
        if (e.tracks.any { it.key == track.key }) return false
        e.tracks += track; save(); true
    }

    fun remove(id: Long, track: NeteaseTrack) = synchronized(lock) {
        all().firstOrNull { it.id == id }?.let { if (it.tracks.removeAll { t -> t.key == track.key }) save() }
    }

    fun contains(id: Long, track: NeteaseTrack): Boolean = synchronized(lock) { all().firstOrNull { it.id == id }?.tracks?.any { it.key == track.key } == true }
}

/** Adds the local playlists to any source without touching the source's own implementation. */
internal class LocalPlaylistApi(private val inner: MusicSourceApi) : MusicSourceApi by inner {
    override fun playlists(): List<NeteasePlaylist> {
        val local = LocalPlaylists.list()
        val remote = try { inner.playlists() } catch (e: Exception) { if (local.isEmpty()) throw e else emptyList() }
        return remote + local
    }

    override fun playlistTracks(id: Long): List<NeteaseTrack> =
        if (LocalPlaylists.isLocal(id)) LocalPlaylists.tracks(id) else inner.playlistTracks(id)
}
