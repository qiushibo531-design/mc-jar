package me.sorihiko.dango.music

import com.google.gson.JsonObject
import com.google.gson.JsonParser
import me.sorihiko.dango.lyrics.Lyrics
import me.sorihiko.dango.lyrics.LyricsProvider

/*
 * Login-free music catalogues added in the Uncle Lion edition (ported from the SongRequest mod).
 * They are guest-only: search + play (+ lyrics where the service offers them).
 */

internal fun refererFor(source: MusicSource): String = when (source) {
    MusicSource.QQ -> "https://y.qq.com/"
    MusicSource.KUGOU -> "https://m.kugou.com/"
    MusicSource.MIGU -> "https://m.music.migu.cn/"
    MusicSource.KUWO -> "http://www.kuwo.cn/"
    else -> "https://www.google.com/"
}

private fun fetchText(url: String, referer: String): String =
    String(SourceHttp.bytes(url, referer, 4 * 1024 * 1024) ?: throw SourceAccessException("Source request failed"), Charsets.UTF_8)

private fun track(source: MusicSource, nativeId: String, name: String, artists: List<String>, durationMs: Long,
                  cover: String = "", media: String = nativeId, album: String = ""): NeteaseTrack =
    NeteaseTrack(MusicSources.stableId(source, nativeId), name.ifBlank { "?" }, artists.filter { it.isNotBlank() }, durationMs, cover, source, nativeId, media, album)

/** Audius: decentralised, official public API, full-length streams. */
object AudiusSource : MusicSourceApi {
    override val source = MusicSource.AUDIUS
    private const val APP = "DangoMusic"
    @Volatile private var host: String? = null

    private fun host(): String {
        host?.let { return it }
        val h = try {
            JsonParser().parse(fetchText("https://api.audius.co", "")).asJsonObject.getAsJsonArray("data")[0].asString
        } catch (_: Exception) { "https://discoveryprovider.audius.co" }
        host = h
        return h
    }

    override fun search(query: String): List<NeteaseTrack> {
        val root = SourceHttp.json("${host()}/v1/tracks/search?app_name=$APP&query=${SourceHttp.enc(query.trim())}", "")
        return root.array("data").mapNotNull { e ->
            val s = e.takeIf { it.isJsonObject }?.asJsonObject ?: return@mapNotNull null
            val id = s.text("id").ifEmpty { return@mapNotNull null }
            val art = s.obj("artwork")?.let { it.text("480x480").ifEmpty { it.text("150x150") } }.orEmpty()
            track(source, id, s.text("title"), listOf(s.obj("user")?.text("name").orEmpty()), s.number("duration") * 1000, art)
        }
    }

    override fun songUrl(track: NeteaseTrack): NeteaseApi.SongUrl? {
        // Audius answers /stream with a redirect to a content node; SourceHttp follows redirects itself.
        return NeteaseApi.SongUrl("${host()}/v1/tracks/${SourceHttp.enc(track.nativeId)}/stream?app_name=$APP", false)
    }

    override fun lyrics(track: NeteaseTrack): Lyrics? = null
}

/** Internet Archive: public-domain / CC audio. Duration is unknown until the file is decoded. */
object ArchiveSource : MusicSourceApi {
    override val source = MusicSource.ARCHIVE
    private fun enc(s: String) = SourceHttp.enc(s).replace("+", "%20")

    override fun search(query: String): List<NeteaseTrack> {
        val q = "(title:(${query.trim()}) OR creator:(${query.trim()})) AND mediatype:audio"
        val root = SourceHttp.json("https://archive.org/advancedsearch.php?q=${enc(q)}&fl%5B%5D=identifier&fl%5B%5D=title&fl%5B%5D=creator" +
            "&sort%5B%5D=downloads+desc&rows=25&output=json", "")
        return root.obj("response")?.array("docs").let { it ?: com.google.gson.JsonArray() }.mapNotNull { e ->
            val d = e.takeIf { it.isJsonObject }?.asJsonObject ?: return@mapNotNull null
            val id = d.text("identifier").ifEmpty { return@mapNotNull null }
            val creator = d.get("creator")?.let { if (it.isJsonArray) it.asJsonArray.firstOrNull()?.asString else if (it.isJsonPrimitive) it.asString else null }.orEmpty()
            track(source, id, d.text("title"), listOf(creator), 0L, "https://archive.org/services/img/${enc(id)}")
        }
    }

    override fun songUrl(track: NeteaseTrack): NeteaseApi.SongUrl? {
        val files = SourceHttp.json("https://archive.org/metadata/${enc(track.nativeId)}", "").array("files")
        var best: String? = null
        for (f in files) {
            val o = f.takeIf { it.isJsonObject }?.asJsonObject ?: continue
            val name = o.text("name")
            if (name.lowercase().endsWith(".mp3")) {
                best = name
                if (!o.text("source").equals("Original", true)) break // derived MP3s are usually smaller
            }
        }
        val file = best ?: return null
        return NeteaseApi.SongUrl("https://archive.org/download/${enc(track.nativeId)}/${enc(file).replace("%2F", "/")}", false)
    }

    override fun lyrics(track: NeteaseTrack): Lyrics? = null
}

/** ccMixter: Creative Commons remixes and originals. */
object CcMixterSource : MusicSourceApi {
    override val source = MusicSource.CCMIXTER

    override fun search(query: String): List<NeteaseTrack> {
        val text = fetchText("https://ccmixter.org/api/query?f=json&limit=25&sort=rank&search_type=all&search=${SourceHttp.enc(query.trim())}", "")
        val root = JsonParser().parse(text)
        if (!root.isJsonArray) return emptyList()
        return root.asJsonArray.mapNotNull { e ->
            val o = e.takeIf { it.isJsonObject }?.asJsonObject ?: return@mapNotNull null
            val url = o.array("files").mapNotNull { f -> f.takeIf { it.isJsonObject }?.asJsonObject?.text("download_url") }
                .firstOrNull { it.lowercase().endsWith(".mp3") } ?: return@mapNotNull null
            val id = o.text("upload_id").ifEmpty { url }
            track(source, id, o.text("upload_name"), listOf(o.text("user_real_name").ifEmpty { o.text("user_name") }), 0L, "", media = url)
        }
    }

    override fun songUrl(track: NeteaseTrack): NeteaseApi.SongUrl? =
        track.mediaId.takeIf { it.startsWith("http") }?.let { NeteaseApi.SongUrl(it, false) }

    override fun lyrics(track: NeteaseTrack): Lyrics? = null
}

/** Deezer public search API. Only the 30 s preview is available without a subscription. */
object DeezerSource : MusicSourceApi {
    override val source = MusicSource.DEEZER

    override fun search(query: String): List<NeteaseTrack> {
        val root = SourceHttp.json("https://api.deezer.com/search?limit=30&q=${SourceHttp.enc(query.trim())}", "")
        return root.array("data").mapNotNull { e ->
            val s = e.takeIf { it.isJsonObject }?.asJsonObject ?: return@mapNotNull null
            val id = s.text("id").ifEmpty { return@mapNotNull null }
            val album = s.obj("album")
            track(source, id, s.text("title"), listOf(s.obj("artist")?.text("name").orEmpty()), s.number("duration") * 1000,
                album?.text("cover_big")?.ifEmpty { album.text("cover_medium") }.orEmpty())
        }
    }

    override fun songUrl(track: NeteaseTrack): NeteaseApi.SongUrl? {
        // Preview URLs are time-limited, so fetch a fresh one right before playing.
        val preview = SourceHttp.json("https://api.deezer.com/track/${SourceHttp.enc(track.nativeId)}", "").text("preview")
        return if (preview.isEmpty()) null else NeteaseApi.SongUrl(preview, true)
    }

    override fun lyrics(track: NeteaseTrack): Lyrics? = null
}

/** Kuwo (unofficial web endpoints). */
object KuwoSource : MusicSourceApi {
    override val source = MusicSource.KUWO
    private const val REF = "http://www.kuwo.cn/"

    override fun search(query: String): List<NeteaseTrack> {
        val url = "http://search.kuwo.cn/r.s?client=kt&all=${SourceHttp.enc(query.trim())}&pn=0&rn=30&ft=music&cluster=0&strategy=2012&encoding=utf8&rformat=json&vermerge=1&mobi=1"
        val root = JsonParser().parse(fetchText(url, REF).replace("'", "\"")).asJsonObject
        return root.array("abslist").mapNotNull { e ->
            val s = e.takeIf { it.isJsonObject }?.asJsonObject ?: return@mapNotNull null
            val rid = s.text("MUSICRID").replace("MUSIC_", "").ifEmpty { return@mapNotNull null }
            track(source, rid, cleanSourceText(s.text("SONGNAME")), cleanSourceText(s.text("ARTIST")).split("&").map { it.trim() },
                s.number("DURATION") * 1000, "", album = "")
        }
    }

    override fun songUrl(track: NeteaseTrack): NeteaseApi.SongUrl? {
        val url = fetchText("http://antiserver.kuwo.cn/anti.s?type=convert_url&format=mp3&response=url&rid=MUSIC_${SourceHttp.enc(track.nativeId)}", REF).trim()
        return if (url.startsWith("http")) NeteaseApi.SongUrl(url, false) else null
    }

    override fun lyrics(track: NeteaseTrack): Lyrics? {
        val data = SourceHttp.json("http://m.kuwo.cn/newh5/singles/songinfoandlrc?musicId=${SourceHttp.enc(track.nativeId)}", REF).obj("data") ?: return null
        val lrc = StringBuilder()
        for (e in data.array("lrclist")) {
            val l = e.takeIf { it.isJsonObject }?.asJsonObject ?: continue
            val ms = ((l.text("time").toDoubleOrNull() ?: 0.0) * 1000).toLong()
            lrc.append(String.format("[%02d:%02d.%02d]%s\n", ms / 60000, ms / 1000 % 60, ms % 1000 / 10, l.text("lineLyric")))
        }
        val lines = LyricsProvider.parseLrc(lrc.toString())
        return if (lines.isEmpty()) null else Lyrics(lines, source.label)
    }
}

/** Migu (unofficial mobile web endpoints). The search result carries the MP3 and lyric URLs. */
object MiguSource : MusicSourceApi {
    override val source = MusicSource.MIGU
    private const val REF = "https://m.music.migu.cn/"

    override fun search(query: String): List<NeteaseTrack> {
        val root = SourceHttp.json("https://m.music.migu.cn/migu/remoting/scr_search_tag?rows=30&type=2&pgc=1&keyword=${SourceHttp.enc(query.trim())}", REF)
        return root.array("musics").mapNotNull { e ->
            val s = e.takeIf { it.isJsonObject }?.asJsonObject ?: return@mapNotNull null
            val id = s.text("copyrightId").ifEmpty { s.text("id") }.ifEmpty { return@mapNotNull null }
            track(source, id, cleanSourceText(s.text("songName")), cleanSourceText(s.text("singerName")).split(",", "、", "&").map { it.trim() },
                0L, s.text("cover"), media = s.text("mp3"), album = s.text("lrcUrl"))
        }
    }

    override fun songUrl(track: NeteaseTrack): NeteaseApi.SongUrl? =
        track.mediaId.takeIf { it.startsWith("http") }?.let { NeteaseApi.SongUrl(it, false) }

    override fun lyrics(track: NeteaseTrack): Lyrics? {
        val url = track.albumId.takeIf { it.startsWith("http") } ?: return null
        val lines = LyricsProvider.parseLrc(fetchText(url, REF))
        return if (lines.isEmpty()) null else Lyrics(lines, source.label)
    }
}
