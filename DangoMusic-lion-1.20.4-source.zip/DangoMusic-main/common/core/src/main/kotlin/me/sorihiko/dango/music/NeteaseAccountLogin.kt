package me.sorihiko.dango.music

import com.google.gson.JsonObject
import com.google.gson.JsonParser
import me.sorihiko.dango.DangoLogger
import java.security.MessageDigest

/**
 * NetEase phone-number / account login (added in the Uncle Lion edition):
 *   - SMS captcha:     phone + 4-digit code
 *   - Password login:  phone number or e-mail address + password
 * The result is the same cookie the QR login produces, saved through [NeteaseApi.saveCookie].
 */
object NeteaseAccountLogin {
    @Volatile var busy = false
        private set
    /** Last status line for the dialog (already an I18n key or a server message). */
    @Volatile var message = ""
        private set
    @Volatile var messageIsError = false
        private set
    @Volatile var success = false
        private set
    /** Wall-clock millis until which "send code" is disabled. */
    @Volatile var nextSendAt = 0L
        private set

    fun reset() {
        busy = false; message = ""; messageIsError = false; success = false
    }

    private fun md5(text: String): String =
        MessageDigest.getInstance("MD5").digest(text.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }

    private fun esc(s: String) = s.replace("\\", "\\\\").replace("\"", "\\\"")

    private fun fail(text: String) { message = text; messageIsError = true; busy = false }

    private fun isPhone(value: String) = value.length in 6..15 && value.all { it.isDigit() }

    fun sendCaptcha(phone: String, countryCode: String = "86") {
        if (busy) return
        val p = phone.trim()
        if (!isPhone(p)) { fail("Enter a valid phone number"); return }
        busy = true; message = ""; messageIsError = false
        Thread({
            try {
                val r = NeteaseLogin.weapi("https://music.163.com/weapi/sms/captcha/sent",
                    """{"cellphone":"${esc(p)}","ctcode":"${esc(countryCode)}"}""")
                val obj = r?.first?.let { JsonParser().parse(it).asJsonObject }
                if (obj != null && obj.get("code")?.asInt == 200) {
                    nextSendAt = System.currentTimeMillis() + 60_000L
                    message = "Code sent. Check your SMS."; messageIsError = false
                    busy = false
                } else fail(serverMessage(obj, "Could not send the code"))
            } catch (e: Exception) {
                DangoLogger.warn("NetEase captcha request failed: {}", e.toString())
                fail("Network error, try again")
            }
        }, "Dango-NeteaseCaptcha").apply { isDaemon = true; start() }
    }

    fun loginWithCaptcha(phone: String, code: String, countryCode: String = "86") {
        if (busy) return
        val p = phone.trim(); val c = code.trim()
        if (!isPhone(p)) { fail("Enter a valid phone number"); return }
        if (c.isEmpty()) { fail("Enter the SMS code"); return }
        submit("https://music.163.com/weapi/login/cellphone",
            """{"phone":"${esc(p)}","countrycode":"${esc(countryCode)}","captcha":"${esc(c)}","rememberLogin":"true"}""")
    }

    /** [account] is a phone number or an e-mail address. */
    fun loginWithPassword(account: String, password: String, countryCode: String = "86") {
        if (busy) return
        val a = account.trim()
        if (a.isEmpty() || password.isEmpty()) { fail("Enter your account and password"); return }
        val hash = md5(password)
        if (isPhone(a)) submit("https://music.163.com/weapi/login/cellphone",
            """{"phone":"${esc(a)}","countrycode":"${esc(countryCode)}","password":"$hash","rememberLogin":"true"}""")
        else submit("https://music.163.com/weapi/login",
            """{"username":"${esc(a)}","password":"$hash","rememberLogin":"true"}""")
    }

    private fun submit(url: String, json: String) {
        busy = true; message = ""; messageIsError = false
        Thread({
            try {
                val r = NeteaseLogin.weapi(url, json)
                if (r == null) { fail("Network error, try again"); return@Thread }
                val obj = JsonParser().parse(r.first).asJsonObject
                val code = obj.get("code")?.asInt ?: -1
                val cookie = NeteaseLogin.extractCookie(r.second)
                if (code == 200 && cookie.contains("MUSIC_U=")) {
                    NeteaseApi.saveCookie(cookie)
                    success = true; busy = false
                } else if (code == 200) fail("Login failed")
                else fail(serverMessage(obj, when (code) {
                    502 -> "Wrong password"
                    400 -> "Account not found"
                    else -> "Login failed"
                }))
            } catch (e: Exception) {
                DangoLogger.warn("NetEase account login failed: {}", e.toString())
                fail("Network error, try again")
            }
        }, "Dango-NeteaseAccount").apply { isDaemon = true; start() }
    }

    private fun serverMessage(obj: JsonObject?, fallback: String): String {
        val code = obj?.get("code")?.takeIf { it.isJsonPrimitive }?.asInt
        return when (code) {
            -462, 8821 -> "Security check required. Log in with QR once, or use the SMS code."
            503 -> "Wrong or expired code"
            400 -> "Account not found"
            502 -> "Wrong password"
            else -> fallback
        }
    }
}
